/**
 * WorkDesk AI - Document Agent API Client
 * Wraps /documents upload, list, delete, and RAG Q&A endpoints.
 */

import { apiClient } from './client';
import { authApi } from './auth';

export interface DocumentItem {
  id: string;
  filename: string;
  file_size: number;
  mime_type: string;
  status: 'uploaded' | 'processing' | 'ready' | 'error';
  total_pages: number;
  total_chunks: number;
  created_at: string;
  injections_neutralized: number;
  text_preview?: string;
}

export interface DocumentCitation {
  page: number;
  relevance_score: number;
  snippet: string;
}

export interface DocumentAskResponse {
  answer: string;
  citations: DocumentCitation[];
  pages_referenced: number[];
  confidence_score: number;
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = (error) => reject(error);
  });
}

// In-memory local cache for offline dev
let _LOCAL_DOCS: DocumentItem[] = [
  {
    id: 'demo-doc-001',
    filename: 'Vendor_Master_Services_Agreement_2026.pdf',
    file_size: 428000,
    mime_type: 'application/pdf',
    status: 'ready',
    total_pages: 8,
    total_chunks: 14,
    created_at: new Date(Date.now() - 3600000).toISOString(),
    injections_neutralized: 0,
    text_preview: 'MASTER SERVICES AGREEMENT\nBetween WorkDesk Enterprise and Cloud Services Vendor.\n1. SCOPE: Deliver cloud API infrastructure with 99.9% uptime SLA.\n2. PAYMENT: Monthly invoicing with Net-30 payment schedule.\n3. TERMINATION: 60 days written notice required.',
  },
];

export const documentsApi = {
  async upload(file: File): Promise<DocumentItem> {
    const base64 = await fileToBase64(file);
    const token = authApi.getToken();

    try {
      const res = await apiClient.post<DocumentItem>(
        '/documents/upload',
        {
          filename: file.name,
          content_base64: base64,
          mime_type: file.type || 'application/octet-stream',
        },
        token ? { Authorization: `Bearer ${token}` } : undefined
      );
      _LOCAL_DOCS.unshift(res);
      return res;
    } catch (err: unknown) {
      const isNetError =
        typeof err === 'object' && err !== null && (err as { isNetworkError?: boolean }).isNetworkError;

      if (isNetError) {
        const simulated: DocumentItem = {
          id: `sim-doc-${Date.now()}`,
          filename: file.name,
          file_size: file.size,
          mime_type: file.type || 'application/octet-stream',
          status: 'ready',
          total_pages: Math.max(1, Math.round(file.size / 15000)),
          total_chunks: Math.max(2, Math.round(file.size / 4000)),
          created_at: new Date().toISOString(),
          injections_neutralized: 0,
          text_preview: `Sample extracted preview for ${file.name}.\nDocument validated and indexed in vector storage.`,
        };
        _LOCAL_DOCS.unshift(simulated);
        return simulated;
      }
      throw err;
    }
  },

  async list(): Promise<DocumentItem[]> {
    const token = authApi.getToken();
    try {
      return await apiClient.get<DocumentItem[]>(
        '/documents',
        token ? { Authorization: `Bearer ${token}` } : undefined
      );
    } catch (err: unknown) {
      const isNetError =
        typeof err === 'object' && err !== null && (err as { isNetworkError?: boolean }).isNetworkError;
      if (isNetError) {
        return _LOCAL_DOCS;
      }
      throw err;
    }
  },

  async get(id: string): Promise<DocumentItem> {
    const token = authApi.getToken();
    try {
      return await apiClient.get<DocumentItem>(
        `/documents/${id}`,
        token ? { Authorization: `Bearer ${token}` } : undefined
      );
    } catch (err: unknown) {
      const found = _LOCAL_DOCS.find((d) => d.id === id);
      if (found) return found;
      throw err;
    }
  },

  async delete(id: string): Promise<void> {
    const token = authApi.getToken();
    try {
      await apiClient.delete(
        `/documents/${id}`,
        token ? { Authorization: `Bearer ${token}` } : undefined
      );
    } catch (err) {
      console.warn('Backend delete probe:', err);
    }
    _LOCAL_DOCS = _LOCAL_DOCS.filter((d) => d.id !== id);
  },

  async ask(id: string, question: string, mode: string = 'qa'): Promise<DocumentAskResponse> {
    const token = authApi.getToken();
    try {
      return await apiClient.post<DocumentAskResponse>(
        `/documents/${id}/ask`,
        { question, mode },
        token ? { Authorization: `Bearer ${token}` } : undefined
      );
    } catch (err: unknown) {
      const isNetError =
        typeof err === 'object' && err !== null && (err as { isNetworkError?: boolean }).isNetworkError;

      if (isNetError) {
        const found = _LOCAL_DOCS.find((d) => d.id === id);
        const name = found ? found.filename : 'Document';

        if (mode === 'summary') {
          return {
            answer: `### Executive Briefing: ${name}\n\n**1. Overview**\nThis document defines service deliverables, operational terms, and performance benchmarks.\n\n**2. Key Takeaways**\n- 99.9% uptime SLA guarantee with credit rebates for outages.\n- Payment term Net-30 upon monthly itemized billing submission.\n- Termination clause requires 60 days advance written notice.\n\n**3. Action Items**\n- Review insurance certificates before effective date.\n- Set up automated billing reconciliation workflow.`,
            citations: [
              { page: 1, relevance_score: 0.94, snippet: '1. SCOPE: Deliver cloud API infrastructure with 99.9% uptime SLA...' },
              { page: 2, relevance_score: 0.88, snippet: '2. PAYMENT: Monthly invoicing with Net-30 payment schedule...' },
            ],
            pages_referenced: [1, 2],
            confidence_score: 0.94,
          };
        }

        return {
          answer: `Based on **${name}**:\n\nThe agreement stipulates a **Net-30 payment schedule** upon receipt of itemized monthly statements. Termination of service mandates a **60-day advance notice period**.\n\n*(Reference: [Page 1], [Page 2])*`,
          citations: [
            { page: 1, relevance_score: 0.92, snippet: 'Monthly invoicing with Net-30 payment schedule...' },
            { page: 2, relevance_score: 0.85, snippet: '3. TERMINATION: 60 days written notice required...' },
          ],
          pages_referenced: [1, 2],
          confidence_score: 0.92,
        };
      }
      throw err;
    }
  },
};
