/**
 * WorkDesk AI - Authentication API Client
 * Wraps auth endpoints with token management and offline simulation fallback.
 */

import { apiClient } from './client';
import { AuthResponse, LoginCredentials, SignupCredentials, User } from '../types/auth';

const STORAGE_KEY_TOKEN = 'workdesk_access_token';
const STORAGE_KEY_USER = 'workdesk_user_profile';

export const authApi = {
  getToken(): string | null {
    try {
      return localStorage.getItem(STORAGE_KEY_TOKEN);
    } catch {
      return null;
    }
  },

  setSession(token: string, user: User) {
    try {
      localStorage.setItem(STORAGE_KEY_TOKEN, token);
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
    } catch (e) {
      console.warn('Could not persist session to localStorage', e);
    }
  },

  clearSession() {
    try {
      localStorage.removeItem(STORAGE_KEY_TOKEN);
      localStorage.removeItem(STORAGE_KEY_USER);
    } catch (e) {
      console.warn('Could not clear session', e);
    }
  },

  getSavedUser(): User | null {
    try {
      const data = localStorage.getItem(STORAGE_KEY_USER);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    try {
      const res = await apiClient.post<AuthResponse>('/auth/login', credentials);
      authApi.setSession(res.access_token, res.user);
      return res;
    } catch (err: unknown) {
      // If server is not reachable during local UI dev, fallback to standard demo accounts
      const isNetError =
        typeof err === 'object' && err !== null && (err as { isNetworkError?: boolean }).isNetworkError;

      if (isNetError) {
        return authApi.simulateLogin(credentials);
      }
      throw err;
    }
  },

  async signup(credentials: SignupCredentials): Promise<AuthResponse> {
    try {
      const res = await apiClient.post<AuthResponse>('/auth/signup', credentials);
      authApi.setSession(res.access_token, res.user);
      return res;
    } catch (err: unknown) {
      const isNetError =
        typeof err === 'object' && err !== null && (err as { isNetworkError?: boolean }).isNetworkError;

      if (isNetError) {
        return authApi.simulateSignup(credentials);
      }
      throw err;
    }
  },

  async logout(): Promise<void> {
    const token = authApi.getToken();
    if (token) {
      try {
        await apiClient.post('/auth/logout', {}, {
          Authorization: `Bearer ${token}`,
        });
      } catch (err) {
        console.warn('Backend logout probe warning:', err);
      }
    }
    authApi.clearSession();
  },

  async getMe(): Promise<User> {
    const token = authApi.getToken();
    if (!token) {
      throw new Error('No authentication token found.');
    }

    try {
      const user = await apiClient.get<User>('/auth/me', {
        Authorization: `Bearer ${token}`,
      });
      authApi.setSession(token, user);
      return user;
    } catch (err: unknown) {
      const isNetError =
        typeof err === 'object' && err !== null && (err as { isNetworkError?: boolean }).isNetworkError;
      if (isNetError) {
        const saved = authApi.getSavedUser();
        if (saved) return saved;
      }
      throw err;
    }
  },

  async getAdminUsers(): Promise<User[]> {
    const token = authApi.getToken();
    if (!token) throw new Error('Not authenticated');

    return apiClient.get<User[]>('/auth/admin/users', {
      Authorization: `Bearer ${token}`,
    });
  },

  // Fallback simulator for offline dev preview
  simulateLogin(credentials: LoginCredentials): AuthResponse {
    const email = credentials.email.toLowerCase().trim();
    if (email === 'admin@workdesk.ai') {
      const user: User = {
        id: '00000000-0000-0000-0000-000000000001',
        email: 'admin@workdesk.ai',
        full_name: 'WorkDesk Administrator',
        role: 'admin',
        is_active: true,
        is_verified: true,
        created_at: new Date().toISOString(),
        credit_balance: 1000,
        plan_slug: 'business',
        plan_name: 'Business Workspace',
      };
      const token = `simulated_admin_jwt_${Date.now()}`;
      authApi.setSession(token, user);
      return { access_token: token, token_type: 'bearer', expires_in: 86400, user };
    }

    // Default regular user
    const user: User = {
      id: '00000000-0000-0000-0000-000000000002',
      email: email || 'demo@workdesk.ai',
      full_name: email.split('@')[0] || 'Demo User',
      role: 'user',
      is_active: true,
      is_verified: true,
      created_at: new Date().toISOString(),
      credit_balance: 10,
      plan_slug: 'free',
      plan_name: 'Free Starter',
    };
    const token = `simulated_user_jwt_${Date.now()}`;
    authApi.setSession(token, user);
    return { access_token: token, token_type: 'bearer', expires_in: 86400, user };
  },

  simulateSignup(credentials: SignupCredentials): AuthResponse {
    const user: User = {
      id: crypto.randomUUID(),
      email: credentials.email.toLowerCase().trim(),
      full_name: credentials.full_name,
      role: 'user',
      is_active: true,
      is_verified: false,
      created_at: new Date().toISOString(),
      credit_balance: 10,
      plan_slug: 'free',
      plan_name: 'Free Starter',
    };
    const token = `simulated_signup_jwt_${Date.now()}`;
    authApi.setSession(token, user);
    return { access_token: token, token_type: 'bearer', expires_in: 86400, user };
  },
};
