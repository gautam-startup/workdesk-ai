/**
 * WorkDesk AI - Health API Service
 * Wraps GET /api/v1/health with timing and diagnostics.
 */

import { apiClient } from './client';
import { HealthStatusResponse } from '../types/api';

export interface HealthProbeResult {
  data: HealthStatusResponse | null;
  latencyMs: number;
  isOnline: boolean;
  error?: string;
  isSimulated?: boolean;
}

export async function checkBackendHealth(): Promise<HealthProbeResult> {
  const startTime = performance.now();
  try {
    const data = await apiClient.get<HealthStatusResponse>('/health');
    const latencyMs = Math.round(performance.now() - startTime);

    return {
      data,
      latencyMs,
      isOnline: true,
    };
  } catch (err: unknown) {
    const latencyMs = Math.round(performance.now() - startTime);
    const errorMsg =
      err && typeof err === 'object' && 'message' in err
        ? String((err as { message: string }).message)
        : 'Network error';

    return {
      data: null,
      latencyMs,
      isOnline: false,
      error: errorMsg,
    };
  }
}
