/**
 * WorkDesk AI - Core API Client Abstraction
 * Handles base URLs, standard headers, request IDs, error normalization, and telemetry logging.
 */

import { ApiError, ApiResponse } from '../types/api';

const DEFAULT_API_BASE =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_API_BASE_URL) ||
  'http://localhost:8000/api/v1';

export class ApiClient {
  private baseUrl: string;

  constructor(baseUrl: string = DEFAULT_API_BASE) {
    this.baseUrl = baseUrl.replace(/\/+$/, '');
  }

  /**
   * Sets or overrides the API base URL at runtime.
   */
  public setBaseUrl(url: string) {
    this.baseUrl = url.replace(/\/+$/, '');
  }

  public getBaseUrl(): string {
    return this.baseUrl;
  }

  /**
   * Unified request handler with error wrapping and logging.
   */
  public async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
    const url = `${this.baseUrl}${cleanEndpoint}`;
    const requestId = crypto.randomUUID();

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'X-Request-ID': requestId,
      ...(options.headers as Record<string, string>),
    };

    console.debug(`[ApiClient] Request -> ${options.method || 'GET'} ${url} [req_id=${requestId}]`);
    const startTime = performance.now();

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      const durationMs = Math.round(performance.now() - startTime);
      console.debug(
        `[ApiClient] Response <- ${options.method || 'GET'} ${url} status=${response.status} (${durationMs}ms)`
      );

      const contentType = response.headers.get('content-type') || '';
      let data: ApiResponse<T> | T | null = null;

      if (contentType.includes('application/json')) {
        data = await response.json();
      } else {
        const text = await response.text();
        data = { message: text } as unknown as T;
      }

      if (!response.ok) {
        const errPayload = data as ApiResponse<T>;
        const apiError: ApiError = {
          errorCode: errPayload?.error_code || `HTTP_${response.status}`,
          message:
            errPayload?.message ||
            `Request failed with status code ${response.status}`,
          statusCode: response.status,
          details: errPayload?.details,
          requestId: errPayload?.request_id || requestId,
          isNetworkError: false,
        };
        throw apiError;
      }

      return data as T;
    } catch (err: unknown) {
      const durationMs = Math.round(performance.now() - startTime);

      // Check if it's already an ApiError
      if (typeof err === 'object' && err !== null && 'statusCode' in err) {
        throw err as ApiError;
      }

      const networkError: ApiError = {
        errorCode: 'NETWORK_ERROR',
        message:
          err instanceof Error
            ? `Connection to backend failed (${err.message}). Is the FastAPI server running at ${this.baseUrl}?`
            : 'Unable to connect to the backend server.',
        statusCode: 0,
        requestId,
        isNetworkError: true,
        details: { durationMs, originalError: String(err) },
      };

      console.warn(`[ApiClient] Network failure to ${url}:`, err);
      throw networkError;
    }
  }

  public get<T>(endpoint: string, headers?: Record<string, string>): Promise<T> {
    return this.request<T>(endpoint, { method: 'GET', headers });
  }

  public post<T>(
    endpoint: string,
    body?: unknown,
    headers?: Record<string, string>
  ): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'POST',
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
  }

  public put<T>(
    endpoint: string,
    body?: unknown,
    headers?: Record<string, string>
  ): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'PUT',
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
  }

  public delete<T>(endpoint: string, headers?: Record<string, string>): Promise<T> {
    return this.request<T>(endpoint, { method: 'DELETE', headers });
  }
}

export const apiClient = new ApiClient();
