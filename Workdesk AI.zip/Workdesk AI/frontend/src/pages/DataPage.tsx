import React, { useState, useEffect, useRef } from 'react';
import {
  BarChart3,
  Upload,
  RefreshCw,
  Trash2,
  Sparkles,
  Download,
  AlertTriangle,
  CheckCircle2,
  Table,
  Filter,
  ArrowUpDown,
  Layers,
  FileSpreadsheet,
  TrendingUp,
  Sliders,
  Check,
} from 'lucide-react';
import { dataApi, DatasetDetail, DatasetSummary, SafeOperationItem } from '../api/data';

export const DataPage: React.FC = () => {
  const [datasets, setDatasets] = useState<DatasetSummary[]>([]);
  const [selectedDataset, setSelectedDataset] = useState<DatasetDetail | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // Active view tab
  const [activeTab, setActiveTab] = useState<'preview' | 'profile' | 'charts' | 'report'>('preview');

  // Operation state
  const [isTransforming, setIsTransforming] = useState(false);
  const [operationSuccess, setOperationSuccess] = useState<string | null>(null);

  // Filter/Sort Modal state
  const [selectedCol, setSelectedCol] = useState<string>('');
  const [sortAscending, setSortAscending] = useState(true);
  const [filterOp, setFilterOp] = useState('==');
  const [filterVal, setFilterVal] = useState('');

  // Report state
  const [reportText, setReportText] = useState<string | null>(null);
  const [isLoadingReport, setIsLoadingReport] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadDatasets();
  }, []);

  const loadDatasets = async () => {
    setIsLoading(true);
    try {
      const list = await dataApi.list();
      setDatasets(list);
      if (list.length > 0 && !selectedDataset) {
        loadDatasetDetail(list[0].id);
      }
    } catch (err) {
      console.error('Failed to load datasets:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const loadDatasetDetail = async (id: string) => {
    try {
      const detail = await dataApi.get(id);
      setSelectedDataset(detail);
      setReportText(null);
      if (detail.columns.length > 0) {
        setSelectedCol(detail.columns[0]);
      }
    } catch (err) {
      console.error('Failed to load dataset detail:', err);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setUploadError(null);

    try {
      const newDataset = await dataApi.upload(file);
      setSelectedDataset(newDataset);
      setDatasets((prev) => [
        {
          id: newDataset.id,
          filename: newDataset.filename,
          format: newDataset.format,
          total_rows: newDataset.profile.total_rows,
          total_columns: newDataset.profile.total_columns,
          quality_score: newDataset.profile.quality_score,
          created_at: newDataset.created_at,
        },
        ...prev,
      ]);
      setOperationSuccess('Dataset uploaded and profiled successfully!');
      setTimeout(() => setOperationSuccess(null), 3000);
    } catch (err: unknown) {
      const msg =
        err && typeof err === 'object' && 'message' in err
          ? String((err as { message: string }).message)
          : 'Failed to upload dataset.';
      setUploadError(msg);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleExecuteOperation = async (ops: SafeOperationItem[]) => {
    if (!selectedDataset || isTransforming) return;
    setIsTransforming(true);
    try {
      const updated = await dataApi.transform(selectedDataset.id, ops);
      setSelectedDataset(updated);
      setOperationSuccess('Operation applied deterministically!');
      setTimeout(() => setOperationSuccess(null), 3000);
    } catch (err: unknown) {
      const msg =
        err && typeof err === 'object' && 'message' in err
          ? String((err as { message: string }).message)
          : 'Operation failed.';
      alert(msg);
    } finally {
      setIsTransforming(false);
    }
  };

  const handleAutoClean = async () => {
    if (!selectedDataset) return;
    const ops: SafeOperationItem[] = [];

    // Deduplicate if duplicates detected
    if (selectedDataset.profile.duplicate_rows > 0) {
      ops.push({ operation: 'remove_duplicates' });
    }

    // Fill missing values for columns with nulls
    for (const [col, count] of Object.entries(selectedDataset.profile.null_counts)) {
      if (count > 0) {
        const dtype = selectedDataset.profile.column_types[col];
        const strategy = dtype === 'numeric' ? 'mean' : 'mode';
        ops.push({
          operation: 'fill_missing',
          params: { column: col, strategy },
        });
      }
    }

    if (ops.length > 0) {
      await handleExecuteOperation(ops);
    }
  };

  const handleGenerateReport = async () => {
    if (!selectedDataset || isLoadingReport) return;
    setIsLoadingReport(true);
    try {
      const res = await dataApi.generateReport(selectedDataset.id);
      setReportText(res.analysis_report);
      setActiveTab('report');
    } catch (err) {
      console.error('Failed to generate report:', err);
    } finally {
      setIsLoadingReport(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this dataset?')) return;
    try {
      await dataApi.delete(id);
      const remaining = datasets.filter((d) => d.id !== id);
      setDatasets(remaining);
      if (selectedDataset?.id === id) {
        if (remaining.length > 0) {
          loadDatasetDetail(remaining[0].id);
        } else {
          setSelectedDataset(null);
        }
      }
    } catch (err) {
      console.error('Delete dataset error:', err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs uppercase font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Phase 5 Complete
              </span>
              <span className="text-xs text-slate-400">
                Deterministic Pandas Engine • Zero Arbitrary Code • Safe Transforms
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-100">
              Data Analysis Agent
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Upload CSV or Excel spreadsheets. Inspect schema profiles, detect quality issues, and execute safe deterministic operations.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".csv,.xlsx"
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-emerald-600/20 transition-all cursor-pointer disabled:opacity-50"
            >
              {isUploading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Profiling Dataset...</span>
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  <span>Upload CSV / Excel</span>
                </>
              )}
            </button>
          </div>
        </div>

        {uploadError && (
          <div className="mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-xs text-red-300">
            {uploadError}
          </div>
        )}

        {operationSuccess && (
          <div className="mt-4 p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{operationSuccess}</span>
          </div>
        )}
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Dataset List (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Your Datasets ({datasets.length})
              </h3>
              <button
                onClick={loadDatasets}
                title="Refresh datasets"
                className="text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
              </button>
            </div>

            <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1">
              {datasets.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500">
                  <FileSpreadsheet className="w-8 h-8 mx-auto text-slate-600 mb-2" />
                  <p>No datasets uploaded yet.</p>
                  <p className="text-[11px] text-slate-600 mt-1">Upload a CSV or XLSX file to begin.</p>
                </div>
              ) : (
                datasets.map((d) => {
                  const isSelected = selectedDataset?.id === d.id;
                  return (
                    <div
                      key={d.id}
                      onClick={() => loadDatasetDetail(d.id)}
                      className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-emerald-600/10 border-emerald-500/40 text-slate-100 shadow-md'
                          : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-800/40 text-slate-300'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2 truncate">
                          <FileSpreadsheet className={`w-4 h-4 shrink-0 ${isSelected ? 'text-emerald-400' : 'text-slate-400'}`} />
                          <span className="font-semibold truncate">{d.filename}</span>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDelete(d.id);
                          }}
                          title="Delete dataset"
                          className="text-slate-500 hover:text-red-400 transition-colors p-0.5"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
                        <span>{d.total_rows} rows • {d.total_columns} cols</span>
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          d.quality_score > 85 ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        }`}>
                          Score: {d.quality_score}%
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Safe Operations Sandbox Notice */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 text-xs text-slate-400 space-y-2">
            <div className="flex items-center gap-2 text-slate-200 font-semibold">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Safe Predefined Operations</span>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-400">
              Operations execute via isolated deterministic Pandas routines without eval() or arbitrary code execution.
            </p>
          </div>
        </div>

        {/* Right Column: Profiler, Actions & Data Viewer (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {selectedDataset ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col min-h-[650px]">
              {/* Header Info */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800 shrink-0">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                    <FileSpreadsheet className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-slate-100 truncate max-w-sm">
                      {selectedDataset.filename}
                    </h2>
                    <p className="text-[11px] text-slate-400">
                      {selectedDataset.profile.total_rows} Rows • {selectedDataset.profile.total_columns} Columns • {selectedDataset.format.toUpperCase()}
                    </p>
                  </div>
                </div>

                {/* Primary Actions */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleGenerateReport}
                    disabled={isLoadingReport}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-medium cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className={`w-3.5 h-3.5 text-indigo-400 ${isLoadingReport ? 'animate-spin' : ''}`} />
                    <span>AI Report</span>
                  </button>

                  <a
                    href={dataApi.downloadUrl(selectedDataset.id)}
                    download
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-md shadow-emerald-600/20"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Cleaned</span>
                  </a>
                </div>
              </div>

              {/* Data Health & Issues Summary Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-4 border-b border-slate-800">
                <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Health Score</span>
                  <span className={`text-xl font-bold ${selectedDataset.profile.quality_score > 85 ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {selectedDataset.profile.quality_score}%
                  </span>
                </div>
                <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Duplicate Rows</span>
                  <span className="text-xl font-bold text-slate-200">
                    {selectedDataset.profile.duplicate_rows}
                  </span>
                </div>
                <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Missing Cells</span>
                  <span className="text-xl font-bold text-slate-200">
                    {selectedDataset.profile.total_missing_cells}
                  </span>
                </div>
                <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 flex items-center justify-center">
                  <button
                    onClick={handleAutoClean}
                    disabled={isTransforming || selectedDataset.profile.detected_issues.length === 0}
                    className="w-full h-full flex flex-col items-center justify-center px-2 py-1 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 rounded-lg text-xs font-semibold cursor-pointer disabled:opacity-40"
                  >
                    <Sparkles className="w-4 h-4 mb-0.5 text-indigo-400" />
                    <span>One-Click Clean</span>
                  </button>
                </div>
              </div>

              {/* Detected Quality Alerts */}
              {selectedDataset.profile.detected_issues.length > 0 && (
                <div className="py-3 border-b border-slate-800 space-y-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block">
                    Detected Quality Issues ({selectedDataset.profile.detected_issues.length})
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {selectedDataset.profile.detected_issues.map((issue, idx) => (
                      <div
                        key={idx}
                        className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-500/10 border border-amber-500/20 rounded-lg text-[11px] text-amber-300"
                      >
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        <span>{issue.message}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tab Navigation */}
              <div className="flex items-center gap-1 pt-3 pb-2 border-b border-slate-800 shrink-0">
                <button
                  onClick={() => setActiveTab('preview')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                    activeTab === 'preview'
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  <Table className="w-3.5 h-3.5" />
                  <span>Data Preview ({selectedDataset.preview_rows.length} rows)</span>
                </button>

                <button
                  onClick={() => setActiveTab('profile')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                    activeTab === 'profile'
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>Schema & Transforms</span>
                </button>

                <button
                  onClick={() => setActiveTab('charts')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                    activeTab === 'charts'
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  <BarChart3 className="w-3.5 h-3.5" />
                  <span>Charts & Trends</span>
                </button>

                <button
                  onClick={() => setActiveTab('report')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                    activeTab === 'report'
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>AI Business Report</span>
                </button>
              </div>

              {/* Tab 1: Interactive Data Preview Table */}
              {activeTab === 'preview' && (
                <div className="flex-1 overflow-x-auto overflow-y-auto pt-3">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400">
                        {selectedDataset.columns.map((col) => {
                          const dtype = selectedDataset.profile.column_types[col] || 'text';
                          return (
                            <th key={col} className="p-2.5 font-semibold text-slate-300">
                              <div className="flex items-center justify-between gap-2">
                                <span>{col}</span>
                                <span className={`text-[9px] uppercase px-1.5 py-0.5 rounded font-mono ${
                                  dtype === 'numeric'
                                    ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20'
                                    : dtype === 'datetime'
                                    ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                                    : 'bg-slate-800 text-slate-400'
                                }`}>
                                  {dtype}
                                </span>
                              </div>
                            </th>
                          );
                        })}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {selectedDataset.preview_rows.map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-800/30">
                          {selectedDataset.columns.map((col) => (
                            <td key={col} className="p-2.5 font-mono text-[11px] text-slate-300">
                              {row[col] === null || row[col] === undefined || row[col] === '' ? (
                                <span className="text-amber-400/80 italic text-[10px]">null</span>
                              ) : (
                                String(row[col])
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Tab 2: Schema & Safe Predefined Operations */}
              {activeTab === 'profile' && (
                <div className="flex-1 overflow-y-auto pt-3 space-y-4">
                  {/* Operations Card */}
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                    <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                      Execute Predefined Operation
                    </h3>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Sort Operation */}
                      <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 space-y-2">
                        <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                          <ArrowUpDown className="w-3.5 h-3.5 text-indigo-400" />
                          <span>Sort Rows</span>
                        </span>
                        <div className="flex items-center gap-2">
                          <select
                            value={selectedCol}
                            onChange={(e) => setSelectedCol(e.target.value)}
                            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg p-1.5 flex-1"
                          >
                            {selectedDataset.columns.map((c) => (
                              <option key={c} value={c}>{c}</option>
                            ))}
                          </select>
                          <button
                            onClick={() => setSortAscending(!sortAscending)}
                            className="px-2 py-1.5 bg-slate-800 text-xs rounded-lg text-slate-300"
                          >
                            {sortAscending ? 'ASC' : 'DESC'}
                          </button>
                        </div>
                        <button
                          onClick={() => handleExecuteOperation([{ operation: 'sort_rows', params: { column: selectedCol, ascending: sortAscending } }])}
                          disabled={isTransforming}
                          className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold cursor-pointer"
                        >
                          Sort Dataset
                        </button>
                      </div>

                      {/* Filter Operation */}
                      <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 space-y-2">
                        <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                          <Filter className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Filter Rows</span>
                        </span>
                        <div className="grid grid-cols-3 gap-1">
                          <select
                            value={selectedCol}
                            onChange={(e) => setSelectedCol(e.target.value)}
                            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg p-1.5"
                          >
                            {selectedDataset.columns.map((c) => (
                              <option key={c} value={c}>{c}</option>
                            ))}
                          </select>
                          <select
                            value={filterOp}
                            onChange={(e) => setFilterOp(e.target.value)}
                            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg p-1.5"
                          >
                            <option value="==">==</option>
                            <option value="!=">!=</option>
                            <option value=">">&gt;</option>
                            <option value="<">&lt;</option>
                            <option value="contains">contains</option>
                          </select>
                          <input
                            type="text"
                            value={filterVal}
                            onChange={(e) => setFilterVal(e.target.value)}
                            placeholder="Value"
                            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg p-1.5"
                          />
                        </div>
                        <button
                          onClick={() => handleExecuteOperation([{ operation: 'filter_rows', params: { column: selectedCol, operator: filterOp, value: filterVal } }])}
                          disabled={isTransforming || !filterVal}
                          className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold cursor-pointer disabled:opacity-40"
                        >
                          Apply Filter
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Summary Statistics Table */}
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                    <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                      Descriptive Statistics
                    </h3>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs font-mono">
                        <thead className="text-slate-400 border-b border-slate-800">
                          <tr>
                            <th className="p-2">Metric Column</th>
                            <th className="p-2">Count</th>
                            <th className="p-2">Mean</th>
                            <th className="p-2">Median</th>
                            <th className="p-2">Min</th>
                            <th className="p-2">Max</th>
                            <th className="p-2">Std</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60">
                          {Object.entries(selectedDataset.profile.statistics).map(([col, s]) => (
                            <tr key={col}>
                              <td className="p-2 font-bold text-indigo-300">{col}</td>
                              <td className="p-2 text-slate-300">{s.count}</td>
                              <td className="p-2 text-slate-300">{s.mean}</td>
                              <td className="p-2 text-slate-300">{s.median}</td>
                              <td className="p-2 text-slate-300">{s.min}</td>
                              <td className="p-2 text-slate-300">{s.max}</td>
                              <td className="p-2 text-slate-300">{s.std}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 3: Visual Charts */}
              {activeTab === 'charts' && (
                <div className="flex-1 overflow-y-auto pt-3 space-y-4">
                  {selectedDataset.profile.charts.length === 0 ? (
                    <div className="p-8 text-center text-slate-500">
                      <TrendingUp className="w-8 h-8 mx-auto text-slate-600 mb-2" />
                      <p>No automatic charts could be computed for this schema.</p>
                    </div>
                  ) : (
                    selectedDataset.profile.charts.map((chart, idx) => (
                      <div key={idx} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-bold text-slate-200">{chart.title}</h4>
                          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                            {chart.chart_type}
                          </span>
                        </div>

                        {/* Visual Bar representation */}
                        <div className="space-y-2 pt-2">
                          {chart.labels.map((lbl, i) => {
                            const val = chart.values[i] || 0;
                            const maxVal = Math.max(...chart.values, 1);
                            const pct = Math.max(8, Math.round((val / maxVal) * 100));
                            return (
                              <div key={i} className="space-y-1">
                                <div className="flex items-center justify-between text-[11px] text-slate-300">
                                  <span>{lbl}</span>
                                  <span className="font-mono text-indigo-400 font-semibold">{val.toLocaleString()}</span>
                                </div>
                                <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden">
                                  <div
                                    className="bg-gradient-to-r from-emerald-500 to-indigo-500 h-full rounded-full transition-all duration-500"
                                    style={{ width: `${pct}%` }}
                                  />
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* Tab 4: AI Report */}
              {activeTab === 'report' && (
                <div className="flex-1 overflow-y-auto p-4">
                  {reportText ? (
                    <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-200 leading-relaxed whitespace-pre-wrap">
                      {reportText}
                    </div>
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
                      <Sparkles className="w-8 h-8 text-indigo-400 mb-2" />
                      <p className="text-xs font-semibold text-slate-300">
                        Synthesize Executive Data Report
                      </p>
                      <p className="text-[11px] text-slate-500 mt-1 max-w-sm">
                        Generates high-level briefing on data health, statistical anomalies, and operational insights.
                      </p>
                      <button
                        onClick={handleGenerateReport}
                        disabled={isLoadingReport}
                        className="mt-4 flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold cursor-pointer"
                      >
                        <span>Generate Business Briefing</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-500">
              <FileSpreadsheet className="w-12 h-12 mx-auto text-slate-700 mb-3" />
              <h3 className="text-sm font-semibold text-slate-300">No Dataset Selected</h3>
              <p className="text-xs text-slate-500 mt-1">
                Select an existing dataset from the left or upload a CSV or XLSX file.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
