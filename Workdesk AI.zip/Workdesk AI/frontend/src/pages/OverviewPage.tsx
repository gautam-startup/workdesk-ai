import React, { useState } from 'react';
import {
  Layers,
  Terminal,
  Database,
  ShieldCheck,
  Send,
  Code2,
  Cpu,
  CheckCircle2,
  Copy,
  Check,
  ExternalLink,
} from 'lucide-react';
import { HealthWidget } from '../components/common/HealthWidget';
import { PhaseChecklist } from '../components/common/PhaseChecklist';
import { HealthProbeResult } from '../api/health';
import { apiClient } from '../api/client';

interface OverviewPageProps {
  health: HealthProbeResult | null;
  isCheckingHealth: boolean;
  onRefreshHealth: () => void;
  apiBaseUrl: string;
}

export const OverviewPage: React.FC<OverviewPageProps> = ({
  health,
  isCheckingHealth,
  onRefreshHealth,
  apiBaseUrl,
}) => {
  const [testEndpoint, setTestEndpoint] = useState('/health');
  const [testResult, setTestResult] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  const handleTestEndpoint = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsTesting(true);
    setTestResult(null);

    try {
      const res = await apiClient.get<unknown>(testEndpoint);
      setTestResult(JSON.stringify(res, null, 2));
    } catch (err: unknown) {
      setTestResult(JSON.stringify(err, null, 2));
    } finally {
      setIsTesting(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Hero Welcome Banner */}
      <div className="rounded-3xl bg-gradient-to-br from-indigo-900/30 via-slate-900 to-slate-900 border border-indigo-500/20 p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold mb-4">
            <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
            Phase 1 Foundation Initialized
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100 tracking-tight leading-tight">
            WorkDesk <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-sky-300">AI</span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 mt-2 font-medium">
            "One affordable AI workspace for everyday work."
          </p>

          <p className="text-xs sm:text-sm text-slate-400 mt-2 leading-relaxed">
            Phase 1 establishes the production-grade foundation: separate <code className="text-indigo-300 font-mono">frontend/</code> and <code className="text-indigo-300 font-mono">backend/</code> architectures, FastAPI REST API, PostgreSQL database abstraction with SQLAlchemy & Alembic, CORS security controls, structured error handling, and containerized Docker setup.
          </p>
        </div>
      </div>

      {/* Live Health & Probes Widget */}
      <HealthWidget
        health={health}
        isChecking={isCheckingHealth}
        onRefresh={onRefreshHealth}
        apiBaseUrl={apiBaseUrl}
      />

      {/* Interactive API Tester */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800/80">
          <div>
            <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              <Terminal className="w-4 h-4 text-indigo-400" />
              Interactive REST Client Probe
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Verify CORS, request correlation IDs, and response payloads directly from the frontend abstraction.
            </p>
          </div>
        </div>

        <form onSubmit={handleTestEndpoint} className="mt-4 flex flex-col sm:flex-row gap-3">
          <div className="flex-1 flex items-center bg-slate-950 border border-slate-800 rounded-xl px-3 focus-within:border-indigo-500/50 transition-colors">
            <span className="text-xs font-mono text-slate-500">{apiBaseUrl}</span>
            <input
              type="text"
              value={testEndpoint}
              onChange={(e) => setTestEndpoint(e.target.value)}
              placeholder="/health"
              className="w-full bg-transparent px-2 py-2 text-xs font-mono text-indigo-300 focus:outline-none"
            />
          </div>

          <button
            type="submit"
            disabled={isTesting}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/20 transition-all cursor-pointer disabled:opacity-50"
          >
            <Send className="w-3.5 h-3.5" />
            {isTesting ? 'Sending...' : 'Send Request'}
          </button>
        </form>

        {testResult && (
          <div className="mt-4">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
              <span className="font-mono">Response Payload</span>
              <button
                onClick={() => copyToClipboard(testResult, 'test-res')}
                className="flex items-center gap-1 hover:text-slate-200"
              >
                {copiedCmd === 'test-res' ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
                <span>{copiedCmd === 'test-res' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono text-emerald-300 overflow-x-auto max-h-60">
              {testResult}
            </pre>
          </div>
        )}
      </div>

      {/* Project Structure & Verification Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Backend Highlights */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center gap-2 text-slate-100 font-semibold mb-3">
            <Code2 className="w-5 h-5 text-indigo-400" />
            <h3>Backend Architecture (FastAPI & PostgreSQL)</h3>
          </div>
          <ul className="space-y-2 text-xs text-slate-300">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>GET /api/v1/health</strong> with operational state, environment, and DB connectivity probe.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>PostgreSQL Integration</strong> via SQLAlchemy 2.0 (asyncpg async engine + psycopg2 sync engine).
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Alembic Migrations</strong> pre-configured with script templates and sync engine connection.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>CORS Security</strong> configured for localhost:3000 and 5173 with credentials and headers.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Structured Error Handling</strong> with standard error codes and request IDs.
              </span>
            </li>
          </ul>
        </div>

        {/* Frontend Highlights */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center gap-2 text-slate-100 font-semibold mb-3">
            <Layers className="w-5 h-5 text-sky-400" />
            <h3>Frontend Architecture (React 19 & Vite)</h3>
          </div>
          <ul className="space-y-2 text-xs text-slate-300">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Typed API Client</strong> (<code className="text-indigo-300 font-mono">apiClient</code>) with error wrapping and logging.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Modern SaaS Layout</strong> with header, responsive sidebar, error boundary, and health status indicators.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Tailwind CSS v4</strong> with accessible dark theme palette and zero-pill typographic discipline.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Extensible Domain Contracts</strong> prepared for Phase 2 auth, subscriptions, and AI agent routers.
              </span>
            </li>
          </ul>
        </div>
      </div>

      {/* Phase Roadmap Component */}
      <PhaseChecklist />
    </div>
  );
};
