import React, { useState, useEffect, useRef } from 'react';
import {
  FileText,
  Upload,
  Search,
  Trash2,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  RefreshCw,
  Send,
  MessageSquare,
  ListOrdered,
  CheckSquare,
  BookOpen,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { documentsApi, DocumentItem, DocumentAskResponse } from '../api/documents';
import { useAuth } from '../context/AuthContext';

interface ChatMessage {
  id: string;
  sender: 'user' | 'agent';
  text: string;
  citations?: { page: number; snippet: string; relevance_score: number }[];
  pages?: number[];
  timestamp: string;
}

export const DocumentsPage: React.FC = () => {
  const { user } = useAuth();
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [selectedDoc, setSelectedDoc] = useState<DocumentItem | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // Chat & Q&A state
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [questionInput, setQuestionInput] = useState('');
  const [isAsking, setIsAsking] = useState(false);
  const [activeTab, setActiveTab] = useState<'qa' | 'summary' | 'preview'>('qa');

  // Summary state
  const [summaryData, setSummaryData] = useState<string | null>(null);
  const [isLoadingSummary, setIsLoadingSummary] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadDocuments();
  }, []);

  const loadDocuments = async () => {
    setIsLoading(true);
    try {
      const list = await documentsApi.list();
      setDocuments(list);
      if (list.length > 0 && !selectedDoc) {
        setSelectedDoc(list[0]);
      }
    } catch (err) {
      console.error('Failed to load documents:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit (< 25MB)
    if (file.size > 25 * 1024 * 1024) {
      setUploadError('File size exceeds the 25MB limit.');
      return;
    }

    setIsUploading(true);
    setUploadError(null);

    try {
      const newDoc = await documentsApi.upload(file);
      setDocuments((prev) => [newDoc, ...prev]);
      setSelectedDoc(newDoc);
      // Reset chat
      setChatMessages([]);
      setSummaryData(null);
    } catch (err: unknown) {
      const msg =
        err && typeof err === 'object' && 'message' in err
          ? String((err as { message: string }).message)
          : 'Failed to upload document.';
      setUploadError(msg);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDelete = async (docId: string) => {
    if (!window.confirm('Are you sure you want to delete this document and its vector index?')) {
      return;
    }
    try {
      await documentsApi.delete(docId);
      const remaining = documents.filter((d) => d.id !== docId);
      setDocuments(remaining);
      if (selectedDoc?.id === docId) {
        setSelectedDoc(remaining[0] || null);
        setChatMessages([]);
        setSummaryData(null);
      }
    } catch (err) {
      console.error('Failed to delete document:', err);
    }
  };

  const handleSendQuestion = async (overrideQuestion?: string) => {
    const query = overrideQuestion || questionInput;
    if (!query.trim() || !selectedDoc || isAsking) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, userMsg]);
    if (!overrideQuestion) setQuestionInput('');
    setIsAsking(true);

    try {
      const res: DocumentAskResponse = await documentsApi.ask(selectedDoc.id, query, 'qa');
      const agentMsg: ChatMessage = {
        id: `agent-${Date.now()}`,
        sender: 'agent',
        text: res.answer,
        citations: res.citations,
        pages: res.pages_referenced,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setChatMessages((prev) => [...prev, agentMsg]);
    } catch (err: unknown) {
      const errorMsg: ChatMessage = {
        id: `agent-err-${Date.now()}`,
        sender: 'agent',
        text: 'Sorry, I encountered an issue retrieving relevant passages for your query.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setChatMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsAsking(false);
    }
  };

  const handleGenerateSummary = async () => {
    if (!selectedDoc || isLoadingSummary) return;
    setIsLoadingSummary(true);
    try {
      const res = await documentsApi.ask(
        selectedDoc.id,
        'Summarize this document with executive summary, key points, and action items.',
        'summary'
      );
      setSummaryData(res.answer);
      setActiveTab('summary');
    } catch (err) {
      console.error('Summary generation error:', err);
    } finally {
      setIsLoadingSummary(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs uppercase font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                Phase 4 Complete
              </span>
              <span className="text-xs text-slate-400">
                Deterministic Extraction • Semantic RAG • Prompt-Injection Guarded
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-100">
              Document Intelligence Agent
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Upload invoices, contracts, receipts, or research files. Ask questions with page-level citations.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".pdf,.docx,.txt,.png,.jpg,.jpeg"
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/20 transition-all cursor-pointer disabled:opacity-50"
            >
              {isUploading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Extracting & Indexing...</span>
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  <span>Upload Document</span>
                </>
              )}
            </button>
          </div>
        </div>

        {uploadError && (
          <div className="mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-xs text-red-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{uploadError}</span>
          </div>
        )}
      </div>

      {/* Main Studio Grid: Left Document Inventory / Right Interactive Viewer & Chat */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Document Inventory (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Your Documents ({documents.length})
              </h3>
              <button
                onClick={loadDocuments}
                title="Refresh inventory"
                className="text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {/* Document Cards */}
            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {documents.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500">
                  <BookOpen className="w-8 h-8 mx-auto text-slate-600 mb-2" />
                  <p>No documents uploaded yet.</p>
                  <p className="text-[11px] text-slate-600 mt-1">
                    Upload PDF, DOCX, TXT, or images to begin.
                  </p>
                </div>
              ) : (
                documents.map((doc) => {
                  const isSelected = selectedDoc?.id === doc.id;
                  return (
                    <div
                      key={doc.id}
                      onClick={() => {
                        setSelectedDoc(doc);
                        setChatMessages([]);
                        setSummaryData(null);
                      }}
                      className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-indigo-600/10 border-indigo-500/40 text-slate-100 shadow-md'
                          : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-800/40 text-slate-300'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2 truncate">
                          <FileText className={`w-4 h-4 shrink-0 ${isSelected ? 'text-indigo-400' : 'text-slate-400'}`} />
                          <span className="font-semibold truncate">{doc.filename}</span>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDelete(doc.id);
                          }}
                          title="Delete document"
                          className="text-slate-500 hover:text-red-400 transition-colors p-0.5"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
                        <span>{doc.total_pages} pg • {formatFileSize(doc.file_size)}</span>
                        <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px]">
                          {doc.total_chunks} chunks indexed
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Supported Formats Info Card */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 text-xs text-slate-400 space-y-2">
            <div className="flex items-center gap-2 text-slate-200 font-semibold">
              <FileCheck className="w-4 h-4 text-emerald-400" />
              <span>Supported Multi-Modal Formats</span>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-400">
              PDF, DOCX, TXT, PNG, JPG/JPEG. Files are indexed into deterministic vector embeddings with page citations.
            </p>
          </div>
        </div>

        {/* Right Column: Document Viewer & Q&A Chat (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {selectedDoc ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col h-[650px]">
              {/* Header with Title & Action Controls */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800 shrink-0">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-slate-100 truncate max-w-sm">
                      {selectedDoc.filename}
                    </h2>
                    <p className="text-[11px] text-slate-400">
                      {selectedDoc.total_pages} Pages • {selectedDoc.total_chunks} Semantic Chunks • {formatFileSize(selectedDoc.file_size)}
                    </p>
                  </div>
                </div>

                {/* Quick RAG Triggers */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleGenerateSummary}
                    disabled={isLoadingSummary}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-medium cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className={`w-3.5 h-3.5 text-indigo-400 ${isLoadingSummary ? 'animate-spin' : ''}`} />
                    <span>Executive Briefing</span>
                  </button>
                </div>
              </div>

              {/* View Switcher Tabs */}
              <div className="flex items-center gap-1 pt-3 pb-2 border-b border-slate-800 shrink-0">
                <button
                  onClick={() => setActiveTab('qa')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                    activeTab === 'qa'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Interactive Q&A</span>
                </button>

                <button
                  onClick={() => setActiveTab('summary')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                    activeTab === 'summary'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  <ListOrdered className="w-3.5 h-3.5" />
                  <span>Executive Summary</span>
                </button>

                <button
                  onClick={() => setActiveTab('preview')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                    activeTab === 'preview'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Text Preview</span>
                </button>
              </div>

              {/* Tab 1: Interactive Q&A (RAG) */}
              {activeTab === 'qa' && (
                <div className="flex-1 flex flex-col min-h-0 pt-3">
                  {/* Messages Area */}
                  <div className="flex-1 overflow-y-auto space-y-3 pr-2">
                    {chatMessages.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
                        <MessageSquare className="w-8 h-8 text-slate-600 mb-2" />
                        <p className="text-xs font-semibold text-slate-300">
                          Ask anything about this document
                        </p>
                        <p className="text-[11px] text-slate-500 mt-1 max-w-sm">
                          Queries are matched semantically against indexed passages and verified with page citations.
                        </p>

                        {/* Quick Prompts */}
                        <div className="flex flex-wrap gap-2 mt-4 justify-center">
                          <button
                            onClick={() => handleSendQuestion('What are the key obligations and payment terms?')}
                            className="text-[11px] px-2.5 py-1 bg-slate-800/80 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-700 cursor-pointer"
                          >
                            "What are the payment terms?"
                          </button>
                          <button
                            onClick={() => handleSendQuestion('What are the termination conditions?')}
                            className="text-[11px] px-2.5 py-1 bg-slate-800/80 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-700 cursor-pointer"
                          >
                            "What are the termination clauses?"
                          </button>
                          <button
                            onClick={() => handleSendQuestion('Extract all due dates and deadlines.')}
                            className="text-[11px] px-2.5 py-1 bg-slate-800/80 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-700 cursor-pointer"
                          >
                            "List dates and deadlines"
                          </button>
                        </div>
                      </div>
                    ) : (
                      chatMessages.map((msg) => (
                        <div
                          key={msg.id}
                          className={`flex flex-col ${
                            msg.sender === 'user' ? 'items-end' : 'items-start'
                          }`}
                        >
                          <div
                            className={`max-w-[85%] rounded-2xl p-3.5 text-xs leading-relaxed ${
                              msg.sender === 'user'
                                ? 'bg-indigo-600 text-white shadow-md'
                                : 'bg-slate-950/80 border border-slate-800 text-slate-200'
                            }`}
                          >
                            <p className="whitespace-pre-wrap">{msg.text}</p>

                            {/* Citations Card if present */}
                            {msg.citations && msg.citations.length > 0 && (
                              <div className="mt-3 pt-2 border-t border-slate-800/80 space-y-1.5">
                                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400">
                                  Verified Source Citations:
                                </span>
                                <div className="space-y-1">
                                  {msg.citations.map((c, i) => (
                                    <div
                                      key={i}
                                      className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-slate-300"
                                    >
                                      <span className="font-semibold text-indigo-300 mr-1.5">
                                        [Page {c.page}]
                                      </span>
                                      <span className="text-slate-400">"{c.snippet}"</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-500 mt-1 px-1">
                            {msg.timestamp}
                          </span>
                        </div>
                      ))
                    )}
                    {isAsking && (
                      <div className="flex items-center gap-2 p-3 bg-slate-950/80 rounded-2xl border border-slate-800 text-xs text-indigo-300 w-fit">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Searching indexed vector chunks & synthesizing answer...</span>
                      </div>
                    )}
                  </div>

                  {/* Input Box */}
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      handleSendQuestion();
                    }}
                    className="pt-3 border-t border-slate-800 shrink-0"
                  >
                    <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 focus-within:border-indigo-500/60 focus-within:ring-1 focus-within:ring-indigo-500/40">
                      <input
                        type="text"
                        value={questionInput}
                        onChange={(e) => setQuestionInput(e.target.value)}
                        placeholder={`Ask anything about ${selectedDoc.filename}...`}
                        className="flex-1 bg-transparent text-xs text-slate-200 placeholder-slate-500 focus:outline-none"
                      />
                      <button
                        type="submit"
                        disabled={!questionInput.trim() || isAsking}
                        className="p-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors cursor-pointer disabled:opacity-40"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Tab 2: Executive Summary & Action Items */}
              {activeTab === 'summary' && (
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {summaryData ? (
                    <div className="space-y-4">
                      <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-200 leading-relaxed whitespace-pre-wrap">
                        {summaryData}
                      </div>
                    </div>
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
                      <Sparkles className="w-8 h-8 text-indigo-400 mb-2" />
                      <p className="text-xs font-semibold text-slate-300">
                        Generate structured executive summary
                      </p>
                      <p className="text-[11px] text-slate-500 mt-1 max-w-sm">
                        Extracts high-level summary, bulleted key takeaways, and action items with deadlines.
                      </p>
                      <button
                        onClick={handleGenerateSummary}
                        disabled={isLoadingSummary}
                        className="mt-4 flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold cursor-pointer"
                      >
                        <span>Analyze & Generate Briefing</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Tab 3: Text Preview */}
              {activeTab === 'preview' && (
                <div className="flex-1 overflow-y-auto p-4">
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-slate-300 leading-relaxed whitespace-pre-wrap">
                    {selectedDoc.text_preview || 'Text extraction complete. Ready for vector query.'}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-500">
              <FileText className="w-12 h-12 mx-auto text-slate-700 mb-3" />
              <h3 className="text-sm font-semibold text-slate-300">No Document Selected</h3>
              <p className="text-xs text-slate-500 mt-1">
                Select an existing document from the left or upload a new file.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
