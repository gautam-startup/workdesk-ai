import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  FileText,
  BarChart3,
  PenTool,
  Paperclip,
  ArrowRight,
  ShieldCheck,
  User as UserIcon,
  CreditCard,
  Key,
  Users,
  CheckCircle2,
  RefreshCw,
  LogOut,
  Copy,
  Check,
  AlertCircle,
  Activity,
  Layers,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { authApi } from '../api/auth';
import { agentsApi, AgentRunResponse, ExecutionStep } from '../api/agents';
import { User } from '../types/auth';

export const DashboardPage: React.FC = () => {
  const { user, token, logout, refreshUser } = useAuth();
  const [taskPrompt, setTaskPrompt] = useState('');
  const [selectedMode, setSelectedMode] = useState<'auto' | 'document' | 'data' | 'writer'>('auto');
  const [adminUsers, setAdminUsers] = useState<User[]>([]);
  const [isLoadingAdminUsers, setIsLoadingAdminUsers] = useState(false);
  const [adminError, setAdminError] = useState<string | null>(null);
  const [showTokenDetails, setShowTokenDetails] = useState(false);

  // Agent Execution state
  const [isDispatching, setIsDispatching] = useState(false);
  const [executionResult, setExecutionResult] = useState<AgentRunResponse | null>(null);
  const [executionError, setExecutionError] = useState<string | null>(null);
  const [estimatedCost, setEstimatedCost] = useState<number>(1);
  const [copiedOutput, setCopiedOutput] = useState(false);

  useEffect(() => {
    if (user?.role === 'admin') {
      loadAdminUsers();
    }
  }, [user]);

  // Recalculate estimated credits on prompt change
  useEffect(() => {
    const updateEstimate = async () => {
      if (!taskPrompt.trim()) {
        setEstimatedCost(1);
        return;
      }
      try {
        const est = await agentsApi.estimateCredits(taskPrompt);
        setEstimatedCost(est.estimated_credits);
      } catch {
        setEstimatedCost(1);
      }
    };
    updateEstimate();
  }, [taskPrompt]);

  const loadAdminUsers = async () => {
    setIsLoadingAdminUsers(true);
    setAdminError(null);
    try {
      const users = await authApi.getAdminUsers();
      setAdminUsers(users);
    } catch {
      setAdminError('Could not retrieve admin user directory.');
    } finally {
      setIsLoadingAdminUsers(false);
    }
  };

  const handleDispatch = async () => {
    if (!taskPrompt.trim() || isDispatching) return;
    setIsDispatching(true);
    setExecutionError(null);
    setExecutionResult(null);

    try {
      const result = await agentsApi.runAgent(taskPrompt, selectedMode);
      setExecutionResult(result);
      if (user) {
        user.credit_balance = result.remaining_credits;
      }
      await refreshUser();
    } catch (err: unknown) {
      const msg =
        err && typeof err === 'object' && 'message' in err
          ? String((err as { message: string }).message)
          : 'Agent workflow execution failed. Please check credits.';
      setExecutionError(msg);
    } finally {
      setIsDispatching(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedOutput(true);
    setTimeout(() => setCopiedOutput(false), 2000);
  };

  const quickActions = [
    {
      title: 'Analyze PDF Document',
      desc: 'Extract key points, Q&A, and citation-backed summaries',
      icon: FileText,
      mode: 'document' as const,
      color: 'text-indigo-400',
      sample: 'Analyze this invoice PDF and find total amount and payment details',
    },
    {
      title: 'Analyze Excel / CSV Data',
      desc: 'Deterministic deduplication, profiling, and trend charts',
      icon: BarChart3,
      mode: 'data' as const,
      color: 'text-emerald-400',
      sample: 'Clean this CSV dataset, detect missing values, and find duplicate rows',
    },
    {
      title: 'Professional Writer',
      desc: 'Draft messages, emails, proposals, and WhatsApp copy',
      icon: PenTool,
      mode: 'writer' as const,
      color: 'text-sky-400',
      sample: 'Write a concise, professional follow-up email to a prospective client',
    },
    {
      title: 'Supervisor Auto-Routing',
      desc: 'Intelligent multi-step task planning across tools',
      icon: Sparkles,
      mode: 'auto' as const,
      color: 'text-purple-400',
      sample: 'Compare these two contracts and summarize key differences',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Welcome Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs uppercase font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                Protected Workspace
              </span>
              <span
                className={`text-xs uppercase font-bold px-2.5 py-0.5 rounded-full border ${
                  user?.role === 'admin'
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                    : 'bg-slate-800 text-slate-300 border-slate-700'
                }`}
              >
                Role: {user?.role.toUpperCase()}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-100">
              Welcome back, {user?.full_name || 'User'}!
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Signed in as <code className="text-indigo-300 font-mono">{user?.email}</code>
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => logout()}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800/80 hover:bg-red-500/10 hover:text-red-300 hover:border-red-500/30 border border-slate-700 rounded-xl text-xs font-semibold text-slate-300 transition-all cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Log Out</span>
            </button>
          </div>
        </div>

        {/* User Quota & Plan Summary Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 pt-6 border-t border-slate-800">
          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span>Available Credits</span>
              <CreditCard className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="text-2xl font-bold text-indigo-300">
              {user?.credit_balance ?? 10}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Replenishes monthly on active plan
            </p>
          </div>

          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span>Current Subscription</span>
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-lg font-bold text-slate-200">
              {user?.plan_name || 'Free Starter'}
            </div>
            <p className="text-[11px] text-slate-500 mt-1 font-mono">
              Status: Active (₹0 / month)
            </p>
          </div>

          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span>Security Token</span>
              <Key className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-sm font-semibold text-slate-200 truncate">
              Bearer HS256 JWT
            </div>
            <button
              onClick={() => setShowTokenDetails(!showTokenDetails)}
              className="text-[11px] text-indigo-400 hover:text-indigo-300 font-medium mt-1 cursor-pointer block"
            >
              {showTokenDetails ? 'Hide Token Details' : 'Inspect Token Payload'}
            </button>
          </div>
        </div>

        {/* Token Details Inspector */}
        {showTokenDetails && (
          <div className="mt-4 p-4 bg-slate-950 rounded-2xl border border-slate-800 text-xs font-mono text-slate-300">
            <div className="text-indigo-300 font-semibold mb-2">Authenticated Session Details:</div>
            <pre className="text-[11px] text-slate-400 overflow-x-auto">
              {JSON.stringify({ user, token_sample: token?.slice(0, 36) + '...' }, null, 2)}
            </pre>
          </div>
        )}
      </div>

      {/* Main Workspace Input Interface */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="text-center max-w-xl mx-auto mb-6">
          <h2 className="text-xl font-bold text-slate-100">How can I help you today?</h2>
          <p className="text-xs text-slate-400 mt-1">
            Describe your task in natural language. WorkDesk AI coordinates the appropriate specialist agent and tools.
          </p>
        </div>

        {/* Mode Selector Pills */}
        <div className="flex items-center justify-center gap-2 mb-4">
          {(['auto', 'document', 'data', 'writer'] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => setSelectedMode(mode)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all cursor-pointer ${
                selectedMode === mode
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'bg-slate-800/60 text-slate-400 hover:text-slate-200'
              }`}
            >
              {mode === 'auto' ? '⚡ Auto Supervisor' : mode}
            </button>
          ))}
        </div>

        {/* Unified Prompt Input Box */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3 focus-within:border-indigo-500/60 focus-within:ring-1 focus-within:ring-indigo-500/40 transition-all shadow-inner">
          <textarea
            rows={3}
            value={taskPrompt}
            onChange={(e) => setTaskPrompt(e.target.value)}
            placeholder="e.g., Analyze these 50 invoices, detect duplicates, find missing fields, and draft a summary report..."
            className="w-full bg-transparent text-xs text-slate-200 placeholder-slate-500 resize-none focus:outline-none leading-relaxed"
          />

          <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
            <div className="flex items-center gap-2">
              <button
                type="button"
                className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 rounded-xl text-xs transition-colors cursor-pointer"
                title="Attach PDF, Excel, CSV, or DOCX files"
              >
                <Paperclip className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Attach Files</span>
              </button>
              <span className="text-[11px] text-indigo-400 font-medium">
                Estimated Cost: ~{estimatedCost} credit{estimatedCost > 1 ? 's' : ''}
              </span>
            </div>

            <button
              type="button"
              onClick={handleDispatch}
              disabled={!taskPrompt.trim() || isDispatching}
              className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/20 transition-all cursor-pointer disabled:opacity-50"
            >
              {isDispatching ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Orchestrating...</span>
                </>
              ) : (
                <>
                  <span>Dispatch Agent</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>
        </div>

        {/* Error Alert */}
        {executionError && (
          <div className="mt-4 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-start gap-3 text-xs text-red-300">
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-red-200">Execution Error</div>
              <p className="mt-0.5">{executionError}</p>
            </div>
          </div>
        )}

        {/* Execution Stepper & Results Card */}
        {executionResult && (
          <div className="mt-6 p-6 rounded-2xl bg-slate-950/80 border border-slate-800 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Execution Complete
                </span>
                <span className="text-xs text-slate-400">
                  Agent: <strong className="text-indigo-300 capitalize">{executionResult.selected_agent}</strong>
                </span>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                Deducted: <span className="text-indigo-400 font-semibold">{executionResult.credits_cost}</span> credits (Balance: {executionResult.remaining_credits})
              </span>
            </div>

            {/* Safe Execution Milestones */}
            <div>
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
                Execution Milestones
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {executionResult.safe_steps.map((step) => (
                  <div
                    key={step.step_number}
                    className="p-3 bg-slate-900/90 rounded-xl border border-slate-800/80 text-xs"
                  >
                    <div className="flex items-center gap-1.5 text-emerald-400 font-medium mb-1">
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{step.name}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      {step.safe_detail || 'Completed within deterministic constraints.'}
                    </p>
                    <span className="text-[10px] text-slate-500 font-mono mt-1 block">
                      {step.duration_ms}ms
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Final Formatted Result */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  Result
                </h3>
                <button
                  onClick={() => copyToClipboard(executionResult.final_output)}
                  className="flex items-center gap-1 text-xs text-indigo-400 hover:text-indigo-300 font-medium cursor-pointer"
                >
                  {copiedOutput ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedOutput ? 'Copied' : 'Copy Result'}</span>
                </button>
              </div>
              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 text-xs text-slate-200 leading-relaxed whitespace-pre-wrap font-sans">
                {executionResult.final_output}
              </div>
            </div>
          </div>
        )}

        {/* Quick Actions Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          {quickActions.map((qa) => {
            const Icon = qa.icon;
            return (
              <button
                key={qa.title}
                onClick={() => {
                  setSelectedMode(qa.mode);
                  setTaskPrompt(qa.sample);
                }}
                className="text-left p-4 rounded-2xl bg-slate-950/60 hover:bg-slate-800/50 border border-slate-800 hover:border-slate-700 transition-all group cursor-pointer"
              >
                <div className={`w-8 h-8 rounded-xl bg-slate-900 flex items-center justify-center ${qa.color} mb-3 group-hover:scale-105 transition-transform`}>
                  <Icon className="w-4 h-4" />
                </div>
                <h3 className="text-xs font-semibold text-slate-200 group-hover:text-indigo-300 transition-colors">
                  {qa.title}
                </h3>
                <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                  {qa.desc}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Admin RBAC Section (Shown only if role === 'admin') */}
      {user?.role === 'admin' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-emerald-400" />
              <div>
                <h3 className="text-base font-bold text-slate-100">
                  Admin User Directory (Role-Based Access Control)
                </h3>
                <p className="text-xs text-slate-400">
                  Protected endpoint: <code className="text-indigo-300 font-mono">GET /api/v1/auth/admin/users</code>
                </p>
              </div>
            </div>
            <button
              onClick={loadAdminUsers}
              disabled={isLoadingAdminUsers}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-medium cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingAdminUsers ? 'animate-spin' : ''}`} />
              <span>Refresh Users</span>
            </button>
          </div>

          {adminError ? (
            <div className="p-4 mt-4 bg-red-500/10 border border-red-500/20 rounded-xl text-xs text-red-300">
              {adminError}
            </div>
          ) : (
            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="p-3 rounded-l-xl">User</th>
                    <th className="p-3">Role</th>
                    <th className="p-3">Plan</th>
                    <th className="p-3">Credits</th>
                    <th className="p-3 rounded-r-xl">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {adminUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-800/30">
                      <td className="p-3">
                        <div className="font-semibold text-slate-200">{u.full_name}</div>
                        <div className="text-[11px] text-slate-500 font-mono">{u.email}</div>
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            u.role === 'admin'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {u.role}
                        </span>
                      </td>
                      <td className="p-3 text-slate-300">{u.plan_name}</td>
                      <td className="p-3 font-semibold text-indigo-300">{u.credit_balance}</td>
                      <td className="p-3">
                        <span className="flex items-center gap-1 text-emerald-400 text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Active</span>
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
