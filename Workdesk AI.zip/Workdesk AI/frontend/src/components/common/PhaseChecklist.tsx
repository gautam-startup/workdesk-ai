import React from 'react';
import { CheckCircle2, Clock, ArrowRight, ShieldCheck, Cpu, Database, CreditCard, FileText } from 'lucide-react';
import { PhaseStep } from '../../types';

const PHASES: PhaseStep[] = [
  {
    id: 1,
    title: 'Phase 1: Project Foundation & Architecture',
    status: 'completed',
    description:
      'Separate frontend/backend directories, FastAPI structure, PostgreSQL config, Alembic migrations, health probes, CORS, error handling, structured logging, and Docker setup.',
    modules: ['FastAPI Core', 'SQLAlchemy 2.0', 'Health Probes', 'CORS & Logging', 'Vite & React Setup', 'Docker Compose'],
  },
  {
    id: 2,
    title: 'Phase 2: Authentication, Subscriptions & Credit Ledger',
    status: 'completed',
    description:
      'JWT authentication, PostgreSQL normalized user schema, role-based authorization (User/Admin), session tokens, and credit quota checks.',
    modules: ['JWT Auth & RBAC', 'Credit Ledger', 'PostgreSQL Models', 'Plans (Free/Starter/Pro/Biz)'],
  },
  {
    id: 3,
    title: 'Phase 3: Supervisor Agent & Smart LLM Routing Layer',
    status: 'completed',
    description:
      'Supervisor intent classifier, LLM Provider Abstraction (Mistral, Gemini, Groq), provider fallback, explicit tool permissions gatekeeper, and safe execution steps.',
    modules: ['Supervisor Agent', 'LLM Provider Abstraction', 'Tool Permissions', 'Provider Fallback', 'Safe Execution Steps'],
  },
  {
    id: 4,
    title: 'Phase 4: Document Intelligence Agent & RAG Pipeline',
    status: 'completed',
    description:
      'Deterministic PDF/DOCX/TXT/Image extraction, prompt-injection defense, semantic chunking, vector storage, and citation-backed Q&A.',
    modules: ['PDF & DOCX Extractor', 'Prompt Defense', 'Vector Embeddings', 'Page Citations', 'Executive Briefing'],
  },
  {
    id: 5,
    title: 'Phase 5: Data Analysis Agent (Deterministic Pandas)',
    status: 'completed',
    description:
      'Deterministic Pandas tabular analysis, duplicate row detection, column type profiling, safe transformations, and report generator.',
    modules: ['Pandas Profiler', 'Duplicate Detection', 'Safe Transforms', 'Chart Generator', 'Cleaned CSV Download'],
  },
  {
    id: 6,
    title: 'Phase 6: Writer Agent & Tone Transformation Engine',
    status: 'planned',
    description:
      'Professional messaging, emails, proposals, WhatsApp-style drafts, and tone transformation (Professional, Concise, Friendly, Persuasive).',
    modules: ['Tone Selector', 'Template System', 'Grammar Refinement', 'Multi-format Export'],
  },
  {
    id: 7,
    title: 'Phase 7: Admin Dashboard, Production Hardening & E2E Tests',
    status: 'planned',
    description:
      'Telemetry dashboard, credit consumption logs, model rate management, unit/integration test suites, and Vercel/Render deployment setups.',
    modules: ['Admin Telemetry', 'Audit Logging', 'Integration Tests', 'Production Hardening'],
  },
];

export const PhaseChecklist: React.FC = () => {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
      <div className="flex items-center justify-between pb-6 border-b border-slate-800/80">
        <div>
          <h2 className="text-lg font-semibold text-slate-100">
            WorkDesk AI — Production Roadmap & Milestones
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Modular phase-by-phase execution architecture. Phase 1 foundation complete and verified.
          </p>
        </div>
        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold">
          <ShieldCheck className="w-4 h-4" />
          <span>Phase 1 Verified</span>
        </div>
      </div>

      <div className="space-y-4 mt-6">
        {PHASES.map((phase) => {
          const isCurrent = phase.id === 1;

          return (
            <div
              key={phase.id}
              className={`p-4 rounded-xl border transition-all ${
                isCurrent
                  ? 'bg-slate-950/80 border-indigo-500/40 ring-1 ring-indigo-500/20 shadow-lg shadow-indigo-500/5'
                  : 'bg-slate-950/30 border-slate-800/60 opacity-80 hover:opacity-100'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">
                    {isCurrent ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    ) : (
                      <Clock className="w-5 h-5 text-slate-500" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3
                        className={`text-sm font-semibold ${
                          isCurrent ? 'text-indigo-200' : 'text-slate-300'
                        }`}
                      >
                        {phase.title}
                      </h3>
                      {isCurrent && (
                        <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          Active & Ready
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                      {phase.description}
                    </p>
                    <div className="flex flex-wrap gap-1.5 mt-2.5">
                      {phase.modules.map((mod) => (
                        <span
                          key={mod}
                          className="text-[10px] px-2 py-0.5 rounded-md bg-slate-900 border border-slate-800 text-slate-400 font-mono"
                        >
                          {mod}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
