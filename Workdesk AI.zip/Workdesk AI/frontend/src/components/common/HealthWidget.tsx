import React, { useState } from 'react';
import {
  Activity,
  CheckCircle2,
  AlertCircle,
  Database,
  Server,
  Code2,
  RefreshCw,
  Clock,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { HealthProbeResult } from '../../api/health';

interface HealthWidgetProps {
  health: HealthProbeResult | null;
  isChecking: boolean;
  onRefresh: () => void;
  apiBaseUrl: string;
}

export const HealthWidget: React.FC<HealthWidgetProps> = ({
  health,
  isChecking,
  onRefresh,
  apiBaseUrl,
}) => {
  const [showRaw, setShowRaw] = useState(false);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-semibold text-slate-100">Backend Health & API Status</h2>
            <span
              className={`text-xs px-2.5 py-0.5 rounded-full font-medium ${
                health?.isOnline
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                  : 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
              }`}
            >
              {health?.isOnline ? 'GET /api/v1/health: 200 OK' : 'Backend Not Detected'}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Endpoint: <code className="text-indigo-300 font-mono">{apiBaseUrl}/health</code>
          </p>
        </div>

        <button
          onClick={onRefresh}
          disabled={isChecking}
          className="self-start sm:self-auto flex items-center gap-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-700/80 active:bg-slate-700 text-slate-200 rounded-xl text-xs font-medium border border-slate-700 transition-all cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin text-indigo-400' : ''}`} />
          {isChecking ? 'Probing API...' : 'Probe /health'}
        </button>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
        {/* FastAPI Server Card */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">FastAPI Service</span>
            <Server className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="flex items-center gap-2">
            {health?.isOnline ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" />
            )}
            <span className="text-sm font-semibold text-slate-200">
              {health?.isOnline ? 'Operational' : 'Ready to Start'}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1 font-mono">
            {health?.isOnline ? `Version: ${health.data?.version || '1.0.0'}` : 'uvicorn backend.app.main:app'}
          </p>
        </div>

        {/* Latency Card */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Round-Trip Latency</span>
            <Clock className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-xl font-bold text-slate-200">
            {health?.latencyMs !== undefined ? `${health.latencyMs}ms` : '--'}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {health?.isOnline ? 'Network & middleware timing' : 'Requires running backend'}
          </p>
        </div>

        {/* Database Connectivity */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">PostgreSQL</span>
            <Database className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-slate-200 capitalize">
              {health?.data?.database || 'Configured (asyncpg)'}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1 font-mono">
            SQLAlchemy 2.0 + Alembic
          </p>
        </div>

        {/* CORS Configuration */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">CORS Policy</span>
            <Code2 className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-sm font-semibold text-slate-200">
            Configured
          </div>
          <p className="text-[11px] text-slate-500 mt-1 font-mono">
            localhost:3000, localhost:5173
          </p>
        </div>
      </div>

      {/* Diagnostic Tip if backend is not detected */}
      {!health?.isOnline && (
        <div className="mt-6 p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300">
          <div className="font-semibold text-indigo-300 mb-2 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5" />
            Quick Start: Run the FastAPI backend locally
          </div>
          <div className="space-y-1.5 font-mono text-[11px] text-slate-400 bg-slate-900/90 p-3 rounded-lg border border-slate-800">
            <p className="text-emerald-400"># Option A: Run directly with Uvicorn</p>
            <p>pip install -r backend/requirements.txt</p>
            <p>uvicorn backend.app.main:app --reload --port 8000</p>
            <p className="text-emerald-400 pt-2"># Option B: Run with Docker Compose (PostgreSQL + API)</p>
            <p>docker compose -f backend/docker-compose.yml up -d</p>
          </div>
        </div>
      )}

      {/* Raw Payload Inspector Toggle */}
      <div className="mt-6 pt-4 border-t border-slate-800/80">
        <button
          onClick={() => setShowRaw(!showRaw)}
          className="flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 transition-colors font-medium cursor-pointer"
        >
          {showRaw ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          {showRaw ? 'Hide JSON Health Payload' : 'Inspect Health JSON Response & Schema Contract'}
        </button>

        {showRaw && (
          <div className="mt-3 p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono text-slate-300 overflow-x-auto">
            <pre>
              {JSON.stringify(
                health?.data || {
                  status: 'healthy',
                  project_name: 'WorkDesk AI Backend',
                  environment: 'development',
                  version: '1.0.0',
                  database: 'connected',
                  timestamp: new Date().toISOString(),
                  services: {
                    api: 'operational',
                    cors_configured: true,
                    database_driver: 'asyncpg',
                    phase: 'Phase 1 - Foundation & Project Structure',
                  },
                },
                null,
                2
              )}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
