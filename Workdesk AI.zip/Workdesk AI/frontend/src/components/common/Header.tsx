import React from 'react';
import {
  Layers,
  Activity,
  ExternalLink,
  Terminal,
  User as UserIcon,
  CreditCard,
  LogOut,
  ShieldCheck,
  LayoutDashboard,
} from 'lucide-react';
import { HealthProbeResult } from '../../api/health';
import { useAuth } from '../../context/AuthContext';

interface HeaderProps {
  health: HealthProbeResult | null;
  isChecking: boolean;
  onRefreshHealth: () => void;
  apiBaseUrl: string;
  currentView: 'dashboard' | 'documents' | 'data' | 'overview' | 'login' | 'signup';
  onNavigate: (view: 'dashboard' | 'documents' | 'data' | 'overview' | 'login' | 'signup') => void;
}

export const Header: React.FC<HeaderProps> = ({
  health,
  isChecking,
  onRefreshHealth,
  apiBaseUrl,
  currentView,
  onNavigate,
}) => {
  const { user, isAuthenticated, logout } = useAuth();

  return (
    <header className="sticky top-0 z-30 bg-slate-900/80 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Logo & Brand */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate(isAuthenticated ? 'dashboard' : 'overview')}
            className="flex items-center gap-3 text-left cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-sky-400 p-[1px] shadow-lg shadow-indigo-500/20">
              <div className="w-full h-full bg-slate-950 rounded-[11px] flex items-center justify-center">
                <Layers className="w-5 h-5 text-indigo-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-100 tracking-tight text-lg">
                  WorkDesk <span className="text-indigo-400">AI</span>
                </span>
                <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  Phase 4 RAG
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                One affordable AI workspace for everyday work
              </p>
            </div>
          </button>
        </div>

        {/* Center Navigation Switcher */}
        <nav className="hidden md:flex items-center gap-1 bg-slate-950/60 p-1 rounded-xl border border-slate-800">
          {isAuthenticated && (
            <>
              <button
                onClick={() => onNavigate('dashboard')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  currentView === 'dashboard'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Workspace
              </button>
              <button
                onClick={() => onNavigate('documents')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  currentView === 'documents'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>Document Agent</span>
              </button>
              <button
                onClick={() => onNavigate('data')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  currentView === 'data'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>Data Agent (Pandas)</span>
              </button>
            </>
          )}

          <button
            onClick={() => onNavigate('overview')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              currentView === 'overview'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            System & Health
          </button>

          {!isAuthenticated && (
            <>
              <button
                onClick={() => onNavigate('login')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  currentView === 'login'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Sign In
              </button>
              <button
                onClick={() => onNavigate('signup')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  currentView === 'signup'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Get Started
              </button>
            </>
          )}
        </nav>

        {/* Right Action & User Profile */}
        <div className="flex items-center gap-3">
          {/* Health Status Indicator */}
          <button
            onClick={onRefreshHealth}
            disabled={isChecking}
            title={`API: ${apiBaseUrl} - Click to re-probe health`}
            className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-all ${
              health?.isOnline
                ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20 hover:bg-emerald-500/20'
                : 'bg-amber-500/10 text-amber-300 border-amber-500/20 hover:bg-amber-500/20'
            }`}
          >
            <span className="relative flex h-2 w-2">
              <span
                className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                  health?.isOnline ? 'bg-emerald-400' : 'bg-amber-400'
                }`}
              />
              <span
                className={`relative inline-flex rounded-full h-2 w-2 ${
                  health?.isOnline ? 'bg-emerald-500' : 'bg-amber-500'
                }`}
              />
            </span>
            <span className="hidden lg:inline">
              {health?.isOnline ? `${health.latencyMs}ms` : 'Backend ready'}
            </span>
            <Activity className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin' : ''}`} />
          </button>

          {/* User Profile / Auth Action */}
          {isAuthenticated && user ? (
            <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
              {/* Credit Pill */}
              <div
                title="Current credit balance"
                className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold"
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>{user.credit_balance}</span>
              </div>

              {/* User Avatar & Name */}
              <div className="flex items-center gap-2 bg-slate-800/60 pl-2 pr-1 py-1 rounded-xl border border-slate-700">
                <div className="w-6 h-6 rounded-lg bg-indigo-600 flex items-center justify-center text-white text-[11px] font-bold">
                  {user.full_name.charAt(0).toUpperCase()}
                </div>
                <div className="hidden sm:block text-left">
                  <div className="text-xs font-semibold text-slate-200 leading-tight">
                    {user.full_name.split(' ')[0]}
                  </div>
                  <div className="text-[10px] text-slate-400 capitalize font-mono leading-none">
                    {user.role}
                  </div>
                </div>
                <button
                  onClick={() => logout()}
                  title="Sign Out"
                  className="p-1 text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
              <button
                onClick={() => onNavigate('login')}
                className="px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white transition-colors cursor-pointer"
              >
                Sign In
              </button>
              <button
                onClick={() => onNavigate('signup')}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-md shadow-indigo-600/20 transition-all cursor-pointer"
              >
                Get Started
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
