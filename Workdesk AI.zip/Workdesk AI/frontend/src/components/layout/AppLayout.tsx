import React, { ReactNode } from 'react';
import {
  LayoutDashboard,
  Layers,
  FileText,
  BarChart3,
  PenTool,
  CreditCard,
  Settings,
  HelpCircle,
  Database,
  Terminal,
  UserCheck,
  ShieldCheck,
  LogIn,
} from 'lucide-react';
import { Header } from '../common/Header';
import { HealthProbeResult } from '../../api/health';
import { useAuth } from '../../context/AuthContext';

interface AppLayoutProps {
  children: ReactNode;
  health: HealthProbeResult | null;
  isCheckingHealth: boolean;
  onRefreshHealth: () => void;
  apiBaseUrl: string;
  currentView: 'dashboard' | 'documents' | 'data' | 'overview' | 'login' | 'signup';
  onNavigate: (view: 'dashboard' | 'documents' | 'data' | 'overview' | 'login' | 'signup') => void;
}

export const AppLayout: React.FC<AppLayoutProps> = ({
  children,
  health,
  isCheckingHealth,
  onRefreshHealth,
  apiBaseUrl,
  currentView,
  onNavigate,
}) => {
  const { user, isAuthenticated, loginAsDemo } = useAuth();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Top Header */}
      <Header
        health={health}
        isChecking={isCheckingHealth}
        onRefreshHealth={onRefreshHealth}
        apiBaseUrl={apiBaseUrl}
        currentView={currentView}
        onNavigate={onNavigate}
      />

      <div className="flex-1 flex max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 gap-6">
        {/* Left Sidebar */}
        <aside className="w-64 shrink-0 hidden md:flex flex-col justify-between py-2">
          <div className="space-y-6">
            {/* Core Section */}
            <div>
              <p className="px-3 text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-2">
                Workspace
              </p>
              <nav className="space-y-1">
                {isAuthenticated && (
                  <>
                    <button
                      onClick={() => onNavigate('dashboard')}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                        currentView === 'dashboard'
                          ? 'bg-indigo-600/10 text-indigo-300 border border-indigo-500/20'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                      }`}
                    >
                      <LayoutDashboard className="w-4 h-4 text-indigo-400" />
                      <span>Workspace Tasks</span>
                    </button>

                    <button
                      onClick={() => onNavigate('documents')}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                        currentView === 'documents'
                          ? 'bg-indigo-600/10 text-indigo-300 border border-indigo-500/20'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                      }`}
                    >
                      <FileText className="w-4 h-4 text-indigo-400" />
                      <span>Document Agent (RAG)</span>
                    </button>

                    <button
                      onClick={() => onNavigate('data')}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                        currentView === 'data'
                          ? 'bg-emerald-600/10 text-emerald-400 border border-emerald-500/20'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                      }`}
                    >
                      <BarChart3 className="w-4 h-4 text-emerald-400" />
                      <span>Data Agent (Pandas)</span>
                    </button>
                  </>
                )}

                <button
                  onClick={() => onNavigate('overview')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    currentView === 'overview'
                      ? 'bg-indigo-600/10 text-indigo-300 border border-indigo-500/20'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <Terminal className="w-4 h-4 text-indigo-400" />
                  <span>Architecture & Health</span>
                </button>

                {!isAuthenticated && (
                  <>
                    <button
                      onClick={() => onNavigate('login')}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                        currentView === 'login'
                          ? 'bg-indigo-600/10 text-indigo-300 border border-indigo-500/20'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                      }`}
                    >
                      <LogIn className="w-4 h-4 text-slate-400" />
                      <span>Sign In</span>
                    </button>
                    <button
                      onClick={() => onNavigate('signup')}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                        currentView === 'signup'
                          ? 'bg-indigo-600/10 text-indigo-300 border border-indigo-500/20'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                      }`}
                    >
                      <UserCheck className="w-4 h-4 text-slate-400" />
                      <span>Create Account</span>
                    </button>
                  </>
                )}
              </nav>
            </div>

            {/* Quick Demo Switcher if logged in or unauthenticated */}
            <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 mb-2">
                Fast RBAC Testing
              </p>
              <div className="space-y-1.5">
                <button
                  onClick={async () => {
                    await loginAsDemo('user');
                    onNavigate('dashboard');
                  }}
                  className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-[11px] text-slate-300 transition-colors cursor-pointer"
                >
                  <span>Log in as Demo User</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-indigo-400 border border-slate-700">user</span>
                </button>
                <button
                  onClick={async () => {
                    await loginAsDemo('admin');
                    onNavigate('dashboard');
                  }}
                  className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-[11px] text-slate-300 transition-colors cursor-pointer"
                >
                  <span>Log in as Admin</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">admin</span>
                </button>
              </div>
            </div>

            {/* Upcoming Phase Modules */}
            <div>
              <div className="flex items-center justify-between px-3 mb-2">
                <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  Workspace Agents
                </p>
                <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                  Phases 3–6
                </span>
              </div>
              <div className="space-y-1 text-slate-500 text-xs font-medium">
                <div className="flex items-center justify-between px-3 py-2 rounded-xl opacity-60">
                  <div className="flex items-center gap-2.5">
                    <Layers className="w-4 h-4 text-slate-500" />
                    <span>Supervisor Agent</span>
                  </div>
                  <span className="text-[10px] text-slate-600">Phase 3</span>
                </div>
                <div className="flex items-center justify-between px-3 py-2 rounded-xl opacity-60">
                  <div className="flex items-center gap-2.5">
                    <FileText className="w-4 h-4 text-slate-500" />
                    <span>Document Agent</span>
                  </div>
                  <span className="text-[10px] text-slate-600">Phase 4</span>
                </div>
                <div className="flex items-center justify-between px-3 py-2 rounded-xl opacity-60">
                  <div className="flex items-center gap-2.5">
                    <BarChart3 className="w-4 h-4 text-slate-500" />
                    <span>Data Agent (Pandas)</span>
                  </div>
                  <span className="text-[10px] text-slate-600">Phase 5</span>
                </div>
                <div className="flex items-center justify-between px-3 py-2 rounded-xl opacity-60">
                  <div className="flex items-center gap-2.5">
                    <PenTool className="w-4 h-4 text-slate-500" />
                    <span>Writer Agent</span>
                  </div>
                  <span className="text-[10px] text-slate-600">Phase 6</span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick info card */}
          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400">
            <div className="flex items-center gap-2 text-slate-200 font-semibold mb-1">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Phase 2 Active</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              JWT sessions, role-based authorization (User/Admin), and PostgreSQL schema models.
            </p>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 min-w-0 space-y-6">{children}</main>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} WorkDesk AI. One affordable AI workspace for everyday work.</p>
          <div className="flex items-center gap-4">
            <span>FastAPI 0.115</span>
            <span>•</span>
            <span>JWT Bearer</span>
            <span>•</span>
            <span>RBAC</span>
            <span>•</span>
            <span>PostgreSQL 16</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
