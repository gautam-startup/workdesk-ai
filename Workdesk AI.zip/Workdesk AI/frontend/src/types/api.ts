/**
 * WorkDesk AI - Standardized API Types & Response Contracts
 */

export interface ApiResponse<T = unknown> {
  data?: T;
  error_code?: string;
  message?: string;
  details?: Record<string, unknown>;
  request_id?: string;
}

export interface ApiError {
  errorCode: string;
  message: string;
  statusCode: number;
  details?: Record<string, unknown>;
  requestId?: string;
  isNetworkError?: boolean;
}

export interface HealthStatusResponse {
  status: 'healthy' | 'degraded' | 'unhealthy';
  project_name: string;
  environment: string;
  version: string;
  database: 'connected' | 'unreachable' | 'not_configured';
  timestamp: string;
  services: {
    api: string;
    cors_configured?: boolean;
    database_driver?: string;
    phase?: string;
    [key: string]: unknown;
  };
}
