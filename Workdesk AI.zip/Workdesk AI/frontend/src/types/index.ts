/**
 * WorkDesk AI - Shared Domain Types (Phase 1 Foundation)
 */

export type Environment = 'development' | 'staging' | 'production' | 'test';

export interface SystemHealthState {
  isChecking: boolean;
  lastChecked: string | null;
  status: 'healthy' | 'degraded' | 'unhealthy' | 'offline';
  backendVersion: string;
  databaseStatus: 'connected' | 'unreachable' | 'not_configured';
  apiLatencyMs: number | null;
  errorMessage?: string;
  rawResponse?: Record<string, unknown>;
}

export interface PhaseStep {
  id: number;
  title: string;
  status: 'completed' | 'in_progress' | 'planned';
  description: string;
  modules: string[];
}

export interface AppConfig {
  projectName: string;
  tagline: string;
  apiBaseUrl: string;
  environment: Environment;
}
