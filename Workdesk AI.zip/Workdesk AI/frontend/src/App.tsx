import React, { useState, useEffect, useCallback } from 'react';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppLayout } from './components/layout/AppLayout';
import { OverviewPage } from './pages/OverviewPage';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { DashboardPage } from './pages/DashboardPage';
import { DocumentsPage } from './pages/DocumentsPage';
import { DataPage } from './pages/DataPage';
import { checkBackendHealth, HealthProbeResult } from './api/health';
import { apiClient } from './api/client';

type ViewMode = 'dashboard' | 'documents' | 'data' | 'overview' | 'login' | 'signup';

const AppContent: React.FC = () => {
  const { isAuthenticated, user } = useAuth();
  const [currentView, setCurrentView] = useState<ViewMode>('overview');
  const [health, setHealth] = useState<HealthProbeResult | null>(null);
  const [isCheckingHealth, setIsCheckingHealth] = useState<boolean>(true);

  const performHealthCheck = useCallback(async () => {
    setIsCheckingHealth(true);
    try {
      const result = await checkBackendHealth();
      setHealth(result);
    } catch (err) {
      console.error('[WorkDesk AI] Health probe failed:', err);
    } finally {
      setIsCheckingHealth(false);
    }
  }, []);

  useEffect(() => {
    performHealthCheck();
  }, [performHealthCheck]);

  // If user logs in and was on auth page, switch to dashboard
  useEffect(() => {
    if (isAuthenticated) {
      if (currentView === 'login' || currentView === 'signup') {
        setCurrentView('dashboard');
      }
    }
  }, [isAuthenticated, currentView]);

  return (
    <AppLayout
      health={health}
      isCheckingHealth={isCheckingHealth}
      onRefreshHealth={performHealthCheck}
      apiBaseUrl={apiClient.getBaseUrl()}
      currentView={currentView}
      onNavigate={setCurrentView}
    >
      {/* Route Views */}
      {currentView === 'login' && (
        <LoginPage
          onNavigateSignup={() => setCurrentView('signup')}
          onSuccess={() => setCurrentView('dashboard')}
        />
      )}

      {currentView === 'signup' && (
        <SignupPage
          onNavigateLogin={() => setCurrentView('login')}
          onSuccess={() => setCurrentView('dashboard')}
        />
      )}

      {currentView === 'dashboard' && (
        isAuthenticated ? (
          <DashboardPage />
        ) : (
          <LoginPage
            onNavigateSignup={() => setCurrentView('signup')}
            onSuccess={() => setCurrentView('dashboard')}
          />
        )
      )}

      {currentView === 'documents' && (
        isAuthenticated ? (
          <DocumentsPage />
        ) : (
          <LoginPage
            onNavigateSignup={() => setCurrentView('signup')}
            onSuccess={() => setCurrentView('documents')}
          />
        )
      )}

      {currentView === 'data' && (
        isAuthenticated ? (
          <DataPage />
        ) : (
          <LoginPage
            onNavigateSignup={() => setCurrentView('signup')}
            onSuccess={() => setCurrentView('data')}
          />
        )
      )}

      {currentView === 'overview' && (
        <OverviewPage
          health={health}
          isCheckingHealth={isCheckingHealth}
          onRefreshHealth={performHealthCheck}
          apiBaseUrl={apiClient.getBaseUrl()}
        />
      )}
    </AppLayout>
  );
};

export const App: React.FC = () => {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ErrorBoundary>
  );
};

export default App;
