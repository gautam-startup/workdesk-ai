/**
 * WorkDesk AI - Applet Entry Wrapper
 * Mounts the production modular frontend application from frontend/src/App.tsx
 */

import App from '../frontend/src/App';

export default App;
