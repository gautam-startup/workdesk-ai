"""
Unit tests for configuration validation, environment defaults, and CORS origin parsing.
"""

import unittest
from backend.app.core.config import Settings


class TestConfiguration(unittest.TestCase):
    """Verifies that Settings parses environment variables properly."""

    def test_default_settings(self):
        settings = Settings()
        self.assertEqual(settings.PROJECT_NAME, "WorkDesk AI Backend")
        self.assertEqual(settings.API_V1_PREFIX, "/api/v1")
        self.assertEqual(settings.PORT, 8000)
        self.assertIn("http://localhost:3000", settings.CORS_ORIGINS)

    def test_cors_string_parsing(self):
        settings = Settings(
            CORS_ORIGINS="http://localhost:3000, https://myapp.vercel.app , http://localhost:5173"
        )
        self.assertEqual(
            settings.CORS_ORIGINS,
            ["http://localhost:3000", "https://myapp.vercel.app", "http://localhost:5173"],
        )

    def test_cors_list_passthrough(self):
        custom_origins = ["https://custom-origin.com", "http://localhost:3000"]
        settings = Settings(CORS_ORIGINS=custom_origins)
        self.assertEqual(settings.CORS_ORIGINS, custom_origins)

    def test_database_url_configured(self):
        settings = Settings()
        self.assertTrue(settings.DATABASE_URL.startswith("postgresql"))
        self.assertTrue(settings.DATABASE_URL_SYNC.startswith("postgresql"))


if __name__ == "__main__":
    unittest.main()
