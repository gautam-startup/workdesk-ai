"""
Tests for Health Endpoint Schema, Status Codes, and Structured Errors.
"""

import unittest
from datetime import datetime
from backend.app.core.exceptions import AppException, NotFoundError, ValidationError
from backend.app.schemas.health import HealthCheckResponse


class TestHealthAndExceptions(unittest.TestCase):
    """Verifies the health check schema and standard exception payloads."""

    def test_health_check_response_schema(self):
        sample_time = datetime.utcnow()
        payload = {
            "status": "healthy",
            "project_name": "WorkDesk AI Backend",
            "environment": "testing",
            "version": "1.0.0",
            "database": "connected",
            "timestamp": sample_time,
            "services": {"api": "operational", "cors_configured": True},
        }
        res = HealthCheckResponse(**payload)
        self.assertEqual(res.status, "healthy")
        self.assertEqual(res.environment, "testing")
        self.assertEqual(res.database, "connected")
        self.assertEqual(res.services["api"], "operational")

    def test_app_exception_structure(self):
        exc = AppException(
            status_code=400,
            error_code="INVALID_PAYLOAD",
            message="The payload was malformed.",
            details={"field": "query"},
        )
        self.assertEqual(exc.status_code, 400)
        self.assertEqual(exc.error_code, "INVALID_PAYLOAD")
        self.assertEqual(exc.message, "The payload was malformed.")
        self.assertEqual(exc.details.get("field"), "query")

    def test_not_found_error_structure(self):
        exc = NotFoundError(resource="Document", identifier="doc_123")
        self.assertEqual(exc.status_code, 404)
        self.assertEqual(exc.error_code, "RESOURCE_NOT_FOUND")
        self.assertIn("doc_123", exc.message)

    def test_validation_error_structure(self):
        exc = ValidationError(
            message="Validation error on input parameters",
            details={"missing": ["file_name"]},
        )
        self.assertEqual(exc.status_code, 422)
        self.assertEqual(exc.error_code, "VALIDATION_FAILED")


if __name__ == "__main__":
    unittest.main()
