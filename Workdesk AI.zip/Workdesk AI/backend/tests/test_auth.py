"""
WorkDesk AI - Authentication & Authorization Unit and API Test Suite
Covers:
- Password hashing & timing-safe verification
- JWT generation, validation, expiration, and tampering prevention
- Successful signup & duplicate email prevention (409)
- Valid login & invalid credentials rejection (401)
- Protected route authorization (/api/v1/auth/me)
- Admin role-based access control (RBAC 403 vs 200)
"""

import unittest
from datetime import datetime, timedelta
from backend.app.core.exceptions import AppException, ForbiddenError, UnauthorizedError, ValidationError
from backend.app.core.security import (
    create_access_token,
    decode_access_token,
    hash_password,
    verify_password,
)
from backend.app.schemas.auth import UserCreate, UserLogin
from backend.app.services.auth_service import auth_service


class TestAuthenticationAndSecurity(unittest.TestCase):
    """Verifies security functions and authentication flows."""

    def test_password_hashing_and_verification(self):
        raw_password = "SecurePassword2026!"
        hashed = hash_password(raw_password)

        self.assertNotEqual(raw_password, hashed)
        self.assertTrue(hashed.startswith("pbkdf2_sha256$"))

        # Verify correct password
        self.assertTrue(verify_password(raw_password, hashed))

        # Verify wrong password fails
        self.assertFalse(verify_password("WrongPassword123!", hashed))

    def test_jwt_token_creation_and_decoding(self):
        payload = {"sub": "user_123", "email": "test@workdesk.ai", "role": "user"}
        token = create_access_token(payload)

        decoded = decode_access_token(token)
        self.assertEqual(decoded["sub"], "user_123")
        self.assertEqual(decoded["email"], "test@workdesk.ai")
        self.assertEqual(decoded["role"], "user")
        self.assertIn("exp", decoded)

    def test_jwt_token_tampering_rejected(self):
        payload = {"sub": "user_123", "email": "test@workdesk.ai", "role": "user"}
        token = create_access_token(payload)

        # Alter the signature part
        parts = token.split(".")
        tampered_token = f"{parts[0]}.{parts[1]}.tampered_signature"

        with self.assertRaises(UnauthorizedError):
            decode_access_token(tampered_token)

    def test_jwt_token_expiration(self):
        payload = {"sub": "user_expired", "email": "expired@workdesk.ai", "role": "user"}
        expired_token = create_access_token(payload, expires_delta=timedelta(seconds=-10))

        with self.assertRaises(UnauthorizedError):
            decode_access_token(expired_token)

    def test_successful_signup(self):
        unique_email = f"signup_test_{id(self)}@workdesk.ai"
        signup_payload = UserCreate(
            email=unique_email,
            password="StrongPassword123!",
            full_name="Test User",
        )

        resp = auth_service.register_user(signup_payload)
        self.assertIsNotNone(resp.access_token)
        self.assertEqual(resp.user.email, unique_email)
        self.assertEqual(resp.user.role, "user")
        self.assertEqual(resp.user.credit_balance, 10)  # Free tier default credits

    def test_duplicate_email_signup_rejected(self):
        email = f"duplicate_{id(self)}@workdesk.ai"
        signup_payload = UserCreate(
            email=email,
            password="StrongPassword123!",
            full_name="Original User",
        )
        auth_service.register_user(signup_payload)

        # Attempt to register again with same email
        with self.assertRaises(AppException) as ctx:
            auth_service.register_user(signup_payload)

        self.assertEqual(ctx.exception.status_code, 409)
        self.assertEqual(ctx.exception.error_code, "EMAIL_ALREADY_EXISTS")

    def test_valid_login(self):
        login_payload = UserLogin(
            email="demo@workdesk.ai",
            password="DemoPassword123!",
        )
        resp = auth_service.authenticate_user(login_payload)
        self.assertIsNotNone(resp.access_token)
        self.assertEqual(resp.user.email, "demo@workdesk.ai")
        self.assertEqual(resp.user.role, "user")

    def test_invalid_login_wrong_password(self):
        login_payload = UserLogin(
            email="demo@workdesk.ai",
            password="IncorrectPassword!",
        )
        with self.assertRaises(UnauthorizedError):
            auth_service.authenticate_user(login_payload)

    def test_invalid_login_nonexistent_user(self):
        login_payload = UserLogin(
            email="nonexistent_user_404@workdesk.ai",
            password="SomePassword123!",
        )
        with self.assertRaises(UnauthorizedError):
            auth_service.authenticate_user(login_payload)

    def test_admin_authorization_success(self):
        admin_login = UserLogin(
            email="admin@workdesk.ai",
            password="AdminSecure2026!",
        )
        resp = auth_service.authenticate_user(admin_login)
        self.assertEqual(resp.user.role, "admin")

        users_list = auth_service.list_users()
        self.assertGreaterEqual(len(users_list), 2)

    def test_unauthorized_missing_token_dependency(self):
        import asyncio
        from backend.app.api.deps import get_current_user

        with self.assertRaises(UnauthorizedError):
            asyncio.run(get_current_user(authorization=None))

    def test_unauthorized_invalid_header_format(self):
        import asyncio
        from backend.app.api.deps import get_current_user

        with self.assertRaises(UnauthorizedError):
            asyncio.run(get_current_user(authorization="Basic dXNlcjpwYXNz"))

    def test_admin_authorization_guard(self):
        import asyncio
        from backend.app.api.deps import require_admin
        from backend.app.schemas.auth import UserResponse

        user_resp = UserResponse(
            id="user-1",
            email="user@workdesk.ai",
            full_name="Regular User",
            role="user",
            is_active=True,
            is_verified=True,
            created_at=datetime.utcnow(),
            credit_balance=10,
            plan_slug="free",
            plan_name="Free Starter",
        )
        # Regular user should be forbidden
        with self.assertRaises(ForbiddenError):
            asyncio.run(require_admin(current_user=user_resp))

        admin_resp = UserResponse(
            id="admin-1",
            email="admin@workdesk.ai",
            full_name="Admin User",
            role="admin",
            is_active=True,
            is_verified=True,
            created_at=datetime.utcnow(),
            credit_balance=1000,
            plan_slug="business",
            plan_name="Business Workspace",
        )
        # Admin user should pass
        res = asyncio.run(require_admin(current_user=admin_resp))
        self.assertEqual(res.role, "admin")


if __name__ == "__main__":
    unittest.main()
