"""
WorkDesk AI - Multi-Agent & AI Router Unit and Contract Tests
Verifies:
- Supervisor intent classification and routing (Writer, Document, Data, Research)
- Provider fallback when primary provider encounters an error
- Invalid agent rejection (400)
- Unauthorized tool access rejection by gatekeeper (403)
- Insufficient credits quota rejection (402)
- Safe execution status milestones without exposing chain of thought
"""

import asyncio
import unittest
from backend.app.core.exceptions import AppException
from backend.app.services.agents.credits import InsufficientCreditsError, estimate_credits, verify_and_deduct_credits
from backend.app.services.agents.orchestrator import agent_orchestrator
from backend.app.services.agents.supervisor import supervisor_agent
from backend.app.services.agents.tools import UnauthorizedToolError, tool_registry
from backend.app.services.ai.providers.base import BaseLLMProvider, LLMResponse
from backend.app.services.ai.router import AIRouter


class FailingProvider(BaseLLMProvider):
    """Test stub simulating a failing or timed-out primary provider."""
    def __init__(self):
        super().__init__(name="failing_mock")

    def is_configured(self) -> bool:
        return True

    def get_default_model(self) -> str:
        return "mock-failing-model"

    async def generate(self, *args, **kwargs) -> LLMResponse:
        raise TimeoutError("Provider timeout after 30s")


class SuccessfulFallbackProvider(BaseLLMProvider):
    """Test stub simulating a resilient backup provider."""
    def __init__(self):
        super().__init__(name="resilient_backup")

    def is_configured(self) -> bool:
        return True

    def get_default_model(self) -> str:
        return "mock-backup-model"

    async def generate(self, prompt: str, *args, **kwargs) -> LLMResponse:
        return LLMResponse(
            content=f"Fallback synthesis for: {prompt[:30]}",
            model_id="mock-backup-model",
            provider="resilient_backup",
            input_tokens=10,
            output_tokens=15,
            latency_ms=120,
        )


class TestMultiAgentSystem(unittest.TestCase):
    """Verifies agent routing, tool permissions, credit deductions, and fallback."""

    def test_supervisor_intent_classification(self):
        # 1. Writer Agent queries
        agent, _ = supervisor_agent.classify_intent("Please write an email follow-up to our client")
        self.assertEqual(agent, "writer")

        agent, _ = supervisor_agent.classify_intent("Draft a proposal for software development")
        self.assertEqual(agent, "writer")

        # 2. Document Agent queries
        agent, _ = supervisor_agent.classify_intent("Analyze this invoice PDF and find total amount")
        self.assertEqual(agent, "document")

        agent, _ = supervisor_agent.classify_intent("Summarize this legal contract docx")
        self.assertEqual(agent, "document")

        # 3. Data Agent queries
        agent, _ = supervisor_agent.classify_intent("Clean this Excel file and find duplicate rows")
        self.assertEqual(agent, "data")

        agent, _ = supervisor_agent.classify_intent("Profile this CSV dataset and detect missing values")
        self.assertEqual(agent, "data")

        # 4. Research Agent queries
        agent, _ = supervisor_agent.classify_intent("Find information online about AI agent pricing")
        self.assertEqual(agent, "research")

    def test_credit_estimation_and_insufficient_credits(self):
        self.assertEqual(estimate_credits("writer"), 1)
        self.assertEqual(estimate_credits("summary"), 2)
        self.assertEqual(estimate_credits("document"), 3)
        self.assertEqual(estimate_credits("data"), 5)
        self.assertEqual(estimate_credits("research"), 8)

        # Successful credit deduction
        remaining = verify_and_deduct_credits(current_balance=10, cost=3)
        self.assertEqual(remaining, 7)

        # Insufficient credits raises error
        with self.assertRaises(InsufficientCreditsError) as ctx:
            verify_and_deduct_credits(current_balance=2, cost=5)

        self.assertEqual(ctx.exception.status_code, 402)
        self.assertEqual(ctx.exception.error_code, "INSUFFICIENT_CREDITS")

    def test_unauthorized_tool_access_rejected(self):
        # Writer Agent should NOT be authorized to execute "clean_dataset"
        with self.assertRaises(UnauthorizedToolError) as ctx:
            tool_registry.authorize_and_execute(
                agent_name="writer",
                tool_name="clean_dataset",
            )

        self.assertEqual(ctx.exception.status_code, 403)
        self.assertEqual(ctx.exception.error_code, "UNAUTHORIZED_TOOL_ACCESS")

    def test_authorized_tool_access_succeeds(self):
        # Data Agent IS authorized to execute "clean_dataset"
        res = tool_registry.authorize_and_execute(
            agent_name="data",
            tool_name="clean_dataset",
            remove_duplicates=True,
        )
        self.assertEqual(res["status"], "cleaned")
        self.assertEqual(res["duplicates_removed"], 2)

    def test_invalid_agent_rejected(self):
        with self.assertRaises(AppException) as ctx:
            asyncio.run(
                agent_orchestrator.run(
                    task="Do something unsupported",
                    user_id="user_123",
                    user_credit_balance=10,
                    forced_agent="nonexistent_alien_agent",
                )
            )

        self.assertEqual(ctx.exception.status_code, 400)
        self.assertEqual(ctx.exception.error_code, "INVALID_AGENT")

    def test_ai_router_provider_fallback(self):
        router = AIRouter()
        # Inject failing primary and working fallback
        router.providers["groq"] = FailingProvider()
        router.providers["mistral"] = SuccessfulFallbackProvider()

        # Execute router with fallback
        response = asyncio.run(
            router.generate_with_fallback(
                prompt="Draft quick message",
                preferred_provider="groq",
            )
        )
        self.assertEqual(response.provider, "resilient_backup")
        self.assertIn("Fallback synthesis", response.content)

    def test_agent_safe_execution_steps(self):
        state = asyncio.run(
            agent_orchestrator.run(
                task="Draft an email welcoming a new team member",
                user_id="user_test",
                user_credit_balance=10,
            )
        )
        self.assertEqual(state.selected_agent, "writer")
        self.assertEqual(state.current_status, "completed")
        self.assertGreaterEqual(len(state.safe_steps), 3)

        # Verify steps do NOT expose internal chain-of-thought
        step_names = [s.name for s in state.safe_steps]
        for name in step_names:
            self.assertNotIn("thought", name.lower())
            self.assertNotIn("chain", name.lower())


if __name__ == "__main__":
    unittest.main()
