"""
WorkDesk AI - Writer Agent Test Suite
Verifies:
- Reusable prompt template rendering (Email, WhatsApp, Proposal, Report, Social, Rewrite, Translate, Grammar)
- Multilingual support: English, Hindi, Hinglish
- Credit deduction and insufficient credit gating (PaymentRequiredError)
- Generation history tracking and retrieval
- Saved prompts CRUD operations and user isolation
- User feedback (thumbs up / thumbs down) recording
"""

import asyncio
import unittest
from backend.app.core.exceptions import ForbiddenError, PaymentRequiredError, ValidationError
from backend.app.services.auth_service import auth_service
from backend.app.services.writer.service import writer_service
from backend.app.services.writer.templates import template_engine


class TestWriterAgent(unittest.TestCase):
    """Tests Writer prompt templates, credit deductions, and multilingual synthesis."""

    def setUp(self):
        # Create a test user with 5 credits
        self.user_id = f"test_writer_user_{id(self)}"
        auth_service._USERS_DB[self.user_id] = {
            "id": self.user_id,
            "email": f"{self.user_id}@workdesk.ai",
            "full_name": "Writer Tester",
            "tier": "free",
            "credits": 5,
            "is_active": True,
            "is_verified": True,
        }

    def tearDown(self):
        if self.user_id in auth_service._USERS_DB:
            del auth_service._USERS_DB[self.user_id]

    def test_template_rendering_and_catalog(self):
        templates = template_engine.list_templates()
        self.assertGreaterEqual(len(templates), 9)

        features = [t["feature"] for t in templates]
        self.assertIn("email", features)
        self.assertIn("whatsapp", features)
        self.assertIn("proposal", features)
        self.assertIn("report", features)
        self.assertIn("social", features)
        self.assertIn("translate", features)
        self.assertIn("grammar", features)

        # Test rendering Email in Hinglish with Friendly tone
        rendered = template_engine.render(
            feature="email",
            input_text="Follow up on project deadline and deliverables",
            tone="Friendly",
            language="Hinglish",
            audience="Team",
        )
        self.assertIn("Friendly", rendered["system_prompt"])
        self.assertIn("Hinglish", rendered["system_prompt"])
        self.assertIn("Follow up on project deadline", rendered["user_prompt"])

    def test_writer_generation_and_credit_deduction(self):
        initial_credits = auth_service.get_user_by_id(self.user_id)["credits"]
        self.assertEqual(initial_credits, 5)

        # Generate WhatsApp message
        result = asyncio.run(
            writer_service.generate_content(
                user_id=self.user_id,
                feature="whatsapp",
                input_text="Client demo scheduled for tomorrow 3 PM",
                tone="Casual",
                language="Hinglish",
            )
        )

        self.assertIsNotNone(result["output_text"])
        self.assertEqual(result["credits_deducted"], 1)
        self.assertEqual(result["remaining_credits"], 4)

        # Check in history
        history = writer_service.list_history(self.user_id)
        self.assertGreaterEqual(len(history), 1)
        self.assertEqual(history[0]["id"], result["id"])

    def test_insufficient_credits_blocking(self):
        # Set credits to 0
        auth_service._USERS_DB[self.user_id]["credits"] = 0

        with self.assertRaises(PaymentRequiredError):
            asyncio.run(
                writer_service.generate_content(
                    user_id=self.user_id,
                    feature="email",
                    input_text="Test prompt with zero credits",
                )
            )

    def test_feedback_recording(self):
        gen = asyncio.run(
            writer_service.generate_content(
                user_id=self.user_id,
                feature="social",
                input_text="Launching AI productivity workspace for SMBs",
                tone="Engaging",
            )
        )

        # Record thumbs-up feedback
        fb = writer_service.record_feedback(
            generation_id=gen["id"],
            user_id=self.user_id,
            rating=1,
            comment="Great hook line and hashtags!",
        )
        self.assertEqual(fb["status"], "success")
        self.assertEqual(fb["feedback"]["rating"], 1)

    def test_saved_prompts_crud_and_isolation(self):
        other_user = "other_user_456"

        saved = writer_service.save_prompt(
            user_id=self.user_id,
            title="Cold Outreach Pitch",
            content="Introducing WorkDesk AI to enterprise operations teams.",
            feature="email",
        )
        self.assertEqual(saved["title"], "Cold Outreach Pitch")

        # List saved prompts
        user_prompts = writer_service.list_saved_prompts(self.user_id)
        self.assertEqual(len(user_prompts), 1)

        # Other user cannot delete user's saved prompt
        with self.assertRaises(ForbiddenError):
            writer_service.delete_saved_prompt(saved["id"], user_id=other_user)

        # Owner can delete
        deleted = writer_service.delete_saved_prompt(saved["id"], user_id=self.user_id)
        self.assertTrue(deleted)
        self.assertEqual(len(writer_service.list_saved_prompts(self.user_id)), 0)


if __name__ == "__main__":
    unittest.main()
