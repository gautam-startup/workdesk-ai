"""
WorkDesk AI - Data Agent & Deterministic Operations Test Suite
Verifies:
- CSV & XLSX tabular parsing and column type detection
- Data profiling (rows, columns, null counts, duplicate counts, quality score)
- Predefined safe operations:
  - remove_duplicates
  - fill_missing
  - filter_rows
  - sort_rows
  - group_by
  - describe statistics
  - correlation matrix
- Security: Rejection of arbitrary operations / invalid operators (ValidationError)
- Cleaned dataset download export
"""

import asyncio
import io
import unittest
import zipfile
from backend.app.core.exceptions import ValidationError
from backend.app.services.data.dataframe import DataFrame, read_csv_bytes, read_xlsx_bytes
from backend.app.services.data.operations import safe_operation_dispatcher
from backend.app.services.data.profiler import data_profiler
from backend.app.services.data.service import data_service


class TestDataAgent(unittest.TestCase):
    """Verifies deterministic tabular operations and profiling accuracy."""

    def setUp(self):
        self.sample_csv = (
            "id,name,department,salary,bonus,hire_date\n"
            "1,Alice,Engineering,120000,10000,2023-01-15\n"
            "2,Bob,Marketing,95000,,2022-06-01\n"
            "3,Charlie,Engineering,130000,15000,2021-03-20\n"
            "1,Alice,Engineering,120000,10000,2023-01-15\n"  # Exact duplicate
            "4,David,Sales,85000,5000,2023-11-10\n"
            "5,Eve,Engineering,,12000,2024-02-01\n"  # Missing salary
        )

    def test_csv_parsing_and_profiling(self):
        df = read_csv_bytes(self.sample_csv.encode("utf-8"))
        self.assertEqual(len(df), 6)
        self.assertEqual(len(df.columns), 6)

        profile = data_profiler.profile(df, "employees.csv")
        self.assertEqual(profile["total_rows"], 6)
        self.assertEqual(profile["total_columns"], 6)
        self.assertEqual(profile["duplicate_rows"], 1)
        self.assertEqual(profile["null_counts"]["salary"], 1)
        self.assertEqual(profile["null_counts"]["bonus"], 1)

        # Column type detection
        types = profile["column_types"]
        self.assertEqual(types["salary"], "numeric")
        self.assertEqual(types["name"], "text")
        self.assertEqual(types["hire_date"], "datetime")

    def test_remove_duplicates_operation(self):
        df = read_csv_bytes(self.sample_csv.encode("utf-8"))
        clean_df, meta = safe_operation_dispatcher.execute_operation(
            df=df,
            operation_name="remove_duplicates",
        )
        self.assertEqual(len(clean_df), 5)
        self.assertEqual(meta["duplicates_removed"], 1)

    def test_fill_missing_operation(self):
        df = read_csv_bytes(self.sample_csv.encode("utf-8"))
        # Fill missing salary with mean
        clean_df, meta = safe_operation_dispatcher.execute_operation(
            df=df,
            operation_name="fill_missing",
            params={"column": "salary", "strategy": "mean"},
        )
        self.assertEqual(meta["values_imputed"], 1)

        # Check that row 5 now has imputed salary
        eve_row = next(r for r in clean_df.data if r["name"] == "Eve")
        self.assertIsNotNone(eve_row["salary"])
        self.assertGreater(float(eve_row["salary"]), 0)

    def test_filter_and_sort_operations(self):
        df = read_csv_bytes(self.sample_csv.encode("utf-8"))

        # Filter: department == Engineering
        filtered_df, meta = safe_operation_dispatcher.execute_operation(
            df=df,
            operation_name="filter_rows",
            params={"column": "department", "operator": "==", "value": "Engineering"},
        )
        self.assertEqual(len(filtered_df), 4)

        # Sort: salary descending
        sorted_df, meta = safe_operation_dispatcher.execute_operation(
            df=filtered_df,
            operation_name="sort_rows",
            params={"column": "salary", "ascending": False},
        )
        first_row = sorted_df.data[0]
        self.assertEqual(first_row["name"], "Charlie")

    def test_group_by_aggregation(self):
        df = read_csv_bytes(self.sample_csv.encode("utf-8"))
        # Clean duplicates first
        df, _ = df.remove_duplicates()
        df, _ = df.fill_missing(column="salary", strategy="mean")

        grouped_df, meta = safe_operation_dispatcher.execute_operation(
            df=df,
            operation_name="group_by",
            params={"group_columns": ["department"], "agg_column": "salary", "agg_func": "mean"},
        )
        self.assertIn("department", grouped_df.columns)
        self.assertIn("salary_mean", grouped_df.columns)

    def test_security_rejection_of_arbitrary_operations(self):
        df = read_csv_bytes(self.sample_csv.encode("utf-8"))

        # Arbitrary code or unapproved operation names must be rejected with ValidationError
        with self.assertRaises(ValidationError):
            safe_operation_dispatcher.execute_operation(
                df=df,
                operation_name="__import__('os').system('rm -rf /')",
            )

        with self.assertRaises(ValidationError):
            safe_operation_dispatcher.execute_operation(
                df=df,
                operation_name="custom_eval_code",
            )

    def test_data_service_lifecycle_and_download(self):
        user_id = "test_user_data_agent"
        summary = data_service.upload_dataset(
            user_id=user_id,
            filename="sales_test.csv",
            file_bytes=self.sample_csv.encode("utf-8"),
        )

        doc_id = summary["id"]
        self.assertEqual(summary["filename"], "sales_test.csv")

        # Apply deduplication and imputation
        transform_res = data_service.apply_operations(
            dataset_id=doc_id,
            user_id=user_id,
            operations=[
                {"operation": "remove_duplicates"},
                {"operation": "fill_missing", "params": {"column": "bonus", "strategy": "constant", "constant_value": 0}},
            ],
        )
        self.assertEqual(len(transform_res["operations_applied"]), 2)
        self.assertEqual(transform_res["profile"]["duplicate_rows"], 0)

        # Download cleaned file
        filename, file_bytes = data_service.export_dataset(doc_id, user_id)
        self.assertTrue(filename.startswith("cleaned_sales_test.csv"))
        self.assertIn(b"salary", file_bytes)

        # Clean up
        data_service.delete_dataset(doc_id, user_id)


if __name__ == "__main__":
    unittest.main()
