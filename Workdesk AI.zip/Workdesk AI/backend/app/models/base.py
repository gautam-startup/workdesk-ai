"""
WorkDesk AI - Base SQLAlchemy Declarative Model & Mixins
Provides UUID primary keys and UTC timestamp tracking across all database entities.
"""

import uuid
from datetime import datetime
from backend.app.core.database import Base

try:
    from sqlalchemy import Column, DateTime, String
    from sqlalchemy.dialects.postgresql import UUID
    import sqlalchemy as sa
except ImportError:
    # Lightweight fallback for stubbed environments
    class Column:  # type: ignore
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    class DateTime:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class String:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class UUID:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class sa:  # type: ignore
        pass


class TimestampMixin:
    """Provides created_at and updated_at datetime columns."""
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


def generate_uuid() -> str:
    """Generates a stringified UUIDv4."""
    return str(uuid.uuid4())
