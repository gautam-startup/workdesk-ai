"""
WorkDesk AI - Workspace Models (Conversations, Messages, Documents, AgentRuns)
"""

from datetime import datetime
from backend.app.core.database import Base
from backend.app.models.base import TimestampMixin, generate_uuid

try:
    from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Index, Integer, String, Text
    from sqlalchemy.orm import relationship
except ImportError:
    class Column:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Boolean:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class DateTime:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class ForeignKey:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Index:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Integer:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class String:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Text:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    def relationship(*args, **kwargs):  # type: ignore
        return None


class Conversation(Base, TimestampMixin):
    __tablename__ = "conversations"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    title = Column(String(255), default="New Workspace Task", nullable=False)
    pinned = Column(Boolean, default=False, nullable=False)

    user = relationship("User", back_populates="conversations")
    messages = relationship("Message", back_populates="conversation", cascade="all, delete-orphan")
    agent_runs = relationship("AgentRun", back_populates="conversation", cascade="all, delete-orphan")


class Message(Base, TimestampMixin):
    __tablename__ = "messages"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    conversation_id = Column(String(36), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False, index=True)
    sender_type = Column(String(32), nullable=False)  # 'user', 'supervisor', 'document', 'data', 'writer'
    agent_name = Column(String(64), nullable=True)
    content = Column(Text, nullable=False)
    metadata_json = Column(Text, nullable=True)

    conversation = relationship("Conversation", back_populates="messages")


class Document(Base, TimestampMixin):
    __tablename__ = "documents"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    filename = Column(String(255), nullable=False)
    file_size = Column(Integer, nullable=False)
    mime_type = Column(String(128), nullable=False)
    storage_path = Column(String(512), nullable=False)
    status = Column(String(32), default="pending", nullable=False)  # 'pending', 'processed', 'failed'
    total_pages = Column(Integer, default=0, nullable=False)
    extracted_text_path = Column(String(512), nullable=True)

    user = relationship("User", back_populates="documents")


class AgentRun(Base, TimestampMixin):
    __tablename__ = "agent_runs"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    conversation_id = Column(String(36), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    status = Column(String(32), default="queued", nullable=False)  # 'queued', 'running', 'completed', 'failed'
    requested_task = Column(Text, nullable=False)
    planned_steps_json = Column(Text, nullable=True)
    credits_cost = Column(Integer, default=0, nullable=False)
    started_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    completed_at = Column(DateTime, nullable=True)

    conversation = relationship("Conversation", back_populates="agent_runs")
