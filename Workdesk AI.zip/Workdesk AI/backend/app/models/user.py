"""
WorkDesk AI - User and Session SQLAlchemy Models
"""

import enum
from datetime import datetime
from backend.app.core.database import Base
from backend.app.models.base import TimestampMixin, generate_uuid

try:
    from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Index, String, Text, Enum
    from sqlalchemy.orm import relationship
except ImportError:
    class Column:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Boolean:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class DateTime:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class ForeignKey:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Index:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class String:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Text:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Enum:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    def relationship(*args, **kwargs):  # type: ignore
        return None


class UserRole(str, enum.Enum):
    USER = "user"
    ADMIN = "admin"


class User(Base, TimestampMixin):
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    role = Column(String(32), default=UserRole.USER.value, nullable=False, index=True)
    is_active = Column(Boolean, default=True, nullable=False)
    is_verified = Column(Boolean, default=False, nullable=False)

    # Relationships
    sessions = relationship("Session", back_populates="user", cascade="all, delete-orphan")
    credit = relationship("Credit", back_populates="user", uselist=False, cascade="all, delete-orphan")
    subscriptions = relationship("Subscription", back_populates="user", cascade="all, delete-orphan")
    conversations = relationship("Conversation", back_populates="user", cascade="all, delete-orphan")
    documents = relationship("Document", back_populates="user", cascade="all, delete-orphan")


class Session(Base, TimestampMixin):
    __tablename__ = "sessions"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    token_hash = Column(String(255), unique=True, index=True, nullable=False)
    ip_address = Column(String(64), nullable=True)
    user_agent = Column(Text, nullable=True)
    expires_at = Column(DateTime, nullable=False)

    user = relationship("User", back_populates="sessions")
