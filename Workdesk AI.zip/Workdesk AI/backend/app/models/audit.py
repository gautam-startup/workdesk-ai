"""
WorkDesk AI - Telemetry, Audit Logs, and Model Usage Logs
"""

from datetime import datetime
from backend.app.core.database import Base
from backend.app.models.base import TimestampMixin, generate_uuid

try:
    from sqlalchemy import Column, DateTime, ForeignKey, Index, Integer, String, Text
except ImportError:
    class Column:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class DateTime:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class ForeignKey:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Index:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Integer:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class String:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Text:  # type: ignore
        def __init__(self, *args, **kwargs): pass


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    action = Column(String(128), nullable=False, index=True)  # 'user.signup', 'user.login', 'admin.view_users'
    resource = Column(String(128), nullable=True)
    ip_address = Column(String(64), nullable=True)
    details_json = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)


class UsageLog(Base):
    __tablename__ = "usage_logs"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    agent_name = Column(String(64), nullable=False, index=True)
    provider = Column(String(64), nullable=False)
    model = Column(String(128), nullable=False)
    input_tokens = Column(Integer, default=0, nullable=False)
    output_tokens = Column(Integer, default=0, nullable=False)
    latency_ms = Column(Integer, default=0, nullable=False)
    credits_deducted = Column(Integer, default=0, nullable=False)
    status = Column(String(32), default="success", nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
