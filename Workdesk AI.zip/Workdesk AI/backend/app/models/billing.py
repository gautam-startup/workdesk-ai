"""
WorkDesk AI - Billing, Plans, Credits, and Payment Models
"""

import enum
from datetime import datetime
from backend.app.core.database import Base
from backend.app.models.base import TimestampMixin, generate_uuid

try:
    from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Index, Integer, String, Text
    from sqlalchemy.orm import relationship
except ImportError:
    class Column:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Boolean:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class DateTime:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class ForeignKey:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Index:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Integer:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class String:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    class Text:  # type: ignore
        def __init__(self, *args, **kwargs): pass
    def relationship(*args, **kwargs):  # type: ignore
        return None


class Plan(Base, TimestampMixin):
    __tablename__ = "plans"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    slug = Column(String(64), unique=True, index=True, nullable=False)
    name = Column(String(128), nullable=False)
    price_inr = Column(Integer, default=0, nullable=False)  # in rupees (0, 149, 299, 699)
    price_usd = Column(Integer, default=0, nullable=False)  # in dollars (0, 5, 10, 25)
    credits_monthly = Column(Integer, default=10, nullable=False)
    max_file_size_mb = Column(Integer, default=10, nullable=False)
    features_json = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)

    subscriptions = relationship("Subscription", back_populates="plan")


class Subscription(Base, TimestampMixin):
    __tablename__ = "subscriptions"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    plan_id = Column(String(36), ForeignKey("plans.id"), nullable=False, index=True)
    status = Column(String(32), default="active", nullable=False)
    current_period_start = Column(DateTime, default=datetime.utcnow, nullable=False)
    current_period_end = Column(DateTime, nullable=False)
    provider_subscription_id = Column(String(128), nullable=True)

    user = relationship("User", back_populates="subscriptions")
    plan = relationship("Plan", back_populates="subscriptions")
    payments = relationship("Payment", back_populates="subscription")


class Payment(Base, TimestampMixin):
    __tablename__ = "payments"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    subscription_id = Column(String(36), ForeignKey("subscriptions.id"), nullable=True, index=True)
    amount = Column(Integer, nullable=False)
    currency = Column(String(8), default="INR", nullable=False)
    provider = Column(String(32), default="razorpay", nullable=False)
    provider_payment_id = Column(String(128), unique=True, index=True, nullable=False)
    status = Column(String(32), default="pending", nullable=False)

    subscription = relationship("Subscription", back_populates="payments")


class Credit(Base, TimestampMixin):
    __tablename__ = "credits"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False, index=True)
    balance = Column(Integer, default=10, nullable=False)
    total_allocated = Column(Integer, default=10, nullable=False)
    total_consumed = Column(Integer, default=0, nullable=False)

    user = relationship("User", back_populates="credit")


class CreditTransaction(Base, TimestampMixin):
    __tablename__ = "credit_transactions"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    amount = Column(Integer, nullable=False)  # positive for grant, negative for use
    transaction_type = Column(String(32), nullable=False)  # 'allocation', 'deduction', 'refund'
    reason = Column(String(255), nullable=False)
    agent_run_id = Column(String(36), nullable=True, index=True)
