"""
WorkDesk AI - Multi-Agent REST API Endpoints
Handles agent dispatching, credit quota deductions, and supervisor task estimation.
"""

from fastapi import APIRouter, Depends, status
from backend.app.api.deps import get_current_active_user
from backend.app.schemas.agent import (
    AgentEstimateRequest,
    AgentEstimateResponse,
    AgentRunRequest,
    AgentRunResponse,
)
from backend.app.schemas.auth import UserResponse
from backend.app.services.agents.credits import estimate_credits
from backend.app.services.agents.orchestrator import agent_orchestrator
from backend.app.services.agents.supervisor import supervisor_agent
from backend.app.services.agents.tools import tool_registry

router = APIRouter(prefix="/agent", tags=["Multi-Agent Orchestrator"])


@router.post(
    "/estimate",
    response_model=AgentEstimateResponse,
    status_code=status.HTTP_200_OK,
    summary="Estimate required credits for a task",
)
async def estimate_agent_task(payload: AgentEstimateRequest) -> AgentEstimateResponse:
    agent_type, complexity = supervisor_agent.classify_intent(payload.task)
    credits_cost = estimate_credits(
        task_type=agent_type,
        has_file=payload.has_file,
        file_size_mb=payload.file_size_mb,
    )

    return AgentEstimateResponse(
        task_type=agent_type,
        recommended_agent=agent_type,
        estimated_credits=credits_cost,
        complexity=complexity,
    )


@router.post(
    "/run",
    response_model=AgentRunResponse,
    status_code=status.HTTP_200_OK,
    summary="Execute multi-agent workflow",
)
async def run_agent_workflow(
    payload: AgentRunRequest,
    current_user: UserResponse = Depends(get_current_active_user),
) -> AgentRunResponse:
    state = await agent_orchestrator.run(
        task=payload.task,
        user_id=current_user.id,
        user_credit_balance=current_user.credit_balance,
        forced_agent=payload.agent_override,
    )

    remaining_credits = max(0, current_user.credit_balance - state.credits_cost)
    current_user.credit_balance = remaining_credits

    return AgentRunResponse(
        task=state.task,
        selected_agent=state.selected_agent,
        credits_cost=state.credits_cost,
        remaining_credits=remaining_credits,
        safe_steps=state.safe_steps,
        final_output=state.final_output,
        current_status=state.current_status,
    )


@router.get(
    "/tools",
    status_code=status.HTTP_200_OK,
    summary="List registered deterministic tools and permissions",
)
async def list_registered_tools():
    return {
        "tools": [
            {
                "name": t.name,
                "description": t.description,
                "required_permission": t.permission,
            }
            for t in tool_registry.tools.values()
        ],
        "agent_permissions": tool_registry.agent_permissions,
    }
