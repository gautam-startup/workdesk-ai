"""
WorkDesk AI - Data Agent REST API Endpoints
Provides tabular profiling, safe predefined operations, report generation, and cleaned file downloads.
"""

import base64
from typing import List
from fastapi import APIRouter, Depends, Response, status
from backend.app.api.deps import get_current_active_user
from backend.app.core.exceptions import ValidationError
from backend.app.schemas.auth import UserResponse
from backend.app.schemas.data import (
    DataReportResponse,
    DataTransformRequest,
    DataUploadBase64Request,
    DatasetDetailResponse,
    DatasetSummaryResponse,
)
from backend.app.services.data.service import data_service

router = APIRouter(prefix="/data", tags=["Data Agent & Predefined Operations"])


@router.post(
    "/upload",
    response_model=DatasetDetailResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Upload & profile CSV or XLSX dataset",
)
async def upload_dataset(
    payload: DataUploadBase64Request,
    current_user: UserResponse = Depends(get_current_active_user),
) -> DatasetDetailResponse:
    try:
        file_bytes = base64.b64decode(payload.content_base64)
    except Exception:
        raise ValidationError("Could not decode base64 file contents.")

    result = data_service.upload_dataset(
        user_id=current_user.id,
        filename=payload.filename,
        file_bytes=file_bytes,
    )
    return DatasetDetailResponse(**result)


@router.get(
    "",
    response_model=List[DatasetSummaryResponse],
    status_code=status.HTTP_200_OK,
    summary="List authenticated user's datasets",
)
async def list_datasets(
    current_user: UserResponse = Depends(get_current_active_user),
) -> List[DatasetSummaryResponse]:
    sets = data_service.list_user_datasets(user_id=current_user.id)
    return [DatasetSummaryResponse(**s) for s in sets]


@router.get(
    "/{dataset_id}",
    response_model=DatasetDetailResponse,
    status_code=status.HTTP_200_OK,
    summary="Get dataset profile, columns, and preview rows",
)
async def get_dataset(
    dataset_id: str,
    current_user: UserResponse = Depends(get_current_active_user),
) -> DatasetDetailResponse:
    summary = data_service.get_dataset_summary(dataset_id=dataset_id, user_id=current_user.id)
    return DatasetDetailResponse(**summary)


@router.post(
    "/{dataset_id}/transform",
    status_code=status.HTTP_200_OK,
    summary="Execute validated predefined operations",
)
async def transform_dataset(
    dataset_id: str,
    payload: DataTransformRequest,
    current_user: UserResponse = Depends(get_current_active_user),
):
    ops = [
        {"operation": op.operation, "params": op.params or {}}
        for op in payload.operations
    ]
    return data_service.apply_operations(
        dataset_id=dataset_id,
        user_id=current_user.id,
        operations=ops,
    )


@router.post(
    "/{dataset_id}/report",
    response_model=DataReportResponse,
    status_code=status.HTTP_200_OK,
    summary="Generate natural-language business analysis report",
)
async def generate_dataset_report(
    dataset_id: str,
    current_user: UserResponse = Depends(get_current_active_user),
) -> DataReportResponse:
    rep = await data_service.generate_report(dataset_id=dataset_id, user_id=current_user.id)
    return DataReportResponse(**rep)


@router.get(
    "/{dataset_id}/download",
    status_code=status.HTTP_200_OK,
    summary="Download cleaned dataset as CSV",
)
async def download_cleaned_dataset(
    dataset_id: str,
    current_user: UserResponse = Depends(get_current_active_user),
):
    filename, file_bytes = data_service.export_dataset(dataset_id=dataset_id, user_id=current_user.id)
    return Response(
        content=file_bytes,
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@router.delete(
    "/{dataset_id}",
    status_code=status.HTTP_200_OK,
    summary="Delete dataset",
)
async def delete_dataset(
    dataset_id: str,
    current_user: UserResponse = Depends(get_current_active_user),
):
    data_service.delete_dataset(dataset_id=dataset_id, user_id=current_user.id)
    return {"status": "success", "message": "Dataset deleted."}
