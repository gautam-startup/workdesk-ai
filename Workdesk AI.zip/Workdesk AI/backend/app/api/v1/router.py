"""
WorkDesk AI - Version 1 API Router
Aggregates endpoints for all domain modules.
"""

from fastapi import APIRouter
from backend.app.api.v1.health import router as health_router
from backend.app.api.v1.auth import router as auth_router
from backend.app.api.v1.agents import router as agent_router
from backend.app.api.v1.documents import router as document_router
from backend.app.api.v1.data import router as data_router
from backend.app.api.v1.writer import router as writer_router

api_v1_router = APIRouter()

# Health & Diagnostic Routes
api_v1_router.include_router(health_router)

# Authentication & Account Routes
api_v1_router.include_router(auth_router)

# Multi-Agent Orchestrator Routes
api_v1_router.include_router(agent_router)

# Document Intelligence & RAG Routes
api_v1_router.include_router(document_router)

# Data Analysis Agent Routes
api_v1_router.include_router(data_router)

# Writer Agent & Multi-Tone Synthesis Routes
api_v1_router.include_router(writer_router)
