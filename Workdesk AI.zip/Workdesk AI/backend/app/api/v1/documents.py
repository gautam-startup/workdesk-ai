"""
WorkDesk AI - Document Agent REST API Endpoints
Handles document uploads, listing, details, deletion, and RAG Q&A with strict user ownership.
"""

import base64
from typing import List
from fastapi import APIRouter, Depends, Request, status
from backend.app.api.deps import get_current_active_user
from backend.app.core.exceptions import ValidationError
from backend.app.schemas.auth import UserResponse
from backend.app.schemas.document import (
    DocumentAskRequest,
    DocumentAskResponse,
    DocumentCitation,
    DocumentDetail,
    DocumentSummary,
    DocumentUploadBase64Request,
)
from backend.app.services.documents.service import document_service

router = APIRouter(prefix="/documents", tags=["Document Agent & RAG Pipeline"])


@router.post(
    "/upload",
    response_model=DocumentSummary,
    status_code=status.HTTP_201_CREATED,
    summary="Upload & Index Document (PDF, DOCX, TXT, PNG, JPG)",
)
async def upload_document(
    payload: DocumentUploadBase64Request,
    current_user: UserResponse = Depends(get_current_active_user),
) -> DocumentSummary:
    """Accepts base64-encoded document, runs deterministic extraction, chunks, and vector indexes."""
    try:
        file_bytes = base64.b64decode(payload.content_base64)
    except Exception:
        raise ValidationError("Invalid base64 payload. Could not decode file contents.")

    doc = await document_service.upload_document(
        user_id=current_user.id,
        filename=payload.filename,
        file_bytes=file_bytes,
        mime_type=payload.mime_type or "",
    )

    return DocumentSummary(**doc)


@router.get(
    "",
    response_model=List[DocumentSummary],
    status_code=status.HTTP_200_OK,
    summary="List authenticated user's documents",
)
async def list_documents(
    current_user: UserResponse = Depends(get_current_active_user),
) -> List[DocumentSummary]:
    """Returns all documents uploaded by the authenticated user."""
    docs = document_service.list_user_documents(user_id=current_user.id)
    return [DocumentSummary(**d) for d in docs]


@router.get(
    "/{document_id}",
    response_model=DocumentDetail,
    status_code=status.HTTP_200_OK,
    summary="Get document details & preview",
)
async def get_document(
    document_id: str,
    current_user: UserResponse = Depends(get_current_active_user),
) -> DocumentDetail:
    """Retrieves single document metadata and text preview."""
    doc = document_service.get_document(document_id=document_id, user_id=current_user.id)
    return DocumentDetail(**doc)


@router.delete(
    "/{document_id}",
    status_code=status.HTTP_200_OK,
    summary="Delete document and purge vector index",
)
async def delete_document(
    document_id: str,
    current_user: UserResponse = Depends(get_current_active_user),
):
    """Deletes document physical file and vector index after ownership check."""
    return document_service.delete_document(document_id=document_id, user_id=current_user.id)


@router.post(
    "/{document_id}/ask",
    response_model=DocumentAskResponse,
    status_code=status.HTTP_200_OK,
    summary="RAG Q&A or structured summary on document",
)
async def ask_document(
    document_id: str,
    payload: DocumentAskRequest,
    current_user: UserResponse = Depends(get_current_active_user),
) -> DocumentAskResponse:
    """Executes vector similarity retrieval and synthesizes answers with citations."""
    res = await document_service.ask_document(
        document_id=document_id,
        user_id=current_user.id,
        question=payload.question,
        mode=payload.mode or "qa",
    )

    citations = [
        DocumentCitation(
            page=c["page"],
            relevance_score=c["relevance_score"],
            snippet=c["snippet"],
        )
        for c in res.get("citations", [])
    ]

    return DocumentAskResponse(
        answer=res["answer"],
        citations=citations,
        pages_referenced=res.get("pages_referenced", []),
        confidence_score=res.get("confidence_score", 0.0),
    )
