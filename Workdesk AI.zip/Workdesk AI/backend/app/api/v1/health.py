"""
WorkDesk AI - Health Check API Endpoint
"""

from fastapi import APIRouter, status
from backend.app.core.config import settings
from backend.app.core.database import check_database_health
from backend.app.schemas.health import HealthCheckResponse
from backend.app.core.logging import logger

router = APIRouter(tags=["Health & System"])


@router.get(
    "/health",
    response_model=HealthCheckResponse,
    status_code=status.HTTP_200_OK,
    summary="System Health & Readiness Probe",
    description="Returns API status, active environment, and database connectivity state.",
)
async def get_health_status() -> HealthCheckResponse:
    """Performs a self-check and returns operational status."""
    db_status = await check_database_health()

    logger.debug("Health probe requested. Database status: %s", db_status)

    return HealthCheckResponse(
        status="healthy",
        project_name=settings.PROJECT_NAME,
        environment=settings.ENVIRONMENT,
        version="1.0.0",
        database=db_status,
        services={
            "api": "operational",
            "cors_configured": True,
            "database_driver": "asyncpg",
            "phase": "Phase 1 - Foundation & Project Structure",
        },
    )
