"""
WorkDesk AI - Authentication REST Endpoints
Endpoints for Signup, Login, Logout, Session User (/me), and Admin User Management.
"""

from typing import List
from fastapi import APIRouter, Depends, Request, status
from backend.app.api.deps import get_current_active_user, require_admin
from backend.app.core.rate_limit import rate_limiter
from backend.app.schemas.auth import UserCreate, UserLogin, UserResponse, TokenResponse
from backend.app.services.auth_service import auth_service
from backend.app.core.logging import logger

router = APIRouter(prefix="/auth", tags=["Authentication & Accounts"])


@router.post(
    "/signup",
    response_model=TokenResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create new user account",
)
async def signup(payload: UserCreate, request: Request) -> TokenResponse:
    """Registers a new user, hashes password, allocates 10 free credits, and returns JWT."""
    client_ip = request.client.host if request.client else "unknown"
    rate_limiter.check_rate_limit(f"signup:{client_ip}", max_requests=10, window_seconds=60)

    logger.info("Processing signup for email: %s", payload.email)
    return auth_service.register_user(payload)


@router.post(
    "/login",
    response_model=TokenResponse,
    status_code=status.HTTP_200_OK,
    summary="Authenticate and receive JWT",
)
async def login(payload: UserLogin, request: Request) -> TokenResponse:
    """Verifies credentials and returns a Bearer access token."""
    client_ip = request.client.host if request.client else "unknown"
    rate_limiter.check_rate_limit(f"login:{client_ip}", max_requests=15, window_seconds=60)

    logger.info("Login attempt for email: %s", payload.email)
    return auth_service.authenticate_user(payload)


@router.post(
    "/logout",
    status_code=status.HTTP_200_OK,
    summary="Invalidate session",
)
async def logout(current_user: UserResponse = Depends(get_current_active_user)):
    """Logs out user and confirms token invalidation."""
    logger.info("User %s logged out", current_user.email)
    return {
        "status": "success",
        "message": "Successfully logged out.",
    }


@router.get(
    "/me",
    response_model=UserResponse,
    status_code=status.HTTP_200_OK,
    summary="Current authenticated user profile & credit balance",
)
async def get_me(current_user: UserResponse = Depends(get_current_active_user)) -> UserResponse:
    """Returns the profile, role, credit balance, and active subscription of the requesting user."""
    return current_user


@router.get(
    "/admin/users",
    response_model=List[UserResponse],
    status_code=status.HTTP_200_OK,
    summary="Admin: List all registered users",
)
async def list_users_admin(admin_user: UserResponse = Depends(require_admin)) -> List[UserResponse]:
    """Admin-only endpoint listing all accounts in the system."""
    logger.info("Admin %s accessed user directory", admin_user.email)
    return auth_service.list_users()
