"""
WorkDesk AI - Writer Agent REST API Endpoints
Provides multi-format synthesis (Email, WhatsApp, Proposals, Social, Translation, Grammar)
with decoupled reusable prompt templates, credit deduction, history, and feedback.
"""

from typing import List
from fastapi import APIRouter, Depends, status
from backend.app.api.deps import get_current_active_user
from backend.app.schemas.auth import UserResponse
from backend.app.schemas.writer import (
    FeedbackRequest,
    SavedPromptCreate,
    SavedPromptResponse,
    WriterGenerateRequest,
    WriterGenerateResponse,
    WriterTemplateItem,
)
from backend.app.services.writer.service import writer_service
from backend.app.services.writer.templates import template_engine

router = APIRouter(prefix="/writer", tags=["Writer Agent & Synthesis"])


@router.post(
    "/generate",
    response_model=WriterGenerateResponse,
    status_code=status.HTTP_200_OK,
    summary="Generate written content with tone, format, and language controls",
)
async def generate_content(
    payload: WriterGenerateRequest,
    current_user: UserResponse = Depends(get_current_active_user),
) -> WriterGenerateResponse:
    res = await writer_service.generate_content(
        user_id=current_user.id,
        feature=payload.feature,
        input_text=payload.input_text,
        tone=payload.tone or "Professional",
        length=payload.length or "Medium",
        language=payload.language or "English",
        audience=payload.audience or "General",
        custom_instructions=payload.custom_instructions,
    )
    return WriterGenerateResponse(**res)


@router.get(
    "/templates",
    response_model=List[WriterTemplateItem],
    status_code=status.HTTP_200_OK,
    summary="List available reusable prompt templates and suggested tones",
)
async def list_templates() -> List[WriterTemplateItem]:
    templates = template_engine.list_templates()
    return [WriterTemplateItem(**t) for t in templates]


@router.get(
    "/history",
    response_model=List[WriterGenerateResponse],
    status_code=status.HTTP_200_OK,
    summary="List authenticated user's recent generations",
)
async def list_history(
    current_user: UserResponse = Depends(get_current_active_user),
) -> List[WriterGenerateResponse]:
    records = writer_service.list_history(user_id=current_user.id)
    return [WriterGenerateResponse(**r) for r in records]


@router.post(
    "/history/{generation_id}/feedback",
    status_code=status.HTTP_200_OK,
    summary="Record user thumbs up/down feedback on generation",
)
async def record_feedback(
    generation_id: str,
    payload: FeedbackRequest,
    current_user: UserResponse = Depends(get_current_active_user),
):
    return writer_service.record_feedback(
        generation_id=generation_id,
        user_id=current_user.id,
        rating=payload.rating,
        comment=payload.comment,
    )


@router.post(
    "/saved-prompts",
    response_model=SavedPromptResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Save a custom prompt template",
)
async def create_saved_prompt(
    payload: SavedPromptCreate,
    current_user: UserResponse = Depends(get_current_active_user),
) -> SavedPromptResponse:
    res = writer_service.save_prompt(
        user_id=current_user.id,
        title=payload.title,
        content=payload.content,
        feature=payload.feature or "email",
    )
    return SavedPromptResponse(**res)


@router.get(
    "/saved-prompts",
    response_model=List[SavedPromptResponse],
    status_code=status.HTTP_200_OK,
    summary="List authenticated user's saved prompts",
)
async def list_saved_prompts(
    current_user: UserResponse = Depends(get_current_active_user),
) -> List[SavedPromptResponse]:
    items = writer_service.list_saved_prompts(user_id=current_user.id)
    return [SavedPromptResponse(**i) for i in items]


@router.delete(
    "/saved-prompts/{prompt_id}",
    status_code=status.HTTP_200_OK,
    summary="Delete a saved prompt",
)
async def delete_saved_prompt(
    prompt_id: str,
    current_user: UserResponse = Depends(get_current_active_user),
):
    writer_service.delete_saved_prompt(prompt_id=prompt_id, user_id=current_user.id)
    return {"status": "success", "message": "Saved prompt deleted."}
