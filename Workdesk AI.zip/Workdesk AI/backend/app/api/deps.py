"""
WorkDesk AI - Authentication & Authorization FastAPI Dependencies
Provides route guards for JWT verification, active user checks, and Admin RBAC.
"""

from typing import Optional
try:
    from fastapi import Header, Depends
except ImportError:
    def Header(default=None):  # type: ignore
        return default
    def Depends(dependency=None):  # type: ignore
        return dependency
from backend.app.core.exceptions import UnauthorizedError, ForbiddenError
from backend.app.core.security import decode_access_token
from backend.app.schemas.auth import UserResponse
from backend.app.services.auth_service import auth_service


async def get_current_user(authorization: Optional[str] = Header(None)) -> UserResponse:
    """Dependency that extracts, decodes, and validates the Bearer JWT token."""
    if not authorization:
        raise UnauthorizedError("Authentication token is missing. Please log in.")

    parts = authorization.split()
    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise UnauthorizedError("Invalid Authorization header format. Expected 'Bearer <token>'.")

    token = parts[1]
    payload = decode_access_token(token)

    user_id = payload.get("sub")
    if not user_id:
        raise UnauthorizedError("Malformed token payload.")

    user_data = auth_service.get_user_by_id(user_id)
    if not user_data:
        raise UnauthorizedError("The user associated with this token no longer exists.")

    return UserResponse(**user_data)


async def get_current_active_user(
    current_user: UserResponse = Depends(get_current_user),
) -> UserResponse:
    """Ensures the authenticated user is currently active."""
    if not current_user.is_active:
        raise ForbiddenError("Account is inactive.")
    return current_user


async def require_admin(
    current_user: UserResponse = Depends(get_current_active_user),
) -> UserResponse:
    """Restricts route access exclusively to users with the 'admin' role."""
    if current_user.role != "admin":
        raise ForbiddenError("Administrator access required for this action.")
    return current_user
