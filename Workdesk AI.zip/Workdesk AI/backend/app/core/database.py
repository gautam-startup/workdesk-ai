"""
WorkDesk AI - PostgreSQL Database Connection & Session Management
Provides async and sync SQLAlchemy engines with connection pooling.
"""

from typing import AsyncGenerator
try:
    from sqlalchemy import create_engine
    from sqlalchemy.orm import declarative_base, sessionmaker
    from sqlalchemy.ext.asyncio import (
        AsyncSession,
        async_sessionmaker,
        create_async_engine,
    )
    Base = declarative_base()
except ImportError:
    class Base:  # type: ignore
        metadata = None
    create_engine = None  # type: ignore
    declarative_base = None  # type: ignore
    sessionmaker = None  # type: ignore
    AsyncSession = None  # type: ignore
    async_sessionmaker = None  # type: ignore
    create_async_engine = None  # type: ignore

from backend.app.core.config import settings
from backend.app.core.logging import logger

# Async Engine for high-performance FastAPI request handling
async_engine = None
AsyncSessionLocal = None

try:
    async_engine = create_async_engine(
        settings.DATABASE_URL,
        echo=settings.DEBUG,
        pool_pre_ping=True,
        pool_size=10,
        max_overflow=20,
    )
    AsyncSessionLocal = async_sessionmaker(
        bind=async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )
except Exception as e:
    logger.warning("Could not initialize async database engine: %s", e)

# Sync Engine for Alembic migrations and synchronous scripts
sync_engine = None
SyncSessionLocal = None

try:
    sync_engine = create_engine(
        settings.DATABASE_URL_SYNC,
        echo=False,
        pool_pre_ping=True,
    )
    SyncSessionLocal = sessionmaker(
        autocommit=False,
        autoflush=False,
        bind=sync_engine,
    )
except Exception as e:
    logger.warning("Could not initialize sync database engine: %s", e)


async def get_async_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency for obtaining an async database session."""
    if AsyncSessionLocal is None:
        raise RuntimeError("Async database session is not configured.")
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def check_database_health() -> str:
    """Verifies that the database is reachable and accepting queries."""
    if async_engine is None:
        return "not_configured"
    try:
        from sqlalchemy import text
        async with async_engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        return "connected"
    except Exception as exc:
        logger.error("Database health check failed: %s", exc)
        return "unreachable"
