"""
WorkDesk AI - Core Configuration Module
Loads and validates environment variables using Pydantic Settings.
"""

from typing import List, Union
try:
    from pydantic_settings import BaseSettings, SettingsConfigDict
    from pydantic import Field, field_validator
except ImportError:
    try:
        from pydantic import BaseSettings, Field, validator as field_validator  # type: ignore
        SettingsConfigDict = dict  # type: ignore
    except ImportError:
        # Graceful fallback stubs for non-pip test run environments
        class BaseSettings:  # type: ignore
            def __init__(self, **kwargs):
                # Copy class defaults
                for k in dir(self.__class__):
                    if not k.startswith("_") and not callable(getattr(self.__class__, k)):
                        val = getattr(self.__class__, k)
                        if isinstance(val, list):
                            val = list(val)
                        setattr(self, k, val)
                for k, v in kwargs.items():
                    if k == "CORS_ORIGINS" and isinstance(v, str):
                        v = [i.strip() for i in v.split(",") if i.strip()]
                    setattr(self, k, v)

        def field_validator(*args, **kwargs):  # type: ignore
            def decorator(fn):
                return fn
            return decorator

        def Field(*args, **kwargs):  # type: ignore
            return kwargs.get("default", None)

        class SettingsConfigDict(dict):  # type: ignore
            pass


class Settings(BaseSettings):
    """Application configuration settings."""

    # Project metadata
    PROJECT_NAME: str = "WorkDesk AI Backend"
    API_V1_PREFIX: str = "/api/v1"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    PORT: int = 8000
    HOST: str = "0.0.0.0"
    LOG_LEVEL: str = "INFO"

    # Security
    SECRET_KEY: str = "insecure-dev-secret-change-me-in-production-min-32-chars-long"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440

    # CORS configuration
    CORS_ORIGINS: Union[str, List[str]] = [
        "http://localhost:3000",
        "http://localhost:5173",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
    ]

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/workdesk_ai"
    DATABASE_URL_SYNC: str = "postgresql+psycopg2://postgres:postgres@localhost:5432/workdesk_ai"

    # Docker PostgreSQL settings
    POSTGRES_USER: str = "postgres"
    POSTGRES_PASSWORD: str = "postgres"
    POSTGRES_DB: str = "workdesk_ai"
    POSTGRES_PORT: int = 5432

    # AI Provider API Keys
    MISTRAL_API_KEY: str = ""
    GEMINI_API_KEY: str = ""
    GROQ_API_KEY: str = ""

    # Configuration-driven Model IDs
    DEFAULT_GROQ_MODEL: str = "llama-3.3-70b-versatile"
    DEFAULT_MISTRAL_MODEL: str = "mistral-large-latest"
    DEFAULT_GEMINI_MODEL: str = "gemini-2.5-flash"

    # Execution limits & Resilience
    LLM_TIMEOUT_SECONDS: int = 30
    LLM_MAX_RETRIES: int = 2
    LLM_PREFERRED_PROVIDER: str = "groq"

    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def assemble_cors_origins(cls, v: Union[str, List[str]]) -> List[str]:
        if isinstance(v, str) and not v.startswith("["):
            return [i.strip() for i in v.split(",") if i.strip()]
        elif isinstance(v, list):
            return v
        return []

    # Configure Pydantic Settings v2
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )


settings = Settings()
