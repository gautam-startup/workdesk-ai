"""
WorkDesk AI - Sliding Window Rate Limiting Foundation
Protects sensitive auth endpoints against brute-force attacks and abuse.
"""

import time
from collections import defaultdict
from typing import Dict, List
from backend.app.core.exceptions import RateLimitError


class InMemoryRateLimiter:
    """Sliding-window in-memory rate limiter per IP/client key."""

    def __init__(self, requests_per_minute: int = 60):
        self.requests_per_minute = requests_per_minute
        self.history: Dict[str, List[float]] = defaultdict(list)

    def check_rate_limit(self, key: str, max_requests: int = 10, window_seconds: int = 60) -> None:
        """Raises RateLimitError if client exceeds the maximum allowed requests."""
        now = time.time()
        window_start = now - window_seconds

        # Prune older entries
        self.history[key] = [t for t in self.history[key] if t > window_start]

        if len(self.history[key]) >= max_requests:
            raise RateLimitError(
                f"Rate limit exceeded: maximum {max_requests} requests per {window_seconds} seconds."
            )

        self.history[key].append(now)


rate_limiter = InMemoryRateLimiter()
