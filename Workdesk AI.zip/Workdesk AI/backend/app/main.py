"""
WorkDesk AI - Backend Application Entrypoint
FastAPI REST API with CORS, structured logging, centralized error handling, and health probes.
"""

import time
import uuid
from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from backend.app.api.v1.router import api_v1_router
from backend.app.core.config import settings
from backend.app.core.exceptions import AppException
from backend.app.core.logging import logger

# Initialize FastAPI instance
app = FastAPI(
    title=settings.PROJECT_NAME,
    version="1.0.0",
    description="One affordable AI workspace for everyday work - REST API backend.",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url=f"{settings.API_V1_PREFIX}/openapi.json",
)

# Configure Cross-Origin Resource Sharing (CORS)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["X-Request-ID", "X-Response-Time"],
)


@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
    """Logs incoming requests with correlation IDs and processing duration."""
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    request.state.request_id = request_id
    start_time = time.perf_counter()

    logger.info("--> %s %s [req_id=%s]", request.method, request.url.path, request_id)

    try:
        response = await call_next(request)
        process_time = (time.perf_counter() - start_time) * 1000
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Response-Time"] = f"{process_time:.2f}ms"

        logger.info(
            "<-- %s %s status=%d duration=%.2fms [req_id=%s]",
            request.method,
            request.url.path,
            response.status_code,
            process_time,
            request_id,
        )
        return response
    except Exception as exc:
        process_time = (time.perf_counter() - start_time) * 1000
        logger.error(
            "Unhandled server error on %s %s after %.2fms [req_id=%s]: %s",
            request.method,
            request.url.path,
            process_time,
            request_id,
            exc,
            exc_info=True,
        )
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error_code": "INTERNAL_SERVER_ERROR",
                "message": "An unexpected server error occurred. Please contact support.",
                "request_id": request_id,
            },
            headers={"X-Request-ID": request_id},
        )


# Global Exception Handlers
@app.exception_handler(AppException)
async def app_exception_handler(request: Request, exc: AppException):
    """Handles structured domain errors with explicit error codes."""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error_code": exc.error_code,
            "message": exc.message,
            "details": exc.details,
            "request_id": getattr(request.state, "request_id", None),
        },
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Formats Pydantic schema validation failures into clean client responses."""
    errors = []
    for err in exc.errors():
        field_loc = " -> ".join([str(loc) for loc in err.get("loc", [])])
        errors.append({"field": field_loc, "message": err.get("msg")})

    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "error_code": "VALIDATION_ERROR",
            "message": "The submitted payload failed validation.",
            "details": {"validation_errors": errors},
            "request_id": getattr(request.state, "request_id", None),
        },
    )


@app.exception_handler(StarletteHTTPException)
async def starlette_http_exception_handler(request: Request, exc: StarletteHTTPException):
    """Handles standard HTTP errors (e.g., 404, 405) in uniform format."""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error_code": f"HTTP_{exc.status_code}",
            "message": str(exc.detail),
            "details": {},
            "request_id": getattr(request.state, "request_id", None),
        },
    )


# Mount versioned API routes
app.include_router(api_v1_router, prefix=settings.API_V1_PREFIX)


# Root diagnostic endpoint
@app.get("/", tags=["Diagnostic"])
async def root():
    return {
        "project": settings.PROJECT_NAME,
        "version": "1.0.0",
        "health": f"{settings.API_V1_PREFIX}/health",
        "docs": "/docs",
    }
