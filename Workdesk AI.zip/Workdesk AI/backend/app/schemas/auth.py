"""
WorkDesk AI - Authentication & User Schemas
"""

from datetime import datetime
from typing import Optional
from backend.app.schemas.health import BaseModel, Field


class UserCreate(BaseModel):
    email: str = Field(..., example="alex@example.com")
    password: str = Field(..., min_length=8, example="StrongPassword123!")
    full_name: str = Field(..., min_length=2, example="Alex Morgan")


class UserLogin(BaseModel):
    email: str = Field(..., example="alex@example.com")
    password: str = Field(..., example="StrongPassword123!")


class UserResponse(BaseModel):
    id: str
    email: str
    full_name: str
    role: str
    is_active: bool
    is_verified: bool
    created_at: datetime
    credit_balance: int = 10
    plan_slug: str = "free"
    plan_name: str = "Free Starter"


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int = 86400
    user: UserResponse
