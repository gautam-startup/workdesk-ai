"""
WorkDesk AI - Document REST API Schemas
"""

from typing import Any, Dict, List, Optional
from backend.app.schemas.health import BaseModel, Field


class DocumentSummary(BaseModel):
    id: str
    filename: str
    file_size: int
    mime_type: str
    status: str
    total_pages: int
    total_chunks: int
    created_at: str
    injections_neutralized: int = 0


class DocumentDetail(DocumentSummary):
    text_preview: Optional[str] = None


class DocumentUploadBase64Request(BaseModel):
    filename: str = Field(..., example="contract.pdf")
    content_base64: str = Field(..., description="Base64 encoded file bytes")
    mime_type: Optional[str] = Field(default="", example="application/pdf")


class DocumentAskRequest(BaseModel):
    question: str = Field(..., min_length=2, example="What is the total invoice amount and due date?")
    mode: Optional[str] = Field(default="qa", example="qa")  # "qa", "summary", "key_points", "action_items"


class DocumentCitation(BaseModel):
    page: int
    relevance_score: float
    snippet: str


class DocumentAskResponse(BaseModel):
    answer: str
    citations: List[DocumentCitation] = Field(default_factory=list)
    pages_referenced: List[int] = Field(default_factory=list)
    confidence_score: float = 0.0
