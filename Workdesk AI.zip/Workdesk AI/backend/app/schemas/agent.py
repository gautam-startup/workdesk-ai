"""
WorkDesk AI - Agent REST Schemas
"""

from typing import List, Optional
from backend.app.schemas.health import BaseModel, Field
from backend.app.services.agents.state import ExecutionStep


class AgentRunRequest(BaseModel):
    task: str = Field(..., min_length=2, example="Write an email follow-up for client meeting")
    agent_override: Optional[str] = Field(default=None, example="writer")
    file_attachment_name: Optional[str] = None


class AgentEstimateRequest(BaseModel):
    task: str = Field(..., example="Analyze this 50-page PDF document")
    has_file: bool = False
    file_size_mb: float = 0.0


class AgentEstimateResponse(BaseModel):
    task_type: str
    recommended_agent: str
    estimated_credits: int
    complexity: str


class AgentRunResponse(BaseModel):
    task: str
    selected_agent: str
    credits_cost: int
    remaining_credits: int
    safe_steps: List[ExecutionStep]
    final_output: str
    current_status: str
