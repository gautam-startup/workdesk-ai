"""
WorkDesk AI - Writer Agent REST API Schemas
"""

from typing import Any, Dict, List, Optional
from backend.app.schemas.health import BaseModel, Field


class WriterGenerateRequest(BaseModel):
    feature: str = Field(
        ...,
        example="email",
        description="email | whatsapp | proposal | report | social | rewrite | summarize | translate | grammar",
    )
    input_text: str = Field(..., min_length=1, example="Meeting follow-up regarding Q3 deliverables and next steps.")
    tone: Optional[str] = Field(default="Professional", example="Professional")
    length: Optional[str] = Field(default="Medium", example="Medium")
    language: Optional[str] = Field(default="English", example="English")  # "English", "Hindi", "Hinglish"
    audience: Optional[str] = Field(default="General", example="General")
    custom_instructions: Optional[str] = Field(default=None, example="Include call-to-action link to calendar.")


class WriterGenerateResponse(BaseModel):
    id: str
    feature: str
    input_text: str
    output_text: str
    tone: str
    length: str
    language: str
    audience: str
    provider_used: str
    model_used: str
    credits_deducted: int
    remaining_credits: int
    duration_ms: int
    created_at: str
    feedback: Optional[Dict[str, Any]] = None


class FeedbackRequest(BaseModel):
    rating: int = Field(..., description="1 for positive / helpful, -1 for negative")
    comment: Optional[str] = Field(default=None, max_length=500)


class SavedPromptCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=100, example="Vendor Follow-up Template")
    content: str = Field(..., min_length=1, example="Follow up with {vendor} regarding {item} invoice.")
    feature: Optional[str] = Field(default="email", example="email")


class SavedPromptResponse(BaseModel):
    id: str
    title: str
    content: str
    feature: str
    created_at: str


class WriterTemplateItem(BaseModel):
    id: str
    name: str
    feature: str
    description: str
    suggested_tones: List[str]
