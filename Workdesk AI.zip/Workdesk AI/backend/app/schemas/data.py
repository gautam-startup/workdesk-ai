"""
WorkDesk AI - Data Agent REST Schemas
"""

from typing import Any, Dict, List, Optional
from backend.app.schemas.health import BaseModel, Field


class DataUploadBase64Request(BaseModel):
    filename: str = Field(..., example="sales_q3.csv")
    content_base64: str = Field(..., description="Base64 encoded CSV or XLSX bytes")


class SafeOperationItem(BaseModel):
    operation: str = Field(..., example="remove_duplicates")
    params: Optional[Dict[str, Any]] = Field(default_factory=dict)


class DataTransformRequest(BaseModel):
    operations: List[SafeOperationItem] = Field(...)


class DatasetSummaryResponse(BaseModel):
    id: str
    filename: str
    format: str
    total_rows: int
    total_columns: int
    quality_score: int
    created_at: str


class DataIssueItem(BaseModel):
    type: str
    severity: str
    message: str
    suggested_action: Optional[str] = None
    suggested_params: Optional[Dict[str, Any]] = None
    column: Optional[str] = None


class DataChartItem(BaseModel):
    chart_type: str
    title: str
    x_label: Optional[str] = None
    y_label: Optional[str] = None
    labels: List[str] = Field(default_factory=list)
    values: List[Any] = Field(default_factory=list)


class DataProfile(BaseModel):
    filename: str
    total_rows: int
    total_columns: int
    column_types: Dict[str, str] = Field(default_factory=dict)
    null_counts: Dict[str, int] = Field(default_factory=dict)
    total_missing_cells: int = 0
    missing_percentage: float = 0.0
    duplicate_rows: int = 0
    duplicate_percentage: float = 0.0
    quality_score: int = 100
    detected_issues: List[DataIssueItem] = Field(default_factory=list)
    statistics: Dict[str, Any] = Field(default_factory=dict)
    charts: List[DataChartItem] = Field(default_factory=list)


class DatasetDetailResponse(BaseModel):
    id: str
    filename: str
    format: str
    profile: DataProfile
    columns: List[str] = Field(default_factory=list)
    preview_rows: List[Dict[str, Any]] = Field(default_factory=list)
    created_at: str
    updated_at: str
    history: List[Dict[str, Any]] = Field(default_factory=list)


class DataReportResponse(BaseModel):
    dataset_id: str
    filename: str
    quality_score: int
    analysis_report: str
    generated_at: str
