"""
WorkDesk AI - Health Check Schemas
"""

from datetime import datetime
from typing import Dict, Any
try:
    from pydantic import BaseModel, Field
except ImportError:
    class BaseModel:  # type: ignore
        def __init__(self, **kwargs):
            for k in dir(self.__class__):
                if not k.startswith("_") and not callable(getattr(self.__class__, k)):
                    val = getattr(self.__class__, k)
                    setattr(self, k, val)
            for k, v in kwargs.items():
                setattr(self, k, v)
            if not hasattr(self, "version"):
                self.version = "1.0.0"
            if not hasattr(self, "timestamp"):
                self.timestamp = datetime.utcnow()
            if not hasattr(self, "services"):
                self.services = {
                    "api": "operational",
                    "routing": "ready",
                    "agent_orchestrator": "ready",
                }
            if not hasattr(self, "plan_steps") or self.plan_steps is None:
                self.plan_steps = []
            if not hasattr(self, "safe_steps") or self.safe_steps is None:
                self.safe_steps = []
            if not hasattr(self, "tool_calls") or self.tool_calls is None:
                self.tool_calls = []
            if not hasattr(self, "duration_ms"):
                self.duration_ms = 0
            if not hasattr(self, "status"):
                self.status = "completed"
            if not hasattr(self, "current_status"):
                self.current_status = "initialized"
            if not hasattr(self, "selected_agent"):
                self.selected_agent = "supervisor"
            if not hasattr(self, "task_type"):
                self.task_type = "general"
            if not hasattr(self, "final_output"):
                self.final_output = ""
            if not hasattr(self, "credits_cost"):
                self.credits_cost = 1
            if not hasattr(self, "error"):
                self.error = None

    def Field(*args, **kwargs):  # type: ignore
        return kwargs.get("default", None)


class HealthCheckResponse(BaseModel):
    """Schema for GET /api/v1/health response."""

    status: str = Field(..., example="healthy")
    project_name: str = Field(..., example="WorkDesk AI Backend")
    environment: str = Field(..., example="development")
    version: str = Field(default="1.0.0", example="1.0.0")
    database: str = Field(..., example="connected")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    services: Dict[str, Any] = Field(
        default_factory=lambda: {
            "api": "operational",
            "routing": "ready",
            "agent_orchestrator": "ready",
        }
    )
