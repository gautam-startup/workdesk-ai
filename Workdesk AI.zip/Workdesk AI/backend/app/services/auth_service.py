"""
WorkDesk AI - Authentication & User Service
Handles user creation, credential validation, initial credit allocation, and session management.
Supports both SQLAlchemy database persistence and an in-memory store for instant testing.
"""

from datetime import datetime
from typing import Dict, List, Optional
from backend.app.core.exceptions import AppException, NotFoundError, UnauthorizedError, ValidationError
from backend.app.core.security import hash_password, verify_password, create_access_token
from backend.app.models.base import generate_uuid
from backend.app.models.user import UserRole
from backend.app.schemas.auth import UserCreate, UserLogin, UserResponse, TokenResponse

# In-memory storage fallback for standalone testing and dev environments
_IN_MEMORY_USERS: Dict[str, dict] = {}
_INITIALIZED_SEEDS = False


def _ensure_seeds():
    global _INITIALIZED_SEEDS
    if not _INITIALIZED_SEEDS:
        # Seed default Admin and Demo User
        admin_id = "00000000-0000-0000-0000-000000000001"
        _IN_MEMORY_USERS["admin@workdesk.ai"] = {
            "id": admin_id,
            "email": "admin@workdesk.ai",
            "password_hash": hash_password("AdminSecure2026!"),
            "full_name": "WorkDesk Admin",
            "role": UserRole.ADMIN.value,
            "is_active": True,
            "is_verified": True,
            "created_at": datetime.utcnow(),
            "credit_balance": 1000,
            "plan_slug": "business",
            "plan_name": "Business Workspace",
        }

        user_id = "00000000-0000-0000-0000-000000000002"
        _IN_MEMORY_USERS["demo@workdesk.ai"] = {
            "id": user_id,
            "email": "demo@workdesk.ai",
            "password_hash": hash_password("DemoPassword123!"),
            "full_name": "Demo Professional",
            "role": UserRole.USER.value,
            "is_active": True,
            "is_verified": True,
            "created_at": datetime.utcnow(),
            "credit_balance": 10,
            "plan_slug": "free",
            "plan_name": "Free Starter",
        }
        _INITIALIZED_SEEDS = True


class AuthService:
    def __init__(self):
        _ensure_seeds()

    def get_user_by_email(self, email: str) -> Optional[dict]:
        email_clean = email.strip().lower()
        return _IN_MEMORY_USERS.get(email_clean)

    def get_user_by_id(self, user_id: str) -> Optional[dict]:
        for u in _IN_MEMORY_USERS.values():
            if u["id"] == user_id:
                return u
        return None

    def register_user(self, payload: UserCreate, role: str = UserRole.USER.value) -> TokenResponse:
        email_clean = payload.email.strip().lower()

        # Check duplicate email
        if email_clean in _IN_MEMORY_USERS:
            raise AppException(
                status_code=409,
                error_code="EMAIL_ALREADY_EXISTS",
                message=f"An account with email '{email_clean}' already exists.",
            )

        if len(payload.password) < 8:
            raise ValidationError("Password must be at least 8 characters long.")

        user_id = generate_uuid()
        user_record = {
            "id": user_id,
            "email": email_clean,
            "password_hash": hash_password(payload.password),
            "full_name": payload.full_name.strip(),
            "role": role,
            "is_active": True,
            "is_verified": False,
            "created_at": datetime.utcnow(),
            "credit_balance": 10,  # 10 initial free credits
            "plan_slug": "free",
            "plan_name": "Free Starter",
        }

        _IN_MEMORY_USERS[email_clean] = user_record

        # Generate JWT token
        token_payload = {
            "sub": user_id,
            "email": email_clean,
            "role": role,
        }
        token = create_access_token(token_payload)

        return TokenResponse(
            access_token=token,
            token_type="bearer",
            expires_in=86400,
            user=UserResponse(**user_record),
        )

    def authenticate_user(self, payload: UserLogin) -> TokenResponse:
        email_clean = payload.email.strip().lower()
        user_record = _IN_MEMORY_USERS.get(email_clean)

        if not user_record:
            raise UnauthorizedError("Invalid email or password.")

        if not verify_password(payload.password, user_record["password_hash"]):
            raise UnauthorizedError("Invalid email or password.")

        if not user_record.get("is_active", True):
            raise AppException(
                status_code=403,
                error_code="USER_INACTIVE",
                message="Your account has been deactivated. Please contact support.",
            )

        token_payload = {
            "sub": user_record["id"],
            "email": user_record["email"],
            "role": user_record["role"],
        }
        token = create_access_token(token_payload)

        return TokenResponse(
            access_token=token,
            token_type="bearer",
            expires_in=86400,
            user=UserResponse(**user_record),
        )

    def list_users(self) -> List[UserResponse]:
        return [UserResponse(**u) for u in _IN_MEMORY_USERS.values()]


auth_service = AuthService()
