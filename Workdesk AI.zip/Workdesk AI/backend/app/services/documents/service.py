"""
WorkDesk AI - Document Service & Ownership Enforcement
Provides CRUD operations, isolation between users, and coordinates extraction & vector indexing.
"""

import time
from datetime import datetime
from typing import Dict, List, Optional
from backend.app.core.exceptions import AppException, ForbiddenError, NotFoundError
from backend.app.core.logging import logger
from backend.app.models.base import generate_uuid
from backend.app.services.documents.chunking import chunk_document_pages
from backend.app.services.documents.extractor import document_extractor
from backend.app.services.documents.rag import document_rag
from backend.app.services.documents.storage import document_storage
from backend.app.services.documents.vector_store import vector_store

# In-memory document metadata store for immediate dev/test & database bridge
_DOCUMENTS_DB: Dict[str, dict] = {}


class DocumentService:
    async def upload_document(
        self,
        user_id: str,
        filename: str,
        file_bytes: bytes,
        mime_type: str = "",
    ) -> dict:
        """Validates, stores, deterministically extracts, chunks, and indexes a user document."""
        # 1. Validation
        safe_filename, ext = document_storage.validate_file(filename, file_bytes, mime_type)

        # 2. Save physical file to isolated directory
        file_id, storage_path, sha256_hash = document_storage.save_file(
            user_id=user_id,
            filename=safe_filename,
            file_bytes=file_bytes,
        )

        doc_id = str(file_id)
        file_size = len(file_bytes)

        # 3. Deterministic Text Extraction
        extract_res = document_extractor.extract(file_bytes, ext)

        # 4. Semantic Chunking
        chunks = chunk_document_pages(
            document_id=doc_id,
            pages=extract_res.pages,
            chunk_size=700,
            chunk_overlap=120,
        )

        # 5. Vector Store Indexing
        indexed_count = vector_store.index_chunks(doc_id, chunks)

        # 6. Save Record
        doc_record = {
            "id": doc_id,
            "user_id": user_id,
            "filename": safe_filename,
            "file_size": file_size,
            "mime_type": mime_type or f"application/{ext.lstrip('.')}",
            "storage_path": storage_path,
            "status": "ready",
            "total_pages": extract_res.total_pages,
            "total_words": extract_res.total_words,
            "total_chunks": indexed_count,
            "injections_neutralized": extract_res.injections_detected,
            "sha256": sha256_hash,
            "created_at": datetime.utcnow().isoformat(),
            # Sample preview for instant summarization without reloading file
            "text_preview": "\n".join(p.text for p in extract_res.pages[:3])[:2000],
        }

        _DOCUMENTS_DB[doc_id] = doc_record

        # DO NOT log content in server logs
        logger.info(
            "Document uploaded & indexed: id=%s user_id=%s filename=%s pages=%d chunks=%d",
            doc_id, user_id, safe_filename, extract_res.total_pages, indexed_count
        )

        return doc_record

    def list_user_documents(self, user_id: str) -> List[dict]:
        """Returns only documents belonging to the requesting user."""
        docs = [d for d in _DOCUMENTS_DB.values() if d["user_id"] == user_id]
        docs.sort(key=lambda x: x["created_at"], reverse=True)
        return docs

    def get_document(self, document_id: str, user_id: str) -> dict:
        """Retrieves document if owned by user; throws 404 or 403 otherwise."""
        doc = _DOCUMENTS_DB.get(document_id)
        if not doc:
            raise NotFoundError("Document not found.")

        if doc["user_id"] != user_id:
            raise ForbiddenError("You do not have permission to access this document.")

        return doc

    def delete_document(self, document_id: str, user_id: str) -> dict:
        """Deletes physical file, vector index, and metadata record after ownership check."""
        doc = self.get_document(document_id, user_id)

        # 1. Remove physical file
        document_storage.delete_file(doc["storage_path"])

        # 2. Purge vector index
        vector_store.delete_document_index(document_id)

        # 3. Remove metadata record
        del _DOCUMENTS_DB[document_id]

        logger.info("Document deleted: id=%s user_id=%s", document_id, user_id)
        return {"status": "success", "message": f"Document '{doc['filename']}' deleted successfully."}

    async def ask_document(
        self,
        document_id: str,
        user_id: str,
        question: str,
        mode: str = "qa",
    ) -> dict:
        """Executes RAG Q&A or structured summarization against user's owned document."""
        doc = self.get_document(document_id, user_id)

        if mode == "summary":
            return await document_rag.generate_summary_and_insights(
                document_id=doc["id"],
                filename=doc["filename"],
                total_pages=doc["total_pages"],
                all_text_preview=doc.get("text_preview", ""),
            )

        # Default Q&A mode
        return await document_rag.answer_question(
            document_id=doc["id"],
            filename=doc["filename"],
            question=question,
        )


document_service = DocumentService()
