"""
WorkDesk AI - Document Storage Abstraction
Handles local disk storage, mime-type verification, file size limits, and checksums.
"""

import hashlib
import os
import uuid
from typing import Dict, Set, Tuple
from backend.app.core.exceptions import AppException, ValidationError

# Allowed MIME types and extensions
ALLOWED_EXTENSIONS: Set[str] = {".pdf", ".docx", ".txt", ".png", ".jpg", ".jpeg"}

MIME_TYPE_MAPPING: Dict[str, str] = {
    "application/pdf": ".pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "text/plain": ".txt",
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
}

MAX_FILE_SIZE_MB = 25
MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024


class DocumentStorage:
    def __init__(self, base_dir: str = "uploads/documents"):
        self.base_dir = os.path.abspath(base_dir)
        os.makedirs(self.base_dir, exist_ok=True)

    def validate_file(self, filename: str, file_bytes: bytes, mime_type: str = "") -> Tuple[str, str]:
        """Validates extension, size, and returns sanitized (filename, extension)."""
        _, ext = os.path.splitext(filename.lower())

        if ext not in ALLOWED_EXTENSIONS:
            raise ValidationError(
                f"Unsupported file format '{ext}'. Supported formats: PDF, DOCX, TXT, PNG, JPG/JPEG."
            )

        file_size = len(file_bytes)
        if file_size == 0:
            raise ValidationError("Uploaded file is empty.")

        if file_size > MAX_FILE_SIZE_BYTES:
            raise ValidationError(
                f"File size exceeds limit of {MAX_FILE_SIZE_MB}MB (received {file_size / (1024 * 1024):.1f}MB)."
            )

        # Basic mime check
        normalized_mime = mime_type.lower() if mime_type else ""
        if normalized_mime and normalized_mime in MIME_TYPE_MAPPING:
            expected_ext = MIME_TYPE_MAPPING[normalized_mime]
            if ext != expected_ext and not (ext in [".jpg", ".jpeg"] and expected_ext in [".jpg", ".jpeg"]):
                # Warn or normalize extension
                pass

        return os.path.basename(filename), ext

    def save_file(self, user_id: str, filename: str, file_bytes: bytes) -> Tuple[str, str, str]:
        """
        Saves raw bytes into user-isolated storage directory.
        Returns: (file_id, storage_path, sha256_hash)
        """
        user_dir = os.path.join(self.base_dir, user_id)
        os.makedirs(user_dir, exist_ok=True)

        file_id = str(uuid.uuid4())
        _, ext = os.path.splitext(filename)
        safe_filename = f"{file_id}{ext}"
        storage_path = os.path.join(user_dir, safe_filename)

        sha256 = hashlib.sha256(file_bytes).hexdigest()

        with open(storage_path, "wb") as f:
            f.write(file_bytes)

        return file_id, storage_path, sha256

    def read_file(self, storage_path: str) -> bytes:
        if not os.path.exists(storage_path):
            raise AppException(status_code=404, error_code="FILE_NOT_FOUND", message="Storage file not found.")
        with open(storage_path, "rb") as f:
            return f.read()

    def delete_file(self, storage_path: str) -> bool:
        if os.path.exists(storage_path):
            try:
                os.remove(storage_path)
                return True
            except OSError:
                return False
        return False


document_storage = DocumentStorage()
