"""
WorkDesk AI - Semantic & Overlapping Document Chunking Engine
Splits extracted document pages into retrieval-ready passages preserving page boundaries.
"""

import uuid
from dataclasses import dataclass
from typing import List
from backend.app.services.documents.extractor import ExtractedPage


@dataclass
class DocumentChunk:
    id: str
    document_id: str
    chunk_index: int
    page_number: int
    text: str
    word_count: int
    char_length: int


def chunk_document_pages(
    document_id: str,
    pages: List[ExtractedPage],
    chunk_size: int = 800,
    chunk_overlap: int = 150,
) -> List[DocumentChunk]:
    """
    Splits each page into overlapping chunks.
    Preserves exact page references for accurate citations.
    """
    all_chunks: List[DocumentChunk] = []
    chunk_idx = 0

    for page in pages:
        text = page.text.strip()
        if not text:
            continue

        start = 0
        text_len = len(text)

        while start < text_len:
            end = min(start + chunk_size, text_len)

            # Try to snap to the end of a sentence or newline if nearby
            if end < text_len:
                last_period = text.rfind(". ", start, end)
                last_newline = text.rfind("\n", start, end)
                snap_point = max(last_period, last_newline)
                if snap_point > start + (chunk_size // 2):
                    end = snap_point + 1

            chunk_text = text[start:end].strip()
            if chunk_text:
                all_chunks.append(
                    DocumentChunk(
                        id=str(uuid.uuid4()),
                        document_id=document_id,
                        chunk_index=chunk_idx,
                        page_number=page.page_number,
                        text=chunk_text,
                        word_count=len(chunk_text.split()),
                        char_length=len(chunk_text),
                    )
                )
                chunk_idx += 1

            start += chunk_size - chunk_overlap
            if start >= text_len or end >= text_len:
                break

    return all_chunks
