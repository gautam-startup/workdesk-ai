"""
WorkDesk AI - Document RAG Pipeline & Multi-Modal Intelligence
Handles document Q&A, executive summaries, key points, action items, and comparison foundations.
Ensures answers cite exact page numbers and never expose raw internal prompts.
"""

from typing import List, Optional
from backend.app.services.ai.router import ai_router
from backend.app.services.documents.vector_store import RetrievedChunk, vector_store


class DocumentRAGPipeline:
    async def answer_question(
        self,
        document_id: str,
        filename: str,
        question: str,
        top_k: int = 4,
    ) -> dict:
        """Retrieves relevant chunks and generates an answer with page-level citations."""
        retrieved_chunks = vector_store.similarity_search(document_id, question, top_k=top_k)

        if not retrieved_chunks:
            return {
                "answer": f"I couldn't locate relevant sections in '{filename}' to answer your question. Please verify the question or re-upload the document.",
                "citations": [],
                "pages_referenced": [],
                "confidence_score": 0.0,
            }

        # Build context with strict delimiter tagging
        context_blocks = []
        pages_referenced = sorted(list(set(c.page_number for c in retrieved_chunks)))
        citations = []

        for c in retrieved_chunks:
            context_blocks.append(f"<document_page number='{c.page_number}'>\n{c.chunk.text}\n</document_page>")
            citations.append({
                "page": c.page_number,
                "relevance_score": c.similarity_score,
                "snippet": c.chunk.text[:140] + "...",
            })

        context_str = "\n\n".join(context_blocks)

        system_prompt = (
            "You are the WorkDesk AI Document Intelligence Agent. "
            "Answer the user's question using ONLY the provided document excerpts. "
            "Cite page numbers explicitly in your answer (e.g., [Page 1], [Page 2]). "
            "If the document excerpts do not contain the answer, state that clearly. "
            "Do NOT include internal thoughts or reasoning."
        )

        user_prompt = (
            f"DOCUMENT: {filename}\n\n"
            f"EXCERPTS:\n{context_str}\n\n"
            f"QUESTION: {question}\n\n"
            f"Please provide a clear, factual answer with page citations:"
        )

        llm_resp = await ai_router.generate_with_fallback(
            prompt=user_prompt,
            system_prompt=system_prompt,
            complexity="medium",
        )

        # Ensure answer has citation references
        answer_text = llm_resp.content.strip()
        if "page" not in answer_text.lower() and pages_referenced:
            page_tags = ", ".join(f"Page {p}" for p in pages_referenced)
            answer_text += f"\n\n*(Reference: {page_tags})*"

        return {
            "answer": answer_text,
            "citations": citations,
            "pages_referenced": pages_referenced,
            "confidence_score": max(c.similarity_score for c in retrieved_chunks),
        }

    async def generate_summary_and_insights(
        self,
        document_id: str,
        filename: str,
        total_pages: int,
        all_text_preview: str,
    ) -> dict:
        """Generates executive summary, bulleted key points, and action items."""
        system_prompt = (
            "You are the WorkDesk AI Document Agent. "
            "Analyze the document excerpt and produce a structured briefing with: "
            "1. Executive Summary\n"
            "2. Key Takeaways (bulleted)\n"
            "3. Action Items & Deadlines (bulleted)\n"
            "Format with clean Markdown."
        )

        user_prompt = (
            f"DOCUMENT: {filename} (Total Pages: {total_pages})\n\n"
            f"CONTENT SAMPLE:\n{all_text_preview[:3000]}\n\n"
            f"Provide an executive summary, key points, and action items:"
        )

        llm_resp = await ai_router.generate_with_fallback(
            prompt=user_prompt,
            system_prompt=system_prompt,
            complexity="medium",
        )

        content = llm_resp.content.strip()

        return {
            "executive_summary": content,
            "filename": filename,
            "total_pages": total_pages,
            "provider_used": llm_resp.provider,
        }

    def compare_documents(
        self,
        doc_a_name: str,
        doc_a_chunks: List[str],
        doc_b_name: str,
        doc_b_chunks: List[str],
    ) -> dict:
        """Foundation for cross-document differential comparison."""
        words_a = set(" ".join(doc_a_chunks).lower().split())
        words_b = set(" ".join(doc_b_chunks).lower().split())

        common_terms = len(words_a.intersection(words_b))
        unique_a = len(words_a - words_b)
        unique_b = len(words_b - words_a)

        similarity_ratio = round(common_terms / max(1, len(words_a.union(words_b))), 2)

        return {
            "doc_a": doc_a_name,
            "doc_b": doc_b_name,
            "lexical_similarity": similarity_ratio,
            "shared_terminology_count": common_terms,
            "unique_terms_doc_a": unique_a,
            "unique_terms_doc_b": unique_b,
            "comparison_status": "Differences detected in terms and structure.",
        }


document_rag = DocumentRAGPipeline()
