"""
WorkDesk AI - Vector Storage & Embeddings Abstraction
Supports similarity retrieval with cosine distance, ranking, and page citations.
"""

import math
import re
from dataclasses import dataclass
from typing import Dict, List, Tuple
from backend.app.services.documents.chunking import DocumentChunk

EMBEDDING_DIM = 128


def compute_fast_embedding(text: str) -> List[float]:
    """
    Computes a deterministic 128-dimensional dense semantic embedding vector
    using term frequency, token hashes, and bigram features.
    """
    words = re.findall(r"\b\w+\b", text.lower())
    vec = [0.0] * EMBEDDING_DIM

    if not words:
        return vec

    # Unigram features
    for word in words:
        h = hash(word) % EMBEDDING_DIM
        vec[h] += 1.0

    # Bigram features for contextual phrase matching
    for i in range(len(words) - 1):
        bigram = f"{words[i]}_{words[i+1]}"
        h = hash(bigram) % EMBEDDING_DIM
        vec[h] += 1.5

    # L2 normalize
    norm = math.sqrt(sum(v * v for v in vec))
    if norm > 0:
        vec = [v / norm for v in vec]

    return vec


def cosine_similarity(v1: List[float], v2: List[float]) -> float:
    """Computes cosine similarity between two normalized vectors."""
    dot = sum(a * b for a, b in zip(v1, v2))
    return max(0.0, min(1.0, dot))


@dataclass
class RetrievedChunk:
    chunk: DocumentChunk
    similarity_score: float
    page_number: int


class VectorStore:
    def __init__(self):
        # document_id -> list of (chunk, vector)
        self.storage: Dict[str, List[Tuple[DocumentChunk, List[float]]]] = {}

    def index_chunks(self, document_id: str, chunks: List[DocumentChunk]) -> int:
        """Embeds and indexes chunks for a document."""
        indexed = []
        for chunk in chunks:
            vec = compute_fast_embedding(chunk.text)
            indexed.append((chunk, vec))

        self.storage[document_id] = indexed
        return len(indexed)

    def similarity_search(
        self, document_id: str, query: str, top_k: int = 4, min_score: float = 0.05
    ) -> List[RetrievedChunk]:
        """Performs cosine similarity search against indexed document chunks."""
        entries = self.storage.get(document_id, [])
        if not entries:
            return []

        query_vec = compute_fast_embedding(query)
        scored: List[RetrievedChunk] = []

        for chunk, chunk_vec in entries:
            sim = cosine_similarity(query_vec, chunk_vec)
            # Boost score if query keywords appear directly in chunk
            q_words = set(re.findall(r"\b\w{3,}\b", query.lower()))
            chunk_words = set(re.findall(r"\b\w{3,}\b", chunk.text.lower()))
            overlap = len(q_words.intersection(chunk_words))
            if overlap > 0:
                sim = min(1.0, sim + (overlap * 0.15))

            if sim >= min_score:
                scored.append(
                    RetrievedChunk(
                        chunk=chunk,
                        similarity_score=round(sim, 4),
                        page_number=chunk.page_number,
                    )
                )

        scored.sort(key=lambda x: x.similarity_score, reverse=True)
        return scored[:top_k]

    def delete_document_index(self, document_id: str) -> bool:
        if document_id in self.storage:
            del self.storage[document_id]
            return True
        return False


vector_store = VectorStore()
