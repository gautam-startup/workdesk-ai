"""
WorkDesk AI - Reusable Writer Prompt Templates & Catalog
Decoupled template engine for professional writing, messaging, rewriting, and translation.
Supports English, Hindi, and Hinglish with customizable tone, audience, and length constraints.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass
class PromptTemplate:
    id: str
    name: str
    feature: str  # email, whatsapp, proposal, report, social, rewrite, summarize, translate, grammar
    description: str
    system_prompt: str
    user_prompt_pattern: str
    suggested_tones: List[str]


# Predefined reusable templates
WRITER_TEMPLATES: Dict[str, PromptTemplate] = {
    "email": PromptTemplate(
        id="tpl_email",
        name="Professional Email",
        feature="email",
        description="Crafts polished corporate emails with clear subject lines, greetings, and calls to action.",
        system_prompt=(
            "You are the WorkDesk AI Professional Email Writer. "
            "Write an email adhering to the specified tone ({tone}), target audience ({audience}), "
            "and length ({length}). Always include a compelling Subject line, professional greeting, "
            "clear paragraphs, and appropriate sign-off. "
            "Language target: {language}. "
            "If language is Hinglish, blend natural conversational Hindi words written in Latin script with English business terminology."
        ),
        user_prompt_pattern=(
            "PURPOSE / BRIEF:\n{input_text}\n\n"
            "CONTROLS:\nTone: {tone}\nAudience: {audience}\nLength: {length}\nLanguage: {language}\n\n"
            "Please generate the complete email:"
        ),
        suggested_tones=["Professional", "Concise", "Persuasive", "Friendly", "Urgent"],
    ),
    "whatsapp": PromptTemplate(
        id="tpl_whatsapp",
        name="WhatsApp-Style Message",
        feature="whatsapp",
        description="Generates concise, punchy messages formatted with bullet points and emojis suitable for chat apps.",
        system_prompt=(
            "You are the WorkDesk AI WhatsApp & Chat Copywriter. "
            "Write an engaging, easy-to-read chat message adhering to the specified tone ({tone}), "
            "audience ({audience}), and length ({length}). "
            "Use clear line breaks, bullet points where relevant, and appropriate business-friendly emojis. "
            "Language target: {language}. "
            "If language is Hinglish, use natural casual colloquial phrasing commonly used on Indian WhatsApp chats."
        ),
        user_prompt_pattern=(
            "TOPIC / MESSAGE INTENT:\n{input_text}\n\n"
            "CONTROLS:\nTone: {tone}\nAudience: {audience}\nLength: {length}\nLanguage: {language}\n\n"
            "Please generate the WhatsApp message:"
        ),
        suggested_tones=["Casual", "Friendly", "Urgent", "Persuasive", "Professional"],
    ),
    "proposal": PromptTemplate(
        id="tpl_proposal",
        name="Business & Project Proposal",
        feature="proposal",
        description="Structures comprehensive business proposals including Executive Summary, Scope, Value Proposition, and Timeline.",
        system_prompt=(
            "You are the WorkDesk AI Enterprise Proposal Specialist. "
            "Generate a structured business proposal tailored for {audience} with a {tone} tone. "
            "Format with Markdown headers: Executive Summary, Objectives & Scope, Proposed Solution, Deliverables, and Next Steps. "
            "Length guideline: {length}. Language target: {language}."
        ),
        user_prompt_pattern=(
            "PROPOSAL BRIEF / CLIENT REQUIREMENTS:\n{input_text}\n\n"
            "CONTROLS:\nTone: {tone}\nAudience: {audience}\nLength: {length}\nLanguage: {language}\n\n"
            "Please write the formal proposal:"
        ),
        suggested_tones=["Persuasive", "Professional", "Executive", "Empathetic"],
    ),
    "report": PromptTemplate(
        id="tpl_report",
        name="Executive & Project Report",
        feature="report",
        description="Creates analytical briefings with Key Findings, Methodology, Status Updates, and Recommendations.",
        system_prompt=(
            "You are the WorkDesk AI Executive Report Analyst. "
            "Produce an executive briefing formatted in Markdown with structured sections: "
            "Overview, Key Performance Highlights, Findings & Challenges, and Recommendations. "
            "Maintain a {tone} tone for an audience of {audience}. Length: {length}. Language: {language}."
        ),
        user_prompt_pattern=(
            "REPORT DATA & CORE HIGHLIGHTS:\n{input_text}\n\n"
            "CONTROLS:\nTone: {tone}\nAudience: {audience}\nLength: {length}\nLanguage: {language}\n\n"
            "Please generate the structured report:"
        ),
        suggested_tones=["Executive", "Professional", "Concise", "Analytical"],
    ),
    "social": PromptTemplate(
        id="tpl_social",
        name="Social Media & LinkedIn Post",
        feature="social",
        description="Drafts engaging LinkedIn and social posts with strong hooks and relevant hashtags.",
        system_prompt=(
            "You are the WorkDesk AI Social Media Strategist. "
            "Create an impactful post optimized for professional social platforms (e.g. LinkedIn). "
            "Start with an attention-grabbing hook line, provide crisp value, and conclude with an engaging Call to Action (CTA) and 3-5 hashtags. "
            "Tone: {tone}. Audience: {audience}. Length: {length}. Language: {language}."
        ),
        user_prompt_pattern=(
            "POST CONCEPT / INSIGHT:\n{input_text}\n\n"
            "CONTROLS:\nTone: {tone}\nAudience: {audience}\nLength: {length}\nLanguage: {language}\n\n"
            "Please generate the social post:"
        ),
        suggested_tones=["Engaging", "Persuasive", "Casual", "Professional", "Inspirational"],
    ),
    "rewrite": PromptTemplate(
        id="tpl_rewrite",
        name="Tone & Flow Rewriter",
        feature="rewrite",
        description="Rewrites text to adjust vocabulary, flow, clarity, and tone without losing key facts.",
        system_prompt=(
            "You are the WorkDesk AI Editor & Rewriter. "
            "Rewrite the provided text to strictly reflect a {tone} tone and appeal to {audience}. "
            "Enhance sentence variety, flow, and vocabulary while keeping all factual information intact. "
            "Length guideline: {length}. Language: {language}."
        ),
        user_prompt_pattern=(
            "ORIGINAL TEXT TO REWRITE:\n{input_text}\n\n"
            "TARGET CONTROLS:\nTone: {tone}\nAudience: {audience}\nLength: {length}\nLanguage: {language}\n\n"
            "Please provide the rewritten text:"
        ),
        suggested_tones=["Professional", "Concise", "Persuasive", "Friendly", "Empathetic"],
    ),
    "summarize": PromptTemplate(
        id="tpl_summarize",
        name="Executive Summarizer",
        feature="summarize",
        description="Condenses lengthy passages into concise takeaways, bulleted summaries, or TL;DRs.",
        system_prompt=(
            "You are the WorkDesk AI Executive Summarizer. "
            "Summarize the provided content into a crystal-clear overview tailored for {audience}. "
            "Deliver a 1-sentence TL;DR followed by bullet points of core takeaways. "
            "Tone: {tone}. Length: {length}. Language: {language}."
        ),
        user_prompt_pattern=(
            "CONTENT TO SUMMARIZE:\n{input_text}\n\n"
            "CONTROLS:\nTone: {tone}\nAudience: {audience}\nLength: {length}\nLanguage: {language}\n\n"
            "Please provide the summary:"
        ),
        suggested_tones=["Concise", "Executive", "Professional"],
    ),
    "translate": PromptTemplate(
        id="tpl_translate",
        name="Multi-Lingual Translator",
        feature="translate",
        description="Translates fluently between English, Hindi, and Hinglish with contextual nuance.",
        system_prompt=(
            "You are the WorkDesk AI Expert Translator. "
            "Translate the source text into {language} maintaining natural idioms, professional tone ({tone}), "
            "and business context. "
            "If translating into Hinglish, preserve technical terms in English and use natural Romanized Hindi grammar and vocabulary commonly used in modern Indian corporate communication."
        ),
        user_prompt_pattern=(
            "SOURCE TEXT TO TRANSLATE:\n{input_text}\n\n"
            "TARGET LANGUAGE: {language}\nTARGET TONE: {tone}\n\n"
            "Please provide the faithful and natural translation:"
        ),
        suggested_tones=["Professional", "Conversational", "Formal", "Friendly"],
    ),
    "grammar": PromptTemplate(
        id="tpl_grammar",
        name="Grammar & Polish Specialist",
        feature="grammar",
        description="Fixes punctuation, syntax, spelling, and phrasing errors, providing both corrected text and improvement notes.",
        system_prompt=(
            "You are the WorkDesk AI Grammar and Style Specialist. "
            "Analyze the provided text, correct all grammar, spelling, punctuation, and stylistic inconsistencies, "
            "and output: "
            "1. Corrected Version\n"
            "2. Key Corrections Summary (bullet points explaining what was fixed)\n"
            "Maintain the original meaning while elevating clarity. Language target: {language}."
        ),
        user_prompt_pattern=(
            "TEXT TO CORRECT:\n{input_text}\n\n"
            "TARGET LANGUAGE: {language}\nTARGET TONE: {tone}\n\n"
            "Please output the corrected version and bulleted improvement notes:"
        ),
        suggested_tones=["Professional", "Accurate", "Concise"],
    ),
}


class TemplateEngine:
    """Renders structured prompts without hardcoding prompt strings inside API route handlers."""

    def render(
        self,
        feature: str,
        input_text: str,
        tone: str = "Professional",
        length: str = "Medium",
        language: str = "English",
        audience: str = "General",
        custom_instructions: Optional[str] = None,
    ) -> Dict[str, str]:
        template = WRITER_TEMPLATES.get(feature.lower())
        if not template:
            template = WRITER_TEMPLATES["email"]

        system_prompt = template.system_prompt.format(
            tone=tone,
            audience=audience,
            length=length,
            language=language,
        )

        user_prompt = template.user_prompt_pattern.format(
            input_text=input_text.strip(),
            tone=tone,
            audience=audience,
            length=length,
            language=language,
        )

        if custom_instructions and custom_instructions.strip():
            user_prompt += f"\n\nADDITIONAL USER INSTRUCTIONS:\n{custom_instructions.strip()}"

        return {
            "template_id": template.id,
            "feature": template.feature,
            "system_prompt": system_prompt,
            "user_prompt": user_prompt,
        }

    def list_templates(self) -> List[Dict[str, str]]:
        return [
            {
                "id": t.id,
                "name": t.name,
                "feature": t.feature,
                "description": t.description,
                "suggested_tones": t.suggested_tones,
            }
            for t in WRITER_TEMPLATES.values()
        ]


template_engine = TemplateEngine()
