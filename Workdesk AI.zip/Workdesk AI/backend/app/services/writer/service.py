"""
WorkDesk AI - Writer Agent Service
Coordinates template rendering, LLM generation, credit deduction, history, saved prompts, and feedback.
"""

import time
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional
from backend.app.core.exceptions import ForbiddenError, NotFoundError, PaymentRequiredError, ValidationError
from backend.app.core.logging import logger
from backend.app.services.ai.router import ai_router
from backend.app.services.auth_service import auth_service
from backend.app.services.writer.templates import template_engine

# In-memory storage for generation history & saved prompts
_GENERATIONS_STORE: Dict[str, Dict[str, Any]] = {}
_SAVED_PROMPTS_STORE: Dict[str, Dict[str, Any]] = {}

CREDIT_COST_PER_GENERATION = 1


class WriterService:
    async def generate_content(
        self,
        user_id: str,
        feature: str,
        input_text: str,
        tone: str = "Professional",
        length: str = "Medium",
        language: str = "English",
        audience: str = "General",
        custom_instructions: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Executes Writer generation:
        1. Checks & deducts user credits.
        2. Renders prompt via template engine.
        3. Calls AI Router with fallback.
        4. Saves record in user generation history.
        """
        if not input_text or not input_text.strip():
            raise ValidationError("Input text cannot be empty.")

        # Check credits
        user = auth_service.get_user_by_id(user_id)
        if not user:
            raise NotFoundError("User not found.")

        if user.get("credits", 0) < CREDIT_COST_PER_GENERATION:
            raise PaymentRequiredError(
                f"Insufficient credits. This generation requires {CREDIT_COST_PER_GENERATION} credits. "
                f"Your balance is {user.get('credits', 0)}. Please upgrade or add credits."
            )

        # Render prompt decoupled from route handler
        rendered = template_engine.render(
            feature=feature,
            input_text=input_text,
            tone=tone,
            length=length,
            language=language,
            audience=audience,
            custom_instructions=custom_instructions,
        )

        start_time = time.time()

        # Call AI router
        llm_resp = await ai_router.generate_with_fallback(
            prompt=rendered["user_prompt"],
            system_prompt=rendered["system_prompt"],
            complexity="medium",
        )

        duration_ms = round((time.time() - start_time) * 1000)

        # Deduct credit
        updated_credits = auth_service.deduct_credits(
            user_id=user_id,
            amount=CREDIT_COST_PER_GENERATION,
            description=f"Writer Agent: {feature.capitalize()} ({language}, {tone})",
        )

        generation_id = str(uuid.uuid4())
        generated_text = llm_resp.content.strip()

        record = {
            "id": generation_id,
            "user_id": user_id,
            "feature": feature,
            "input_text": input_text,
            "output_text": generated_text,
            "tone": tone,
            "length": length,
            "language": language,
            "audience": audience,
            "custom_instructions": custom_instructions,
            "provider_used": llm_resp.provider,
            "model_used": llm_resp.model_name,
            "credits_deducted": CREDIT_COST_PER_GENERATION,
            "remaining_credits": updated_credits,
            "duration_ms": duration_ms,
            "feedback": None,
            "created_at": datetime.utcnow().isoformat(),
        }

        _GENERATIONS_STORE[generation_id] = record

        logger.info(
            "Writer generated: id=%s user=%s feature=%s lang=%s provider=%s credits_remaining=%d",
            generation_id, user_id, feature, language, llm_resp.provider, updated_credits
        )

        return record

    def list_history(self, user_id: str, limit: int = 30) -> List[Dict[str, Any]]:
        records = [g for g in _GENERATIONS_STORE.values() if g["user_id"] == user_id]
        records.sort(key=lambda x: x["created_at"], reverse=True)
        return records[:limit]

    def get_generation(self, generation_id: str, user_id: str) -> Dict[str, Any]:
        record = _GENERATIONS_STORE.get(generation_id)
        if not record:
            raise NotFoundError("Generation record not found.")
        if record["user_id"] != user_id:
            raise ForbiddenError("You do not have access to this generation record.")
        return record

    def record_feedback(
        self, generation_id: str, user_id: str, rating: int, comment: Optional[str] = None
    ) -> Dict[str, Any]:
        record = self.get_generation(generation_id, user_id)
        feedback = {
            "rating": 1 if rating > 0 else -1,
            "comment": comment or "",
            "timestamp": datetime.utcnow().isoformat(),
        }
        record["feedback"] = feedback
        logger.info("Feedback recorded for generation %s: rating=%d", generation_id, feedback["rating"])
        return {"status": "success", "feedback": feedback}

    # Saved Prompts Library
    def save_prompt(
        self, user_id: str, title: str, content: str, feature: str = "email"
    ) -> Dict[str, Any]:
        prompt_id = str(uuid.uuid4())
        item = {
            "id": prompt_id,
            "user_id": user_id,
            "title": title.strip() or "Untitled Prompt",
            "content": content.strip(),
            "feature": feature,
            "created_at": datetime.utcnow().isoformat(),
        }
        _SAVED_PROMPTS_STORE[prompt_id] = item
        return item

    def list_saved_prompts(self, user_id: str) -> List[Dict[str, Any]]:
        prompts = [p for p in _SAVED_PROMPTS_STORE.values() if p["user_id"] == user_id]
        prompts.sort(key=lambda x: x["created_at"], reverse=True)
        return prompts

    def delete_saved_prompt(self, prompt_id: str, user_id: str) -> bool:
        item = _SAVED_PROMPTS_STORE.get(prompt_id)
        if not item:
            raise NotFoundError("Saved prompt not found.")
        if item["user_id"] != user_id:
            raise ForbiddenError("You do not have permission to delete this saved prompt.")
        del _SAVED_PROMPTS_STORE[prompt_id]
        return True


writer_service = WriterService()
