"""
WorkDesk AI - Smart AI Router & Fallback Engine
Selects optimal LLM provider and model based on task complexity, modality, and cost policy.
Implements retry limits and automatic provider fallback.
"""

from typing import Dict, List, Optional
from backend.app.core.config import settings
from backend.app.core.exceptions import AppException
from backend.app.core.logging import logger
from backend.app.services.ai.providers.base import BaseLLMProvider, LLMResponse
from backend.app.services.ai.providers.groq import GroqProvider
from backend.app.services.ai.providers.mistral import MistralProvider
from backend.app.services.ai.providers.gemini import GeminiProvider


class AIRouter:
    def __init__(self):
        self.providers: Dict[str, BaseLLMProvider] = {
            "groq": GroqProvider(),
            "mistral": MistralProvider(),
            "gemini": GeminiProvider(),
        }

    def get_provider(self, name: str) -> BaseLLMProvider:
        prov = self.providers.get(name.lower())
        if not prov:
            raise AppException(
                status_code=400,
                error_code="INVALID_PROVIDER",
                message=f"Provider '{name}' is not supported.",
            )
        return prov

    def select_provider_and_model(
        self,
        complexity: str = "medium",
        modality: str = "text",
        preferred_provider: Optional[str] = None,
    ) -> tuple[BaseLLMProvider, str]:
        """Routes to best provider and model according to complexity and modality."""
        if preferred_provider and preferred_provider in self.providers:
            prov = self.providers[preferred_provider]
            return prov, prov.get_default_model()

        if modality == "multimodal":
            prov = self.providers["gemini"]
            return prov, prov.get_default_model()

        if complexity == "low":
            prov = self.providers["groq"]
            return prov, prov.get_default_model()
        elif complexity == "high":
            prov = self.providers["mistral"]
            return prov, prov.get_default_model()
        else:
            # Medium: default to configured preferred provider or groq
            pref = settings.LLM_PREFERRED_PROVIDER.lower()
            prov = self.providers.get(pref, self.providers["groq"])
            return prov, prov.get_default_model()

    async def generate_with_fallback(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        complexity: str = "medium",
        modality: str = "text",
        preferred_provider: Optional[str] = None,
    ) -> LLMResponse:
        """Executes LLM request with safe retries and automatic fallback to alternative providers."""
        primary_provider, model = self.select_provider_and_model(
            complexity, modality, preferred_provider
        )

        fallback_order = [p for p in ["groq", "mistral", "gemini"] if p != primary_provider.name]
        candidate_providers = [primary_provider] + [self.providers[p] for p in fallback_order]

        last_error = None

        for prov in candidate_providers:
            for attempt in range(settings.LLM_MAX_RETRIES):
                try:
                    logger.info("Attempting LLM call via '%s' (attempt %d/%d)", prov.name, attempt + 1, settings.LLM_MAX_RETRIES)
                    response = await prov.generate(
                        prompt=prompt,
                        system_prompt=system_prompt,
                        model_id=prov.get_default_model(),
                    )
                    return response
                except Exception as exc:
                    logger.warning("Provider '%s' failed on attempt %d: %s", prov.name, attempt + 1, exc)
                    last_error = exc

        # If all candidates fail, raise clean structured exception
        raise AppException(
            status_code=503,
            error_code="LLM_PROVIDERS_UNAVAILABLE",
            message="All configured AI providers failed to respond. Please try again shortly.",
            details={"last_error": str(last_error)},
        )


ai_router = AIRouter()
