"""
WorkDesk AI - LLM Provider Base Abstraction
Ensures all LLM interactions are decoupled from vendor-specific SDK quirks.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional


@dataclass
class LLMResponse:
    """Standardized response object from any LLM provider."""
    content: str
    model_id: str
    provider: str
    input_tokens: int
    output_tokens: int
    latency_ms: int


class BaseLLMProvider(ABC):
    """Abstract interface that every LLM provider must implement."""

    def __init__(self, name: str):
        self.name = name

    @abstractmethod
    def is_configured(self) -> bool:
        """Returns True if the provider has valid API credentials configured."""
        pass

    @abstractmethod
    def get_default_model(self) -> str:
        """Returns the default model ID from configuration."""
        pass

    @abstractmethod
    async def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        model_id: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> LLMResponse:
        """Generates a text completion."""
        pass
