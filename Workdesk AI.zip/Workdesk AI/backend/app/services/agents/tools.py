"""
WorkDesk AI - Tool Registry & Explicit Permission Gatekeeper
Ensures AI agents cannot autonomously access unauthorized system tools.
"""

from typing import Any, Callable, Dict, List
from backend.app.core.exceptions import AppException


class UnauthorizedToolError(AppException):
    def __init__(self, agent_name: str, tool_name: str, required_permission: str):
        super().__init__(
            status_code=403,
            error_code="UNAUTHORIZED_TOOL_ACCESS",
            message=f"Agent '{agent_name}' is not authorized to execute tool '{tool_name}' (requires '{required_permission}').",
            details={
                "agent_name": agent_name,
                "tool_name": tool_name,
                "required_permission": required_permission,
            },
        )


class Tool:
    def __init__(
        self,
        name: str,
        description: str,
        permission: str,
        func: Callable[..., Any],
    ):
        self.name = name
        self.description = description
        self.permission = permission
        self.func = func

    def execute(self, **kwargs) -> Any:
        return self.func(**kwargs)


class ToolRegistry:
    def __init__(self):
        self.tools: Dict[str, Tool] = {}
        # Explicit permissions granted per agent
        self.agent_permissions: Dict[str, List[str]] = {
            "supervisor": [],  # Supervisor only delegates; no direct tool mutation
            "document": ["document:read", "document:extract"],
            "data": ["data:read", "data:write", "data:profile", "data:clean"],
            "writer": ["writer:write", "writer:format"],
            "research": ["research:search"],
        }
        self._register_default_tools()

    def register_tool(self, tool: Tool):
        self.tools[tool.name] = tool

    def get_tool(self, name: str) -> Tool:
        if name not in self.tools:
            raise AppException(
                status_code=404,
                error_code="TOOL_NOT_FOUND",
                message=f"Tool '{name}' is not registered in the system.",
            )
        return self.tools[name]

    def authorize_and_execute(
        self, agent_name: str, tool_name: str, **kwargs
    ) -> Any:
        tool = self.get_tool(tool_name)
        allowed_permissions = self.agent_permissions.get(agent_name.lower(), [])

        if tool.permission not in allowed_permissions:
            raise UnauthorizedToolError(
                agent_name=agent_name,
                tool_name=tool_name,
                required_permission=tool.permission,
            )

        return tool.execute(**kwargs)

    def _register_default_tools(self):
        # 1. Document Extraction Tool
        self.register_tool(
            Tool(
                name="extract_document_text",
                description="Extracts raw text and page metadata from PDF/DOCX files.",
                permission="document:extract",
                func=lambda filename="": {
                    "filename": filename,
                    "pages": 12,
                    "extracted_sample": "Summary of Q3 Financial Report and operations...",
                },
            )
        )

        # 2. Data Column Profiler Tool
        self.register_tool(
            Tool(
                name="profile_dataframe",
                description="Computes column types, missing values, and row statistics.",
                permission="data:profile",
                func=lambda row_count=100, col_count=5: {
                    "total_rows": row_count,
                    "total_columns": col_count,
                    "missing_values": 0,
                    "duplicates": 2,
                },
            )
        )

        # 3. Data Cleaning Tool
        self.register_tool(
            Tool(
                name="clean_dataset",
                description="Performs deterministic deduplication and null-filling.",
                permission="data:clean",
                func=lambda remove_duplicates=True: {
                    "status": "cleaned",
                    "duplicates_removed": 2,
                    "nulls_imputed": 0,
                },
            )
        )

        # 4. Writer Tone Formatter Tool
        self.register_tool(
            Tool(
                name="format_tone_copy",
                description="Applies tone transformations and formatting rules.",
                permission="writer:format",
                func=lambda tone="professional", text="": {
                    "tone": tone,
                    "word_count": len(text.split()),
                    "formatted_text": text.strip(),
                },
            )
        )

        # 5. Research Query Tool
        self.register_tool(
            Tool(
                name="query_web_index",
                description="Queries indexed public web data sources.",
                permission="research:search",
                func=lambda query="": {
                    "query": query,
                    "results_count": 3,
                    "sources": ["https://example.org/report-2026"],
                },
            )
        )


tool_registry = ToolRegistry()
