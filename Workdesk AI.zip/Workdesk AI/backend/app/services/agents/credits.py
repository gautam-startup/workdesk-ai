"""
WorkDesk AI - Credit Estimation & Quota Enforcement Engine
Configurable credit costs per task type with pre-flight quota checks.
"""

from typing import Dict
from backend.app.core.exceptions import AppException


class InsufficientCreditsError(AppException):
    def __init__(self, current_balance: int, required_credits: int):
        super().__init__(
            status_code=402,
            error_code="INSUFFICIENT_CREDITS",
            message=f"Insufficient credit balance. You have {current_balance} credits, but this task requires {required_credits} credits.",
            details={
                "current_balance": current_balance,
                "required_credits": required_credits,
                "upgrade_url": "/billing",
            },
        )


# Configurable credit costs by task type
DEFAULT_CREDIT_COSTS: Dict[str, int] = {
    "writer": 1,
    "email": 1,
    "rewrite": 1,
    "summary": 2,
    "document": 3,
    "pdf": 3,
    "data": 5,
    "excel": 5,
    "csv": 5,
    "research": 8,
    "complex": 10,
}


def estimate_credits(task_type: str, has_file: bool = False, file_size_mb: float = 0.0) -> int:
    """Calculates credits based on task classification and optional attachment size."""
    normalized_type = task_type.lower().strip()
    base_cost = DEFAULT_CREDIT_COSTS.get(normalized_type, 2)

    if has_file and file_size_mb > 5.0:
        base_cost += 2

    return base_cost


def verify_and_deduct_credits(current_balance: int, cost: int) -> int:
    """Ensures balance is adequate and returns the remaining balance."""
    if current_balance < cost:
        raise InsufficientCreditsError(
            current_balance=current_balance,
            required_credits=cost,
        )
    return current_balance - cost
