"""
WorkDesk AI - Central Multi-Agent Orchestrator
Coordinates Supervisor planning, specialist delegation, deterministic tools, and credit deductions.
"""

import time
from typing import Any, Dict, Optional
from backend.app.core.exceptions import AppException
from backend.app.core.logging import logger
from backend.app.services.agents.credits import verify_and_deduct_credits
from backend.app.services.agents.state import AgentState, ExecutionStep
from backend.app.services.agents.supervisor import supervisor_agent
from backend.app.services.agents.specialists import (
    writer_agent,
    document_agent,
    data_agent,
    research_agent,
)

# In-memory execution logs tracking for Phase 3 telemetry
_AGENT_USAGE_RECORDS = []


class AgentOrchestrator:
    def __init__(self):
        self.specialists = {
            "writer": writer_agent,
            "document": document_agent,
            "data": data_agent,
            "research": research_agent,
        }

    async def run(
        self,
        task: str,
        user_id: str,
        user_credit_balance: int = 10,
        forced_agent: Optional[str] = None,
    ) -> AgentState:
        """Executes full multi-agent pipeline with credit checks and safe milestones."""
        start_time = time.perf_counter()

        # 1. Initialize State
        state = AgentState(task=task)

        # 2. Supervisor Planning & Intent Routing
        state = supervisor_agent.plan_execution(state)

        if forced_agent:
            if forced_agent not in self.specialists:
                raise AppException(
                    status_code=400,
                    error_code="INVALID_AGENT",
                    message=f"Agent '{forced_agent}' is not a valid specialist agent.",
                )
            state.selected_agent = forced_agent
            state.task_type = forced_agent

        # 3. Credit Verification & Pre-flight check
        verify_and_deduct_credits(
            current_balance=user_credit_balance,
            cost=state.credits_cost,
        )

        # 4. Specialist Execution
        specialist = self.specialists.get(state.selected_agent)
        if not specialist:
            raise AppException(
                status_code=400,
                error_code="INVALID_AGENT",
                message=f"No specialist handler found for agent '{state.selected_agent}'.",
            )

        step3_start = time.perf_counter()
        state = await specialist.execute(state)
        step3_duration = int((time.perf_counter() - step3_start) * 1000)

        # 5. Update Safe Execution Milestones
        if len(state.safe_steps) >= 3:
            state.safe_steps[2].status = "completed"
            state.safe_steps[2].duration_ms = step3_duration

        if len(state.safe_steps) >= 4:
            state.safe_steps[3].status = "completed"
            state.safe_steps[3].duration_ms = 35

        state.current_status = "completed"

        # 6. Usage Telemetry Logging
        total_duration = int((time.perf_counter() - start_time) * 1000)
        _AGENT_USAGE_RECORDS.append({
            "user_id": user_id,
            "task": task[:80],
            "agent": state.selected_agent,
            "credits_deducted": state.credits_cost,
            "latency_ms": total_duration,
            "timestamp": time.time(),
        })

        logger.info(
            "Agent task executed successfully: agent=%s cost=%d credits duration=%dms",
            state.selected_agent,
            state.credits_cost,
            total_duration,
        )

        return state

    def get_recent_usage(self):
        return list(_AGENT_USAGE_RECORDS)


agent_orchestrator = AgentOrchestrator()
