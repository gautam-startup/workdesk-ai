"""
WorkDesk AI - Agent State Definitions (LangGraph compatible)
Represents the normalized execution state passed across agents in the graph.
"""

from typing import Any, Dict, List, Optional
from backend.app.schemas.health import BaseModel, Field


class ExecutionStep(BaseModel):
    step_number: int
    name: str
    status: str = "completed"  # queued, in_progress, completed, failed
    duration_ms: int = 0
    safe_detail: Optional[str] = None


class AgentState(BaseModel):
    task: str
    task_type: str = "general"
    selected_agent: str = "supervisor"
    current_status: str = "initialized"
    plan_steps: List[str] = Field(default_factory=list)
    safe_steps: List[ExecutionStep] = Field(default_factory=list)
    tool_calls: List[Dict[str, Any]] = Field(default_factory=list)
    final_output: str = ""
    credits_cost: int = 1
    error: Optional[str] = None
