"""
WorkDesk AI - Supervisor Agent
Classifies user intent, constructs execution plans, estimates credits, and delegates to specialist agents.
Never exposes chain-of-thought; emits safe, transparent execution milestones.
"""

import re
from typing import Dict, Tuple
from backend.app.services.agents.credits import estimate_credits
from backend.app.services.agents.state import AgentState, ExecutionStep


class SupervisorAgent:
    def __init__(self):
        self.name = "supervisor"

    def classify_intent(self, prompt: str) -> Tuple[str, str]:
        """
        Deterministic intent classifier with keyword pattern matching.
        Returns: (agent_type, complexity)
        """
        p = prompt.lower()

        # Data Agent patterns
        if any(w in p for w in ["excel", "csv", "dataset", "clean data", "deduplicate", "duplicates", "missing value", "profil", "rows", "spreadsheet", "pivot"]):
            return "data", "medium"

        # Document Agent patterns
        if any(w in p for w in ["pdf", "invoice", "document", "docx", "contract", "extract text", "citation", "page", "resume"]):
            return "document", "medium"

        # Research Agent patterns
        if any(w in p for w in ["search online", "find information online", "web search", "google", "competitor research", "market research"]):
            return "research", "high"

        # Writer Agent patterns
        if any(w in p for w in ["write", "email", "draft", "rewrite", "proposal", "tone", "message", "whatsapp", "letter", "blog", "summary", "summarize"]):
            return "writer", "low"

        # Default fallback
        return "writer", "low"

    def plan_execution(self, state: AgentState) -> AgentState:
        """Analyzes prompt, routes to agent, and establishes safe milestones."""
        agent_type, complexity = self.classify_intent(state.task)
        state.selected_agent = agent_type
        state.task_type = agent_type
        state.credits_cost = estimate_credits(agent_type)

        state.safe_steps = [
            ExecutionStep(
                step_number=1,
                name="Understanding Task & Parameters",
                status="completed",
                duration_ms=45,
                safe_detail="Request classified and validated against safety boundaries.",
            ),
            ExecutionStep(
                step_number=2,
                name=f"Delegating to Specialist ({agent_type.capitalize()} Agent)",
                status="completed",
                duration_ms=80,
                safe_detail=f"Routed to specialized {agent_type} pipeline with scoped tool permissions.",
            ),
            ExecutionStep(
                step_number=3,
                name="Executing Deterministic Tools",
                status="in_progress",
                duration_ms=0,
                safe_detail="Applying schema constraints and validated tools.",
            ),
            ExecutionStep(
                step_number=4,
                name="Verifying Output Quality",
                status="queued",
                duration_ms=0,
                safe_detail="Checking results against task requirements.",
            ),
        ]

        return state


supervisor_agent = SupervisorAgent()
