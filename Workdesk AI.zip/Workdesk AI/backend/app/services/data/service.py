"""
WorkDesk AI - Data Agent Service
Coordinates dataset parsing, session state, deterministic operations, AI reports, and file export.
"""

import os
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from backend.app.core.exceptions import ForbiddenError, NotFoundError, ValidationError
from backend.app.core.logging import logger
from backend.app.services.ai.router import ai_router
from backend.app.services.data.dataframe import DataFrame, read_csv_bytes, read_xlsx_bytes
from backend.app.services.data.operations import safe_operation_dispatcher
from backend.app.services.data.profiler import data_profiler

# In-memory datasets store
_DATASETS_STORE: Dict[str, Dict[str, Any]] = {}


class DataService:
    def upload_dataset(
        self,
        user_id: str,
        filename: str,
        file_bytes: bytes,
    ) -> Dict[str, Any]:
        """Loads CSV or XLSX into DataFrame, profiles schema and health metrics."""
        _, ext = os.path.splitext(filename.lower())
        if ext not in [".csv", ".xlsx"]:
            raise ValidationError("Unsupported tabular format. Only .csv and .xlsx files are supported.")

        if len(file_bytes) == 0:
            raise ValidationError("Uploaded dataset is empty.")

        # Parse into DataFrame
        if ext == ".csv":
            df = read_csv_bytes(file_bytes)
        else:
            df = read_xlsx_bytes(file_bytes)

        if len(df) == 0 and not df.columns:
            raise ValidationError("Could not parse columns from tabular dataset.")

        dataset_id = str(uuid.uuid4())
        profile = data_profiler.profile(df, filename)

        record = {
            "id": dataset_id,
            "user_id": user_id,
            "filename": filename,
            "format": ext.lstrip("."),
            "df": df,
            "profile": profile,
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat(),
            "history": [],
        }

        _DATASETS_STORE[dataset_id] = record

        logger.info(
            "Dataset uploaded & profiled: id=%s user_id=%s filename=%s shape=(%d, %d)",
            dataset_id, user_id, filename, profile["total_rows"], profile["total_columns"]
        )

        return self.get_dataset_summary(dataset_id, user_id)

    def list_user_datasets(self, user_id: str) -> List[Dict[str, Any]]:
        user_sets = [d for d in _DATASETS_STORE.values() if d["user_id"] == user_id]
        user_sets.sort(key=lambda x: x["updated_at"], reverse=True)
        return [
            {
                "id": d["id"],
                "filename": d["filename"],
                "format": d["format"],
                "total_rows": d["profile"]["total_rows"],
                "total_columns": d["profile"]["total_columns"],
                "quality_score": d["profile"]["quality_score"],
                "created_at": d["created_at"],
            }
            for d in user_sets
        ]

    def get_dataset_summary(self, dataset_id: str, user_id: str) -> Dict[str, Any]:
        record = self._get_record(dataset_id, user_id)
        df: DataFrame = record["df"]
        profile = record["profile"]

        return {
            "id": record["id"],
            "filename": record["filename"],
            "format": record["format"],
            "profile": profile,
            "columns": df.columns,
            "preview_rows": df.head(50),
            "created_at": record["created_at"],
            "updated_at": record["updated_at"],
            "history": record["history"],
        }

    def apply_operations(
        self,
        dataset_id: str,
        user_id: str,
        operations: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Applies a sequence of safe predefined operations deterministically."""
        record = self._get_record(dataset_id, user_id)
        current_df: DataFrame = record["df"]

        applied_summaries = []

        for op in operations:
            op_name = op.get("operation")
            params = op.get("params", {})
            current_df, meta = safe_operation_dispatcher.execute_operation(
                df=current_df,
                operation_name=op_name,
                params=params,
            )
            applied_summaries.append(meta.get("summary", f"Applied {op_name}"))
            record["history"].append({
                "operation": op_name,
                "timestamp": datetime.utcnow().isoformat(),
                "meta": meta,
            })

        # Re-profile updated DataFrame
        new_profile = data_profiler.profile(current_df, record["filename"])
        record["df"] = current_df
        record["profile"] = new_profile
        record["updated_at"] = datetime.utcnow().isoformat()

        logger.info(
            "Operations applied to dataset: id=%s count=%d new_rows=%d",
            dataset_id, len(operations), len(current_df)
        )

        return {
            "id": dataset_id,
            "operations_applied": applied_summaries,
            "profile": new_profile,
            "columns": current_df.columns,
            "preview_rows": current_df.head(50),
            "history": record["history"],
        }

    async def generate_report(self, dataset_id: str, user_id: str) -> Dict[str, Any]:
        """Synthesizes deterministic statistics with a natural language business briefing."""
        record = self._get_record(dataset_id, user_id)
        profile = record["profile"]
        df: DataFrame = record["df"]

        stats_summary = df.describe()
        issues_summary = [i["message"] for i in profile["detected_issues"]]

        prompt = (
            f"DATASET ANALYSIS:\n"
            f"Filename: {record['filename']}\n"
            f"Records: {profile['total_rows']} rows, {profile['total_columns']} columns\n"
            f"Quality Score: {profile['quality_score']}/100\n"
            f"Missing Percentage: {profile['missing_percentage']}%\n"
            f"Duplicate Rows: {profile['duplicate_rows']}\n"
            f"Detected Issues: {', '.join(issues_summary) if issues_summary else 'None'}\n"
            f"Descriptive Statistics Sample: {stats_summary}\n\n"
            f"Please synthesize this into an insightful Executive Business Report with:\n"
            f"1. Executive Data Health Summary\n"
            f"2. Statistical Highlights & Observed Trends\n"
            f"3. Strategic Operational Recommendations"
        )

        sys_prompt = (
            "You are the WorkDesk AI Data Intelligence Agent. "
            "Explain the deterministic findings clearly and professionally. "
            "Do NOT include internal thoughts or code snippets."
        )

        llm_resp = await ai_router.generate_with_fallback(
            prompt=prompt,
            system_prompt=sys_prompt,
            complexity="medium",
        )

        return {
            "dataset_id": dataset_id,
            "filename": record["filename"],
            "quality_score": profile["quality_score"],
            "analysis_report": llm_resp.content.strip(),
            "generated_at": datetime.utcnow().isoformat(),
        }

    def export_dataset(self, dataset_id: str, user_id: str, fmt: str = "csv") -> Tuple[str, bytes]:
        """Exports current cleaned DataFrame state to CSV bytes."""
        record = self._get_record(dataset_id, user_id)
        df: DataFrame = record["df"]
        csv_str = df.to_csv_string()
        filename = f"cleaned_{record['filename']}"
        if not filename.endswith(".csv"):
            filename = f"{os.path.splitext(filename)[0]}.csv"

        return filename, csv_str.encode("utf-8")

    def delete_dataset(self, dataset_id: str, user_id: str) -> bool:
        record = self._get_record(dataset_id, user_id)
        del _DATASETS_STORE[dataset_id]
        logger.info("Dataset deleted: id=%s user_id=%s", dataset_id, user_id)
        return True

    def _get_record(self, dataset_id: str, user_id: str) -> Dict[str, Any]:
        record = _DATASETS_STORE.get(dataset_id)
        if not record:
            raise NotFoundError("Dataset not found.")
        if record["user_id"] != user_id:
            raise ForbiddenError("You do not have permission to access this dataset.")
        return record


data_service = DataService()
