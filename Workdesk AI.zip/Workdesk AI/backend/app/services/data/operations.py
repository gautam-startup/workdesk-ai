"""
WorkDesk AI - Predefined Safe Data Operations Engine
Ensures ZERO arbitrary code execution; dispatches only strictly validated deterministic operations.
"""

from typing import Any, Dict, List, Optional, Tuple
from backend.app.core.exceptions import ValidationError
from backend.app.services.data.dataframe import DataFrame


class SafeOperationDispatcher:
    """Dispatches validated predefined tabular operations."""

    SUPPORTED_OPERATIONS = {
        "remove_duplicates",
        "fill_missing",
        "rename_column",
        "filter_rows",
        "sort_rows",
        "group_by",
        "aggregate",
        "describe",
        "correlation",
        "time_series_summary",
    }

    def execute_operation(
        self, df: DataFrame, operation_name: str, params: Optional[Dict[str, Any]] = None
    ) -> Tuple[DataFrame, Dict[str, Any]]:
        """
        Validates operation against strict whitelist and executes deterministically.
        Returns: (updated_df, execution_meta)
        """
        op = operation_name.strip().lower()
        if op not in self.SUPPORTED_OPERATIONS:
            raise ValidationError(
                f"Operation '{operation_name}' is not allowed. "
                f"Permitted operations: {', '.join(sorted(self.SUPPORTED_OPERATIONS))}."
            )

        params = params or {}

        if op == "remove_duplicates":
            subset = params.get("subset")
            keep = params.get("keep", "first")
            new_df, removed = df.remove_duplicates(subset=subset, keep=keep)
            return new_df, {
                "operation": "remove_duplicates",
                "duplicates_removed": removed,
                "rows_remaining": len(new_df),
                "summary": f"Removed {removed} duplicate rows. Remaining records: {len(new_df)}.",
            }

        elif op == "fill_missing":
            col = params.get("column")
            strategy = params.get("strategy", "mean")
            const_val = params.get("constant_value")
            if strategy not in ["mean", "median", "mode", "constant"]:
                raise ValidationError(f"Invalid fill strategy '{strategy}'. Allowed: mean, median, mode, constant.")
            new_df, filled = df.fill_missing(column=col, strategy=strategy, constant_value=const_val)
            target_desc = f"column '{col}'" if col else "all columns"
            return new_df, {
                "operation": "fill_missing",
                "values_imputed": filled,
                "strategy": strategy,
                "summary": f"Imputed {filled} missing cells across {target_desc} using strategy '{strategy}'.",
            }

        elif op == "rename_column":
            old_name = params.get("old_name")
            new_name = params.get("new_name")
            if not old_name or not new_name:
                raise ValidationError("rename_column requires 'old_name' and 'new_name'.")
            new_df = df.rename_column(old_name, new_name)
            return new_df, {
                "operation": "rename_column",
                "old_name": old_name,
                "new_name": new_name,
                "summary": f"Renamed column '{old_name}' to '{new_name}'.",
            }

        elif op == "filter_rows":
            col = params.get("column")
            op_sym = params.get("operator", "==")
            val = params.get("value")
            if not col or val is None:
                raise ValidationError("filter_rows requires 'column', 'operator', and 'value'.")
            new_df = df.filter_rows(column=col, operator=op_sym, value=val)
            return new_df, {
                "operation": "filter_rows",
                "column": col,
                "operator": op_sym,
                "value": str(val),
                "rows_retained": len(new_df),
                "summary": f"Filtered records where {col} {op_sym} {val}. Retained {len(new_df)} rows.",
            }

        elif op == "sort_rows":
            col = params.get("column")
            ascending = bool(params.get("ascending", True))
            if not col:
                raise ValidationError("sort_rows requires 'column'.")
            new_df = df.sort_rows(column=col, ascending=ascending)
            order_label = "ascending" if ascending else "descending"
            return new_df, {
                "operation": "sort_rows",
                "column": col,
                "ascending": ascending,
                "summary": f"Sorted dataset by column '{col}' ({order_label}).",
            }

        elif op == "group_by":
            group_cols = params.get("group_columns", [])
            agg_col = params.get("agg_column")
            agg_func = params.get("agg_func", "mean")
            if not group_cols or not agg_col:
                raise ValidationError("group_by requires 'group_columns' (list) and 'agg_column'.")
            new_df = df.group_by(group_columns=group_cols, agg_column=agg_col, agg_func=agg_func)
            return new_df, {
                "operation": "group_by",
                "group_columns": group_cols,
                "agg_column": agg_col,
                "agg_func": agg_func,
                "summary": f"Aggregated {agg_col} ({agg_func}) grouped by {', '.join(group_cols)}.",
            }

        elif op == "describe":
            stats = df.describe()
            return df, {
                "operation": "describe",
                "statistics": stats,
                "summary": "Generated descriptive statistics for numeric columns.",
            }

        elif op == "correlation":
            cols = params.get("columns")
            corr = df.correlation(columns=cols)
            return df, {
                "operation": "correlation",
                "matrix": corr,
                "summary": "Computed Pearson correlation coefficients matrix.",
            }

        elif op == "time_series_summary":
            date_col = params.get("date_column")
            val_col = params.get("value_column")
            if not date_col or not val_col:
                raise ValidationError("time_series_summary requires 'date_column' and 'value_column'.")
            summary_df = df.group_by(group_columns=[date_col], agg_column=val_col, agg_func="sum")
            return summary_df, {
                "operation": "time_series_summary",
                "date_column": date_col,
                "value_column": val_col,
                "summary": f"Computed chronological trend summary for {val_col} along {date_col}.",
            }

        raise ValidationError(f"Unhandled operation '{op}'.")


safe_operation_dispatcher = SafeOperationDispatcher()
