"""
WorkDesk AI - Deterministic Data Profiling & Chart Recommendation Engine
Computes health metrics, detects data quality issues, and generates frontend-ready chart configs.
"""

from typing import Any, Dict, List
from backend.app.services.data.dataframe import DataFrame


class DataProfiler:
    def profile(self, df: DataFrame, filename: str = "dataset") -> Dict[str, Any]:
        total_rows, total_cols = df.shape
        dtypes = df.detect_column_types()

        # Missing values analysis
        null_counts = {}
        total_null_cells = 0
        for col in df.columns:
            cnt = sum(
                1
                for r in df.data
                if r.get(col) is None
                or str(r.get(col)).strip() == ""
                or str(r.get(col)).lower() in ["nan", "null", "none"]
            )
            null_counts[col] = cnt
            total_null_cells += cnt

        total_cells = max(1, total_rows * total_cols)
        null_percentage = round((total_null_cells / total_cells) * 100, 1)

        # Exact duplicate rows check
        seen = set()
        duplicate_rows = 0
        for r in df.data:
            key = tuple(r.get(c) for c in df.columns)
            if key in seen:
                duplicate_rows += 1
            seen.add(key)

        duplicate_percentage = round((duplicate_rows / max(1, total_rows)) * 100, 1)

        # Detected data issues
        issues: List[Dict[str, Any]] = []
        if duplicate_rows > 0:
            issues.append({
                "type": "duplicate_rows",
                "severity": "medium",
                "message": f"Found {duplicate_rows} exact duplicate rows ({duplicate_percentage}% of total).",
                "suggested_action": "remove_duplicates",
            })

        for col, count in null_counts.items():
            if count > 0:
                col_pct = round((count / max(1, total_rows)) * 100, 1)
                severity = "high" if col_pct > 25 else "low"
                strategy = "mean" if dtypes.get(col) == "numeric" else "mode"
                issues.append({
                    "type": "missing_values",
                    "severity": severity,
                    "column": col,
                    "message": f"Column '{col}' has {count} missing values ({col_pct}%).",
                    "suggested_action": "fill_missing",
                    "suggested_params": {"column": col, "strategy": strategy},
                })

        # Calculate dataset health score (0-100)
        penalty = (null_percentage * 1.5) + (duplicate_percentage * 2.0)
        quality_score = max(10, min(100, int(100 - penalty)))

        # Summary statistics
        statistics = df.describe()

        # Chart Generation
        charts = self._generate_charts(df, dtypes)

        return {
            "filename": filename,
            "total_rows": total_rows,
            "total_columns": total_cols,
            "column_types": dtypes,
            "null_counts": null_counts,
            "total_missing_cells": total_null_cells,
            "missing_percentage": null_percentage,
            "duplicate_rows": duplicate_rows,
            "duplicate_percentage": duplicate_percentage,
            "quality_score": quality_score,
            "detected_issues": issues,
            "statistics": statistics,
            "charts": charts,
        }

    def _generate_charts(self, df: DataFrame, dtypes: Dict[str, str]) -> List[Dict[str, Any]]:
        """Generates chart recommendations with computed labels and data points."""
        charts = []
        num_cols = [c for c, t in dtypes.items() if t == "numeric"]
        cat_cols = [c for c, t in dtypes.items() if t in ["text", "categorical"]]
        date_cols = [c for c, t in dtypes.items() if t == "datetime"]

        # 1. Bar Chart: Categorical distribution of first text column
        if cat_cols and df.data:
            c_col = cat_cols[0]
            counts: Dict[str, int] = {}
            for r in df.data:
                val = str(r.get(c_col, "Unknown")).strip()
                if val:
                    counts[val] = counts.get(val, 0) + 1

            sorted_counts = sorted(counts.items(), key=lambda x: x[1], reverse=True)[:8]
            if sorted_counts:
                charts.append({
                    "chart_type": "bar",
                    "title": f"Distribution by {c_col.capitalize()}",
                    "x_label": c_col,
                    "y_label": "Record Count",
                    "labels": [k for k, _ in sorted_counts],
                    "values": [v for _, v in sorted_counts],
                })

        # 2. Line Chart: Time series trend or numerical progression
        if date_cols and num_cols:
            d_col = date_cols[0]
            n_col = num_cols[0]
            agg = df.group_by([d_col], n_col, agg_func="sum")
            sorted_agg = sorted(agg.data, key=lambda x: str(x.get(d_col, "")))[:12]
            if sorted_agg:
                charts.append({
                    "chart_type": "line",
                    "title": f"Chronological Trend: {n_col} over {d_col}",
                    "x_label": d_col,
                    "y_label": n_col,
                    "labels": [str(r.get(d_col)) for r in sorted_agg],
                    "values": [r.get(f"{n_col}_sum", 0) for r in sorted_agg],
                })
        elif num_cols and len(df.data) > 1:
            # Numerical comparison bar chart
            n_col = num_cols[0]
            sample = df.data[:10]
            label_col = cat_cols[0] if cat_cols else df.columns[0]
            charts.append({
                "chart_type": "bar",
                "title": f"Top Samples: {n_col}",
                "x_label": label_col,
                "y_label": n_col,
                "labels": [str(r.get(label_col, f"Row {i}")) for i, r in enumerate(sample)],
                "values": [float(str(r.get(n_col, 0)).replace(",", "")) for r in sample],
            })

        return charts


data_profiler = DataProfiler()
