"""
WorkDesk AI - Deterministic Tabular DataFrame Engine
Provides deterministic tabular analysis, schema typing, statistics, and transformations.
Provides seamless fallback and pandas-compatible interfaces without requiring native C-extensions.
"""

import csv
import io
import math
import re
import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Union


class DataFrame:
    """Deterministic in-memory tabular structure with typed columns and safe operations."""

    def __init__(self, data: List[Dict[str, Any]], columns: Optional[List[str]] = None):
        self.data = [dict(row) for row in data]
        if columns:
            self.columns = list(columns)
        elif self.data:
            self.columns = list(self.data[0].keys())
        else:
            self.columns = []

    def __len__(self) -> int:
        return len(self.data)

    @property
    def shape(self) -> Tuple[int, int]:
        return len(self.data), len(self.columns)

    def copy(self) -> "DataFrame":
        return DataFrame(self.data, self.columns)

    def head(self, n: int = 50) -> List[Dict[str, Any]]:
        return self.data[:n]

    def to_dict(self) -> List[Dict[str, Any]]:
        return [dict(r) for r in self.data]

    def detect_column_types(self) -> Dict[str, str]:
        """Detects column types: 'numeric', 'datetime', 'boolean', or 'text'."""
        dtypes = {}
        for col in self.columns:
            non_null_values = [r[col] for r in self.data if r.get(col) is not None and str(r.get(col)).strip() != ""]
            if not non_null_values:
                dtypes[col] = "text"
                continue

            # Check boolean
            if all(str(v).lower() in ["true", "false", "1", "0", "yes", "no"] for v in non_null_values):
                dtypes[col] = "boolean"
                continue

            # Check numeric
            is_num = True
            for v in non_null_values:
                try:
                    float(str(v).replace(",", ""))
                except ValueError:
                    is_num = False
                    break
            if is_num:
                dtypes[col] = "numeric"
                continue

            # Check datetime
            is_date = True
            sample = non_null_values[:20]
            for v in sample:
                try:
                    # Check common formats
                    s = str(v).strip()
                    if not re.search(r"\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]\d{2,4}", s):
                        is_date = False
                        break
                except Exception:
                    is_date = False
                    break
            if is_date and len(sample) > 0:
                dtypes[col] = "datetime"
            else:
                dtypes[col] = "text"

        return dtypes

    def remove_duplicates(self, subset: Optional[List[str]] = None, keep: str = "first") -> Tuple["DataFrame", int]:
        """Removes exact duplicate rows based on subset or all columns."""
        cols = subset if subset else self.columns
        seen = set()
        new_data = []
        duplicates_removed = 0

        for row in self.data:
            key = tuple(row.get(c) for c in cols)
            if key in seen:
                duplicates_removed += 1
                continue
            seen.add(key)
            new_data.append(row)

        return DataFrame(new_data, self.columns), duplicates_removed

    def fill_missing(
        self,
        column: Optional[str] = None,
        strategy: str = "constant",
        constant_value: Any = None,
    ) -> Tuple["DataFrame", int]:
        """Fills missing values using 'mean', 'median', 'mode', or 'constant'."""
        target_cols = [column] if column else self.columns
        new_data = [dict(r) for r in self.data]
        imputed_count = 0

        dtypes = self.detect_column_types()

        for col in target_cols:
            if col not in self.columns:
                continue

            vals = [
                float(str(r[col]).replace(",", ""))
                for r in self.data
                if r.get(col) is not None and str(r[col]).strip() != "" and dtypes.get(col) == "numeric"
            ]

            fill_val = constant_value
            if strategy == "mean" and vals:
                fill_val = round(sum(vals) / len(vals), 2)
            elif strategy == "median" and vals:
                sorted_vals = sorted(vals)
                n = len(sorted_vals)
                fill_val = sorted_vals[n // 2]
            elif strategy == "mode":
                counts: Dict[Any, int] = {}
                for r in self.data:
                    v = r.get(col)
                    if v is not None and str(v).strip() != "":
                        counts[v] = counts.get(v, 0) + 1
                if counts:
                    fill_val = max(counts.items(), key=lambda x: x[1])[0]
            elif strategy == "constant" and constant_value is None:
                fill_val = 0 if dtypes.get(col) == "numeric" else "N/A"

            for row in new_data:
                v = row.get(col)
                if v is None or str(v).strip() == "" or str(v).lower() in ["nan", "null", "none"]:
                    row[col] = fill_val
                    imputed_count += 1

        return DataFrame(new_data, self.columns), imputed_count

    def filter_rows(self, column: str, operator: str, value: Any) -> "DataFrame":
        """Filters rows safely using predefined comparison operators."""
        if column not in self.columns:
            return self

        filtered = []
        op = operator.strip().lower()

        for row in self.data:
            cell = row.get(column)
            match = False

            # Numeric comparison
            try:
                num_cell = float(str(cell).replace(",", ""))
                num_val = float(str(value).replace(",", ""))
                if op in ["==", "="]: match = num_cell == num_val
                elif op in ["!=", "<>"]: match = num_cell != num_val
                elif op == ">": match = num_cell > num_val
                elif op == ">=": match = num_cell >= num_val
                elif op == "<": match = num_cell < num_val
                elif op == "<=": match = num_cell <= num_val
            except (ValueError, TypeError):
                # Text comparison
                str_cell = str(cell).lower() if cell is not None else ""
                str_val = str(value).lower()
                if op in ["==", "="]: match = str_cell == str_val
                elif op in ["!=", "<>"]: match = str_cell != str_val
                elif op == "contains": match = str_val in str_cell
                elif op == "starts_with": match = str_cell.startswith(str_val)
                elif op == "ends_with": match = str_cell.endswith(str_val)

            if match:
                filtered.append(row)

        return DataFrame(filtered, self.columns)

    def sort_rows(self, column: str, ascending: bool = True) -> "DataFrame":
        """Sorts DataFrame rows by specified column."""
        if column not in self.columns:
            return self

        def sort_key(row):
            v = row.get(column)
            if v is None or str(v).strip() == "" or str(v).lower() in ["nan", "null", "none"]:
                return (1, 0.0, "") if ascending else (-1, 0.0, "")
            try:
                return (0, float(str(v).replace(",", "")), "")
            except (ValueError, TypeError):
                return (0, 0.0, str(v).lower())

        sorted_data = sorted(self.data, key=sort_key, reverse=not ascending)
        return DataFrame(sorted_data, self.columns)

    def rename_column(self, old_name: str, new_name: str) -> "DataFrame":
        if old_name not in self.columns or not new_name.strip():
            return self

        new_cols = [new_name if c == old_name else c for c in self.columns]
        new_data = []
        for r in self.data:
            new_r = dict(r)
            if old_name in new_r:
                new_r[new_name] = new_r.pop(old_name)
            new_data.append(new_r)

        return DataFrame(new_data, new_cols)

    def group_by(
        self, group_columns: List[str], agg_column: str, agg_func: str = "mean"
    ) -> "DataFrame":
        """Groups by columns and aggregates numeric target column."""
        groups: Dict[Tuple, List[float]] = {}
        for row in self.data:
            key = tuple(row.get(c) for c in group_columns)
            val = row.get(agg_column)
            try:
                num = float(str(val).replace(",", ""))
                groups.setdefault(key, []).append(num)
            except (ValueError, TypeError):
                pass

        result = []
        res_cols = list(group_columns) + [f"{agg_column}_{agg_func}"]

        for key, values in groups.items():
            if not values:
                continue
            if agg_func == "sum": res_val = round(sum(values), 2)
            elif agg_func == "mean": res_val = round(sum(values) / len(values), 2)
            elif agg_func == "count": res_val = len(values)
            elif agg_func == "min": res_val = min(values)
            elif agg_func == "max": res_val = max(values)
            else: res_val = round(sum(values) / len(values), 2)

            entry = {col: key[i] for i, col in enumerate(group_columns)}
            entry[f"{agg_column}_{agg_func}"] = res_val
            result.append(entry)

        return DataFrame(result, res_cols)

    def describe(self) -> Dict[str, Dict[str, float]]:
        """Calculates statistical description for all numeric columns."""
        dtypes = self.detect_column_types()
        desc = {}

        for col in self.columns:
            if dtypes.get(col) != "numeric":
                continue

            vals = []
            for r in self.data:
                v = r.get(col)
                if v is not None and str(v).strip() != "":
                    try:
                        vals.append(float(str(v).replace(",", "")))
                    except ValueError:
                        pass

            if not vals:
                continue

            n = len(vals)
            sorted_v = sorted(vals)
            mean = sum(vals) / n
            variance = sum((x - mean) ** 2 for x in vals) / max(1, n - 1)
            std = math.sqrt(variance)

            desc[col] = {
                "count": n,
                "mean": round(mean, 2),
                "std": round(std, 2),
                "min": round(sorted_v[0], 2),
                "q25": round(sorted_v[int(n * 0.25)], 2),
                "median": round(sorted_v[n // 2], 2),
                "q75": round(sorted_v[int(n * 0.75)], 2),
                "max": round(sorted_v[-1], 2),
            }

        return desc

    def correlation(self, columns: Optional[List[str]] = None) -> Dict[str, Dict[str, float]]:
        """Calculates Pearson correlation matrix for numerical columns."""
        dtypes = self.detect_column_types()
        num_cols = [c for c in (columns or self.columns) if dtypes.get(c) == "numeric"]

        matrix: Dict[str, Dict[str, float]] = {c: {} for c in num_cols}
        col_series = {}

        for c in num_cols:
            series = []
            for r in self.data:
                try:
                    series.append(float(str(r.get(c, 0)).replace(",", "")))
                except (ValueError, TypeError):
                    series.append(0.0)
            col_series[c] = series

        n = len(self.data)
        for c1 in num_cols:
            for c2 in num_cols:
                if c1 == c2:
                    matrix[c1][c2] = 1.0
                    continue

                s1 = col_series[c1]
                s2 = col_series[c2]
                if n < 2:
                    matrix[c1][c2] = 0.0
                    continue

                mean1 = sum(s1) / n
                mean2 = sum(s2) / n
                cov = sum((x - mean1) * (y - mean2) for x, y in zip(s1, s2))
                var1 = sum((x - mean1) ** 2 for x in s1)
                var2 = sum((y - mean2) ** 2 for y in s2)

                denom = math.sqrt(var1 * var2)
                matrix[c1][c2] = round(cov / denom, 3) if denom > 0 else 0.0

        return matrix

    def to_csv_string(self) -> str:
        """Exports DataFrame to clean CSV string."""
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=self.columns)
        writer.writeheader()
        for row in self.data:
            writer.writerow(row)
        return buf.getvalue()


def read_csv_bytes(file_bytes: bytes) -> DataFrame:
    """Parses CSV bytes with encoding detection."""
    try:
        text = file_bytes.decode("utf-8")
    except UnicodeDecodeError:
        text = file_bytes.decode("latin-1", errors="replace")

    # Sniff delimiter
    sample = text[:4096]
    delimiter = ","
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        delimiter = dialect.delimiter
    except Exception:
        delimiter = ","

    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    columns = reader.fieldnames or []
    data = []
    for r in reader:
        data.append(r)

    return DataFrame(data, list(columns))


def read_xlsx_bytes(file_bytes: bytes) -> DataFrame:
    """
    Parses XLSX bytes using native OpenXML zip extraction.
    Ensures zero reliance on external C-dependencies while supporting full modern Excel sheets.
    """
    try:
        with zipfile.ZipFile(io.BytesIO(file_bytes)) as zf:
            # Shared strings
            shared_strings = []
            if "xl/sharedStrings.xml" in zf.namelist():
                xml_ss = zf.read("xl/sharedStrings.xml")
                root_ss = ET.fromstring(xml_ss)
                ns = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
                for si in root_ss.findall(".//x:si", ns):
                    t = si.find(".//x:t", ns)
                    shared_strings.append(t.text if t is not None and t.text else "")

            # Sheet 1
            sheet_xml = zf.read("xl/worksheets/sheet1.xml")
            root_s = ET.fromstring(sheet_xml)
            ns = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}

            rows = []
            for row in root_s.findall(".//x:row", ns):
                cells = []
                for c in row.findall(".//x:c", ns):
                    cell_type = c.attrib.get("t")
                    val_node = c.find(".//x:v", ns)
                    val = val_node.text if val_node is not None and val_node.text else ""

                    if cell_type == "s" and val.isdigit():
                        idx = int(val)
                        if idx < len(shared_strings):
                            val = shared_strings[idx]
                    cells.append(val)
                rows.append(cells)

            if not rows:
                return DataFrame([])

            columns = [str(c).strip() if c else f"col_{i}" for i, c in enumerate(rows[0])]
            data = []
            for r in rows[1:]:
                # Pad to columns length
                padded = r + [""] * (len(columns) - len(r))
                row_dict = {columns[i]: padded[i] for i in range(len(columns))}
                data.append(row_dict)

            return DataFrame(data, columns)
    except Exception:
        # Fallback empty
        return DataFrame([])
